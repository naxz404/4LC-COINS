const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database.json');
const BACKUP_FILE = path.join(__dirname, '..', 'database.backup.json');
const DATA_DIR = path.join(__dirname, '..', 'data');
const GUILD_DIR = path.join(DATA_DIR, 'guilds');

const DEFAULTS = {
  activityMessage: { userId: '', date: '', channelId: '', count: '0' },
  activityVoice: { userId: '', date: '', channelId: '', seconds: '0' },
  batiment: { bar: 'no', garage: 'no', magasin: 'no', cinema: 'no', gare: 'no', mairie: 'no', entrepot: '0' },
  bot: { statut: 'By 4LC | discord.gg/ddJMXWYJ29', type: 'Watching' },
  cards: { collection: '{}', lastDraw: '0' },
  commandBlock: { statut: 'on' },
  commands: { adds: 'on', remove: 'on', reset: 'on' },
  guild: {
    prefix: '&', footer: '4LC Coins', footerEnabled: 'on', accessRoleId: '',
    dropEnabled: 'off', dropHour: '20', dropMinute: '00', dropChannelId: '', dropAmount: '100', lastDropDate: '',
    topEnabled: 'off', topHour: '20', topMinute: '00', topChannelId: '', lastTopDate: '',
    updateEnabled: 'off', updateChannelId: ''
  },
  items: {},
  job: { cultivateur: 'no', blanchisseur: 'no', policier: 'no', hacker: 'no', cambrioleur: 'no', juge: 'no', tueur: 'no', braqueur: 'no' },
  juge: {},
  list: {},
  list2: {},
  logs: { logstransac: null, logsimpots: null, logsvocal: null, logsxp: null },
  mine: { wagon: '0', charbon: '0', fer: '0', ors: '0', diamant: '0', mine: '0' },
  team: { coins: '0', reputation: '0', cadenas: '5', avatar: 'no', banner: 'no' },
  tmembers: { grade: 'Membres' },
  user: { coins: '0', banque: '0', reputation: '0', color: 'LightGrey', team: 'no', pill: '0', vocal: 'on', msg: 'on', xp: '0', palier: '0', victoires: '0' },
  xp: { xp: 'on', msg: '5', vocal: '10', messageChannels: '' },
  gain: { workmin: '20', workmax: '250', dailymin: '100', dailymax: '1000', bar: '100', garage: '200', magasin: '300', cinema: '400', gare: '500', mairie: '600', vocal: '0', stream: '0', cam: '0', voiceChannels: '' }
};

const GLOBAL_TABLES = ['bot'];

function isGuildTable(table) {
  return table && !GLOBAL_TABLES.includes(table);
}

function guildTables() {
  return Object.keys(DEFAULTS).filter(isGuildTable);
}

function emptyDb(tables = Object.keys(DEFAULTS)) {
  const obj = {};
  tables.forEach(t => obj[t] = []);
  return obj;
}

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(GUILD_DIR)) fs.mkdirSync(GUILD_DIR, { recursive: true });
}

function loadFile(file, tables = Object.keys(DEFAULTS)) {
  ensureDirs();
  try {
    if (!fs.existsSync(file)) {
      const db = emptyDb(tables);
      fs.writeFileSync(file, JSON.stringify(db, null, 2));
      return db;
    }
    const db = JSON.parse(fs.readFileSync(file, 'utf8') || '{}');
    tables.forEach(t => { if (!Array.isArray(db[t])) db[t] = []; });
    return db;
  } catch (e) {
    const db = emptyDb(tables);
    fs.writeFileSync(file, JSON.stringify(db, null, 2));
    return db;
  }
}

function saveFile(file, db) {
  ensureDirs();
  fs.writeFileSync(file, JSON.stringify(db, null, 2));
}

function loadGlobal() {
  return loadFile(DB_FILE);
}

function saveGlobal(db) {
  saveFile(DB_FILE, db);
}

function guildFile(guildId) {
  return path.join(GUILD_DIR, `${String(guildId).replace(/[^\w-]/g, '')}.json`);
}

function loadGuild(guildId) {
  return loadFile(guildFile(guildId), guildTables());
}

function saveGuild(guildId, db) {
  saveFile(guildFile(guildId), db);
}

function sqlValue(value) {
  if (value === null || value === undefined) return "''";
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  if (typeof value === 'boolean') return value ? '1' : '0';
  return `'${String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

function bindParams(sql, params) {
  if (!Array.isArray(params) || !params.length) return sql;
  let i = 0;
  return sql.replace(/\?/g, () => {
    if (i >= params.length) return '?';
    return sqlValue(params[i++]);
  });
}

function strip(v) {
  if (v === undefined || v === null) return '';
  v = String(v).trim();
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
  return v.replace(/\\'/g, "'").replace(/\\"/g, '"');
}

function splitCSV(str) {
  const out = [];
  let cur = '', q = null, par = 0;
  for (let i = 0; i < str.length; i++) {
    const c = str[i];
    if (q) {
      cur += c;
      if (c === q && str[i - 1] !== '\\') q = null;
      continue;
    }
    if (c === '"' || c === "'") { q = c; cur += c; continue; }
    if (c === '(') par++;
    if (c === ')') par--;
    if (c === ',' && par === 0) { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function parseWhere(where) {
  if (!where) return [];
  where = where.replace(/;\s*$/, '').trim();
  return where.split(/\s+AND\s+/i).map(part => {
    const m = part.match(/`?([\wÀ-ÿ]+)`?\s*=\s*(.+)$/i);
    if (!m) return null;
    return { key: normalizeKey(m[1]), value: strip(m[2]) };
  }).filter(Boolean);
}

function normalizeKey(key) {
  return key === 'cinéma' ? 'cinema' : key;
}

function normalizeRow(row) {
  if (row && row['cinéma'] !== undefined && row.cinema === undefined) row.cinema = row['cinéma'];
  return row;
}

function matchWhere(row, conds) {
  normalizeRow(row);
  return conds.every(c => String(row[c.key] ?? '') === String(c.value));
}

function ensureDefault(table, row) {
  return normalizeRow(Object.assign({}, DEFAULTS[table] || {}, row || {}));
}

function maybeAutoCreate(db, table, conds, persist) {
  const autoTables = ['gain', 'commands', 'guild', 'logs', 'xp', 'bot'];
  if (!autoTables.includes(table)) return;
  const keyNames = conds.map(c => c.key);
  if (!keyNames.includes('guildId') && !keyNames.includes('botId')) return;
  if (db[table].some(r => matchWhere(r, conds))) return;
  const row = ensureDefault(table, {});
  conds.forEach(c => row[c.key] = c.value);
  db[table].push(row);
  persist(db);
}

function getTable(sql) {
  const m = sql.match(/(?:FROM|INTO|UPDATE|DELETE\s+FROM)\s+`?([\wÀ-ÿ]+)`?/i);
  return m ? normalizeKey(m[1]) : null;
}

function inferGuildId(sql) {
  const whereM = sql.match(/\sWHERE\s+(.+?)(?:\s+ORDER\s+BY|\s+LIMIT|$)/i);
  const fromWhere = parseWhere(whereM && whereM[1]).find(c => c.key === 'guildId');
  if (fromWhere) return fromWhere.value;

  const insertM = sql.match(/INSERT\s+INTO\s+`?[\wÀ-ÿ]+`?\s*\(([^)]+)\)\s*(?:VALUES\s*\(([^)]+)\)|SELECT\s+(.+?)\s+WHERE\s+NOT\s+EXISTS)/is);
  if (!insertM) return null;
  const cols = splitCSV(insertM[1]).map(c => normalizeKey(c.replace(/[`\s]/g, '')));
  const index = cols.indexOf('guildId');
  if (index === -1) return null;
  const values = splitCSV(insertM[2] || insertM[3] || '').map(strip);
  return values[index] || null;
}

function evalExpr(expr, row) {
  expr = expr.trim();
  const inc = expr.match(/^`?([\wÀ-ÿ]+)`?\s*([+-])\s*(-?\d+(?:\.\d+)?)$/);
  if (inc) {
    const key = normalizeKey(inc[1]);
    const cur = Number(row[key] || 0);
    const n = Number(inc[3]);
    return String(inc[2] === '+' ? cur + n : cur - n);
  }
  return strip(expr);
}

function select(db, sql, persist) {
  const table = getTable(sql);
  if (!table || !db[table]) return [];
  const whereM = sql.match(/\sWHERE\s+(.+?)(?:\s+ORDER\s+BY|\s+LIMIT|$)/i);
  const conds = parseWhere(whereM && whereM[1]);
  maybeAutoCreate(db, table, conds, persist);
  let rows = db[table].filter(r => matchWhere(r, conds)).map(r => Object.assign({}, ensureDefault(table, r)));
  const orderM = sql.match(/ORDER\s+BY\s+`?([\wÀ-ÿ]+)`?\s*(ASC|DESC)?/i);
  if (orderM) {
    const k = normalizeKey(orderM[1]), dir = (orderM[2] || 'ASC').toUpperCase();
    rows.sort((a, b) => (Number(a[k] || 0) - Number(b[k] || 0)) * (dir === 'DESC' ? -1 : 1));
  }
  const limitM = sql.match(/LIMIT\s+(\d+)/i);
  if (limitM) rows = rows.slice(0, Number(limitM[1]));
  return rows;
}

function insert(db, sql, persist) {
  const table = getTable(sql);
  if (!table || !db[table]) return { affectedRows: 0 };
  const m = sql.match(/INSERT\s+INTO\s+`?[\wÀ-ÿ]+`?\s*\(([^)]+)\)\s*(?:VALUES\s*\(([^)]+)\)|SELECT\s+(.+?)\s+WHERE\s+NOT\s+EXISTS\s*\((.+)\))/is);
  if (!m) return { affectedRows: 0 };
  const cols = splitCSV(m[1]).map(c => normalizeKey(c.replace(/[`\s]/g, '')));
  let vals = [];
  if (m[2]) vals = splitCSV(m[2]).map(strip);
  else if (m[3]) vals = splitCSV(m[3]).map(strip);
  const row = ensureDefault(table, {});
  cols.forEach((c, i) => row[c] = vals[i] ?? '');
  if (m[4]) {
    const nested = select(db, m[4], persist);
    if (nested.length) return { affectedRows: 0 };
  }
  db[table].push(row);
  persist(db);
  return { affectedRows: 1, insertId: db[table].length };
}

function update(db, sql, persist) {
  const table = getTable(sql);
  if (!table || !db[table]) return { affectedRows: 0 };
  const setM = sql.match(/\sSET\s+(.+?)\s+WHERE\s+(.+)$/is);
  if (!setM) return { affectedRows: 0 };
  const sets = splitCSV(setM[1]).map(s => {
    const m = s.match(/`?([\wÀ-ÿ]+)`?\s*=\s*(.+)$/is);
    return m ? { key: normalizeKey(m[1]), expr: m[2] } : null;
  }).filter(Boolean);
  const conds = parseWhere(setM[2]);
  maybeAutoCreate(db, table, conds, persist);
  let n = 0;
  db[table].forEach(row => {
    normalizeRow(row);
    if (!matchWhere(row, conds)) return;
    sets.forEach(s => row[s.key] = evalExpr(s.expr, row));
    n++;
  });
  if (n) persist(db);
  return { affectedRows: n };
}

function del(db, sql, persist) {
  const table = getTable(sql);
  if (!table || !db[table]) return { affectedRows: 0 };
  const whereM = sql.match(/\sWHERE\s+(.+)$/i);
  const conds = parseWhere(whereM && whereM[1]);
  const before = db[table].length;
  db[table] = db[table].filter(r => !matchWhere(r, conds));
  const n = before - db[table].length;
  if (n) persist(db);
  return { affectedRows: n };
}

function migrateLegacyDb() {
  ensureDirs();
  if (!fs.existsSync(DB_FILE)) {
    saveGlobal(emptyDb());
    return;
  }

  const legacy = loadGlobal();
  if (legacy.__guildSplitMigrated) return;
  if (!fs.existsSync(BACKUP_FILE)) fs.copyFileSync(DB_FILE, BACKUP_FILE);

  const globalDb = emptyDb();
  GLOBAL_TABLES.forEach(table => globalDb[table] = legacy[table] || []);

  for (const table of guildTables()) {
    for (const oldRow of legacy[table] || []) {
      const row = ensureDefault(table, oldRow);
      if (!row.guildId) {
        globalDb[table].push(row);
        continue;
      }
      const guildDb = loadGuild(row.guildId);
      guildDb[table].push(row);
      saveGuild(row.guildId, guildDb);
    }
  }

  globalDb.__guildSplitMigrated = true;
  saveGlobal(globalDb);
}

class JsonDatabase {
  constructor() {
    migrateLegacyDb();
    this.data = loadGlobal();
  }

  connect(cb) {
    if (typeof cb === 'function') setImmediate(() => cb(null));
  }

  updateBuildingIncome(guildId, gains = {}) {
    try {
      const id = String(guildId || '');
      if (!id) return 0;
      const db = loadGuild(id);
      let changed = 0;
      for (const row of db.batiment || []) {
        normalizeRow(row);
        const building = ['bar', 'garage', 'magasin', 'cinema', 'gare', 'mairie'].find(k => row[k] === 'yes');
        if (!building) continue;
        const gain = Number(gains[building] || 0);
        if (!(gain > 0)) continue;
        const current = Math.max(0, Number(row.entrepot || 0));
        const next = Math.min(5000, current + gain);
        if (next !== current) {
          row.entrepot = String(next);
          changed++;
        }
      }
      if (changed) saveGuild(id, db);
      return changed;
    } catch (e) {
      console.log('[JSON DB] Revenus batiments:', e.message);
      return 0;
    }
  }

  query(sql, params, cb) {
    if (typeof params === 'function') {
      cb = params;
      params = [];
    }
    if (!Array.isArray(params)) params = [];
    try {
      if (!sql || typeof sql !== 'string') throw new Error('Requete SQL invalide');
      const raw = bindParams(sql, params).trim();
      const upper = raw.toUpperCase();
      const table = getTable(raw);
      const guildId = isGuildTable(table) ? inferGuildId(raw) : null;
      const db = guildId ? loadGuild(guildId) : this.data;
      const persist = guildId
        ? (nextDb) => saveGuild(guildId, nextDb)
        : (nextDb) => {
          this.data = nextDb;
          saveGlobal(nextDb);
        };

      let res;
      if (upper.startsWith('SELECT')) res = select(db, raw, persist);
      else if (upper.startsWith('INSERT')) res = insert(db, raw, persist);
      else if (upper.startsWith('UPDATE')) res = update(db, raw, persist);
      else if (upper.startsWith('DELETE')) res = del(db, raw, persist);
      else res = [];

      if (typeof cb === 'function') setImmediate(() => cb(null, res));
      return Promise.resolve(res);
    } catch (e) {
      console.log('[JSON DB]', e.message, sql);
      if (typeof cb === 'function') setImmediate(() => cb(e, []));
      return Promise.resolve([]);
    }
  }
}

module.exports = () => new JsonDatabase();
