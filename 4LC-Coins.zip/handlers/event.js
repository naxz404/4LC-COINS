const fs = require("fs");

module.exports = (bot) => {
  const loadEvent = (event, fileLabel) => {
    let eventName = event.name;
    const eventHandler = event.execute;

    if (!eventName || !eventHandler) {
      console.log(`❌・${fileLabel} [Event invalide]`);
      return;
    }

    if (eventName === "ready") eventName = "clientReady";

    if (event.once) {
      bot.once(eventName, (...args) => eventHandler(...args, bot));
    } else {
      bot.on(eventName, (...args) => eventHandler(...args, bot));
    }

    console.log(`✅・${fileLabel} [Events]`);
  };

  const eventFiles = fs
    .readdirSync("./events/")
    .filter((file) => file.endsWith(".js"));

  for (const file of eventFiles) {
    const event = require(`../events/${file}`);
    loadEvent(event, file);
  }

  const eventSubFolders = fs
    .readdirSync("./events/")
    .filter((folder) => !folder.endsWith(".js"));

  for (const folder of eventSubFolders) {
    const subEventFiles = fs
      .readdirSync(`./events/${folder}/`)
      .filter((file) => file.endsWith(".js"));

    for (const file of subEventFiles) {
      const event = require(`../events/${folder}/${file}`);
      loadEvent(event, `${file} - ${folder}`);
    }
  }
};