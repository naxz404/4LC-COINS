module.exports = {
  connectDatabase(bot) {
    const loadDatabase = require('./loadDatabase');
    bot.db = loadDatabase();
    bot.db.connect((err) => {
      if (err) console.log('[BDD JSON] Erreur:', err.message);
      else console.log('[BDD JSON] Connectée avec succès sans MySQL');
    });
  },
};
