// Version sans MySQL : base locale JSON dans database.json
module.exports = require('./jsonDatabase');
