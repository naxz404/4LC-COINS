# 🪙 4LC Coins

> Bot Discord d'économie virtuelle : coins, mini-jeux, jobs, teams, boutique de rôles, trades et bien plus.

**By 4LC** • Support : https://discord.gg/ddJMXWYJ29

---

## ✨ Fonctionnalités

| Catégorie | Commandes |
|---|---|
| 💰 Coins | `coins`, `dep`, `with`, `pay`, `profil`, `rep`, `top`, `topall` |
| 🎁 Gains | `daily`, `work`, `mine`, `gift`, `rob`, `slut` |
| 🎲 Mini-jeux | `blackjack`, `dragon`, `gunfight`, `morpion`, `pfc`, `puissance4`, `roulette`, `slots` |
| 💼 Jobs | `job`, `batiment`, `braquage`, `cambriolage`, `hack`, `kill`, `arrest`, `juge`, `wagon` |
| 🃏 Cartes | `mycard`, `duel` |
| 👥 Teams | `tcreate`, `tinvite`, `tinfos`, `tdep`, `twith`, `tbuy`, `ttop`, `tedit`, ... |
| 🔁 Trade | `trade`, `value` |
| 🛒 Boutique | `buy`, `cshop`, `items` (rôles achetables avec des coins) |
| ⚙️ Administration | `start`, `drop`, `course`, `setgain`, `setxp`, `setlogs`, `acces`, `footer`, `prefix`, `reset`, ... |
| 👑 Owner | `owner`, `unowner`, `setprofil`, `leave` |
| 🧰 Utilitaire | `help`, `helpall`, `stats`, `ping`, `vocal`, `msg` |

Fais `&help` (ou `<ton prefix>help`) pour la liste complète.

> Le bot fonctionne **avec un préfixe** : `&` par défaut, modifiable par serveur avec `&prefix <nouveau>` (réservé aux administrateurs). Mentionne le bot pour voir le préfixe actuel. Les commandes slash `/` sont désactivées.

---

## 🛠️ Stack technique

* **Node.js** v18 ou supérieur
* **discord.js** v14
* **Stockage** : fichiers JSON (`database.json` et `data/guilds/`), aucune base de données externe à installer

---

## 🚀 Installation

1. **Clone le projet**
   ```bash
   git clone <url-de-ton-repo>
   cd <nom-du-dossier>
   ```

2. **Crée ton bot** sur le [Portail des développeurs Discord](https://discord.com/developers/applications).
   Dans l'onglet **Bot**, active les 3 intents privilégiés :
   *Presence Intent*, *Server Members Intent* et *Message Content Intent*.

3. **Crée ton `config.json`** en copiant l'exemple :
   ```bash
   cp config.example.json config.json
   ```
   puis remplis-le :
   ```json
   {
     "token": "TON_TOKEN_ICI",
     "clientId": "ID_DU_BOT",
     "guildId": "ID_DE_TON_SERVEUR",
     "ownerId": ["TON_ID_DISCORD"]
   }
   ```

4. **Installe et lance**
   ```bash
   npm install
   npm start
   ```

5. **Invite le bot** avec les permissions : voir les salons, envoyer des messages, intégrer des liens, lire l'historique, utiliser les emojis externes, gérer les rôles et gérer les messages. Puis fais `&start` pour créer ton profil.

> Le rôle du bot doit être placé **au-dessus** des rôles qu'il distribue.

⚠️ Ne partage jamais ton `config.json` : il contient ton token.

---

## 📄 Licence

Distribué sous licence **Apache 2.0** (voir `LICENSE`).
Ce projet est basé sur le travail d'origine de ses auteurs précédents ; la licence et ses mentions de copyright doivent être conservées.

---

## 📌 Support

https://discord.gg/ddJMXWYJ29
