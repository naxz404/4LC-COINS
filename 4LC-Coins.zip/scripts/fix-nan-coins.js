// Script de réparation à lancer UNE SEULE FOIS : `node scripts/fix-nan-coins.js`
//
// Corrige les profils dont les champs "coins" ou "banque" ont été corrompus
// par le bug GREATEST(...) de puissance4.js (la mini base JSON ne comprend pas
// cette syntaxe SQL, donc elle stockait le texte brut "GREATEST(coins - 20, 0)"
// à la place d'un nombre, ce qui provoquait ensuite des NaN quand ce texte
// était réutilisé dans un calcul, ex: &dep / &with).
//
// Ce script parcourt data/guilds/*.json et remet à 0 tout champ coins/banque
// qui n'est pas un nombre valide (NaN, "GREATEST(...)", etc.). Les autres
// champs ne sont jamais touchés.

const fs = require('fs');
const path = require('path');

const GUILD_DIR = path.join(__dirname, '..', 'data', 'guilds');

if (!fs.existsSync(GUILD_DIR)) {
  console.log('Aucun dossier data/guilds trouvé, rien à faire.');
  process.exit(0);
}

let totalFixed = 0;

for (const file of fs.readdirSync(GUILD_DIR).filter((f) => f.endsWith('.json'))) {
  const filePath = path.join(GUILD_DIR, file);
  const db = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  let changed = false;

  for (const row of db.user || []) {
    for (const field of ['coins', 'banque']) {
      const n = Number(row[field]);
      if (!Number.isFinite(n)) {
        console.log(`[${file}] user ${row.userId} : ${field} = "${row[field]}" -> remis à 0`);
        row[field] = '0';
        changed = true;
        totalFixed++;
      }
    }
  }

  for (const row of db.team || []) {
    const n = Number(row.coins);
    if (!Number.isFinite(n)) {
      console.log(`[${file}] team ${row.id} : coins = "${row.coins}" -> remis à 0`);
      row.coins = '0';
      changed = true;
      totalFixed++;
    }
  }

  if (changed) fs.writeFileSync(filePath, JSON.stringify(db, null, 2));
}

console.log(`\nTerminé. ${totalFixed} champ(s) corrompu(s) réparé(s).`);
