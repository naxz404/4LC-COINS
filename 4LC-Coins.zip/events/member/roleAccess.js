const { createUserProfile, hasProfile } = require("../../utils/profile.js");

// Quand un membre reçoit le rôle "accès coins" (configuré via &acces), on lui (re)crée
// automatiquement un profil à 0 s'il n'en a pas déjà un.
// Ça marche que le rôle soit donné via le bouton (déjà géré séparément dans
// interactionCreate.js) OU donné manuellement par un membre du staff dans Discord,
// ce qui n'était pas le cas avant : après un reset qui retire le rôle (voir reset.js),
// il suffit maintenant de redonner le rôle pour que le profil reparte à 0.
module.exports = {
  name: "guildMemberUpdate",
  async execute(oldMember, newMember, bot) {
    try {
      if (newMember.user.bot) return;
      if (oldMember.roles.cache.size === newMember.roles.cache.size &&
          [...newMember.roles.cache.keys()].every((id) => oldMember.roles.cache.has(id))) {
        return; // rien n'a changé au niveau des rôles
      }

      const addedRoles = newMember.roles.cache.filter((role) => !oldMember.roles.cache.has(role.id));
      if (!addedRoles.size) return;

      const guildSettings = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${newMember.guild.id}"`);
      const accessRoleId = guildSettings[0]?.accessRoleId;
      if (!accessRoleId || !addedRoles.has(accessRoleId)) return;

      hasProfile(bot, newMember.guild.id, newMember.id, (exists) => {
        if (exists) return;
        createUserProfile(bot, newMember.guild.id, newMember.id);
      });
    } catch (error) {
      console.error("[roleAccess]", error);
    }
  }
};
