const Discord = require("discord.js");
const ms = require('ms')
const { startAllManagedBots } = require("../../utils/managedBots");

module.exports = {
  name: "ready",
  once: true,
  async execute(bot) {
    console.log(`
    /////////////////////////////////////
    //                                 // By 4LC
    //  https://discord.gg/ddJMXWYJ29   //
    //                                 //
    ///////////////////://///////////////
    `)

    startAllManagedBots(bot).then((count) => {
      console.log(`4LC manager: ${count} bot(s) client(s) detecte(s).`);
    }).catch(console.error);

    try {
      // Toutes les commandes slash (/) sont desactivees : on force une liste vide.
      await bot.application.commands.set([]);
      console.log(`4LC manager: commandes slash (/) desactivees.`);
    } catch (error) {
      console.log(`Impossible de desynchroniser les commandes slash manager: ${error.message}`);
    }

    setInterval(() => {
      bot.db.query(`SELECT * FROM bot WHERE botId = "${bot.user.id}"`, async (err, req) => {
        if(req.length == 0) return;

        if(req[0].type == 'Streaming') {
          bot.user.setPresence({
            activities: [
              {
                name: `${req[0].statut}`,
                type: Discord.ActivityType.Streaming,
                url: 'https://twitch.tv/4LC',
              },
            ],
          });
        }

        if(req[0].type == 'Playing') {
          bot.user.setPresence({
            activities: [
              {
                name: `${req[0].statut}`,
                type: Discord.ActivityType.Playing,
              },
            ],
          });
        }

          if(req[0].type == 'Listening') {
            bot.user.setPresence({
              activities: [
                {
                  name: `${req[0].statut}`,
                  type: Discord.ActivityType.Listening,
                },
              ],
            });
          }

          if(req[0].type == 'Watching') {
            bot.user.setPresence({
              activities: [
                {
                  name: `${req[0].statut}`,
                  type: Discord.ActivityType.Watching,
                },
              ],
            });
          }
        if(req[0].type == 'watching') {
            bot.user.setPresence({
              activities: [
                {
                  name: `${req[0].statut}`,
                  type: Discord.ActivityType.Watching,
                },
              ],
            });
          }
      })
    }, 30000)

setInterval(async () => {
    for (const guild of bot.guilds.cache.values()) {
      const req = await bot.db.query(`SELECT * FROM gain WHERE guildId = "${guild.id}"`);
      const gain = req[0];
      if (!gain) continue;
      bot.db.updateBuildingIncome(guild.id, {
        bar: gain.bar,
        garage: gain.garage,
        magasin: gain.magasin,
        cinema: gain.cinema,
        gare: gain.gare,
        mairie: gain.mairie
      });
    }
}, ms("180m"))


  }
}
