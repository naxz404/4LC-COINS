const Discord = require('discord.js');
const { addXp } = require('../../utils/xp');
const { toV2 } = require("../../utils/embedV2.js");

module.exports = {
  name: 'ready',
  async execute(bot) {
    setInterval(async () => {
      for (const guild of bot.guilds.cache.values()) {
        const [gains, xpConfigs, logs] = await Promise.all([
          bot.db.query(`SELECT * FROM gain WHERE guildId = '${guild.id}'`),
          bot.db.query(`SELECT * FROM xp WHERE guildId = '${guild.id}'`),
          bot.db.query(`SELECT * FROM logs WHERE guildId = '${guild.id}'`)
        ]);
        const gain = gains[0];
        if (!gain) continue;
        const allowed = (gain.voiceChannels || '').split(',').filter(Boolean);
        for (const member of guild.members.cache.values()) {
          const state = member.voice;
          if (member.user.bot || !state?.channel || (allowed.length && !allowed.includes(state.channel.id))) continue;
          const user = await bot.db.query(`SELECT * FROM user WHERE guildId = '${guild.id}' AND userId = '${member.id}'`);
          if (!user.length || user[0].vocal === 'off') continue;
          const camera = Boolean(state.selfVideo || state.selfCamera);
          const stream = Boolean(state.streaming);
          const coins = camera && stream ? Number(gain.cam) + Number(gain.stream) : camera ? Number(gain.cam) : stream ? Number(gain.stream) : Number(gain.vocal);
          if (coins > 0) {
            await bot.db.query(`UPDATE user SET coins = coins + ${coins} WHERE guildId = '${guild.id}' AND userId = '${member.id}'`);
            const logChannel = guild.channels.cache.get(logs[0]?.logsvocal);
            if (logChannel?.isTextBased()) {
              const activity = camera && stream ? 'vocal, caméra et stream' : camera ? 'caméra' : stream ? 'stream' : 'vocal';
              await logChannel.send(toV2({ embeds: [new Discord.EmbedBuilder().setColor(user[0].color || 'LightGrey').setAuthor({ name: member.user.username, iconURL: member.user.displayAvatarURL({ dynamic: true }) }).setDescription(`${member} vient de gagner \`${coins} coins\` en ${activity}.`).setTimestamp()] })).catch(() => {});
            }
          }
          if (xpConfigs[0]?.xp !== 'off') await addXp(bot, member, Number(xpConfigs[0]?.vocal), 'activité vocale');
        }
      }
    }, 15 * 60 * 1000);
  }
};
