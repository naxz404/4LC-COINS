// Suivi du temps vocal pour la commande &stats / s&u
// Toutes les minutes, ajoute 60s à chaque membre actuellement en vocal
// (guildId, userId, date UTC, channelId), sur le même principe que
// events/ready/voccoins.js déjà présent dans le bot.

const TICK_MS = 60 * 1000;

function todayUTC() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

module.exports = {
  name: "ready",
  async execute(bot) {
    setInterval(async () => {
      const date = todayUTC();

      for (const guild of bot.guilds.cache.values()) {
        const guildId = guild.id;

        for (const member of guild.members.cache.values()) {
          const state = member.voice;
          if (member.user.bot || !state?.channel) continue;

          const userId = member.id;
          const channelId = state.channel.id;

          const existing = await bot.db.query(
            `SELECT * FROM activityVoice WHERE guildId = '${guildId}' AND userId = '${userId}' AND date = '${date}' AND channelId = '${channelId}'`
          );

          if (existing.length) {
            await bot.db.query(
              `UPDATE activityVoice SET seconds = seconds + 60 WHERE guildId = '${guildId}' AND userId = '${userId}' AND date = '${date}' AND channelId = '${channelId}'`
            );
          } else {
            await bot.db.query(
              `INSERT INTO activityVoice (guildId, userId, date, channelId, seconds) VALUES ('${guildId}', '${userId}', '${date}', '${channelId}', '60')`
            );
          }
        }
      }
    }, TICK_MS);
  }
};
