const fs = require("fs");
const path = require("path");
const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");
const { detectChanges } = require("../../utils/codeWatch.js");

const GUILD_DIR = path.join(__dirname, "..", "..", "data", "guilds");

function listGuildIds() {
    if (!fs.existsSync(GUILD_DIR)) return [];
    return fs.readdirSync(GUILD_DIR)
        .filter((f) => f.endsWith(".json"))
        .map((f) => f.replace(/\.json$/, ""));
}

// Regroupe une liste d'éléments dans une chaîne, sans dépasser une taille max
// (les champs d'embed Discord sont limités à 1024 caractères).
function joinCapped(list, max = 950) {
    let out = "";
    let shown = 0;
    for (const item of list) {
        const next = out ? `${out}, ${item}` : item;
        if (next.length > max) break;
        out = next;
        shown++;
    }
    if (shown < list.length) out += ` *(+${list.length - shown} autre(s))*`;
    return out;
}

function buildRestartEmbed(bot, report) {
    const embed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${bot.user.username} — Redémarrage détecté`, iconURL: bot.user.displayAvatarURL({ dynamic: true }) })
        .setColor("Blurple")
        .setTimestamp()
        .setFooter({ text: "Suivi des mises à jour • configmise" });

    if (report.isFirstRun) {
        embed.setDescription("🔄 Le bot vient de démarrer !\n*Premier démarrage avec le suivi des mises à jour activé sur ce serveur — les prochains redémarrages afficheront les changements de code détectés.*");
        return embed;
    }

    if (!report.hasChanges) {
        embed.setDescription("🔄 Le bot vient de redémarrer.\n✅ Aucun changement de code détecté depuis le dernier démarrage.");
        return embed;
    }

    embed.setDescription("🔄 Le bot vient de redémarrer, avec des changements détectés dans le code !");

    const { commands, other } = report;

    if (commands.added.length) embed.addFields({ name: "🆕 Commandes ajoutées", value: joinCapped(commands.added), inline: false });
    if (commands.modified.length) embed.addFields({ name: "✏️ Commandes modifiées", value: joinCapped(commands.modified), inline: false });
    if (commands.removed.length) embed.addFields({ name: "🗑️ Commandes supprimées", value: joinCapped(commands.removed), inline: false });

    if (other.added.length) embed.addFields({ name: "🆕 Fichiers ajoutés (events/utils/handlers)", value: joinCapped(other.added), inline: false });
    if (other.modified.length) embed.addFields({ name: "✏️ Fichiers modifiés (events/utils/handlers)", value: joinCapped(other.modified), inline: false });
    if (other.removed.length) embed.addFields({ name: "🗑️ Fichiers supprimés (events/utils/handlers)", value: joinCapped(other.removed), inline: false });

    return embed;
}

module.exports = {
    name: "ready",
    once: true,
    async execute(bot) {
        // Petit délai pour laisser le temps aux guilds/salons d'être bien en cache
        setTimeout(async () => {
            let report;
            try {
                report = detectChanges();
            } catch (error) {
                console.error("[CodeWatch]", error);
                return;
            }

            for (const guildId of listGuildIds()) {
                try {
                    const guild = bot.guilds.cache.get(guildId);
                    if (!guild) continue;

                    const rows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${guildId}"`);
                    const g = rows[0];
                    if (!g || g.updateEnabled !== "on" || !g.updateChannelId) continue;

                    const channel = guild.channels.cache.get(g.updateChannelId);
                    if (!channel) continue;

                    const embed = buildRestartEmbed(bot, report);
                    channel.send(toV2({ embeds: [embed] })).catch(() => {});
                } catch (error) {
                    console.error("[CodeWatch]", error);
                }
            }
        }, 5000);
    }
};
