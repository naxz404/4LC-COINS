// Permet de lancer la commande stats avec le texte exact "s&u",
// en plus du classique "&stats" (géré par commandHandler.js).
const statsCommand = require("../../commands/utilitaire/stats.js");

module.exports = {
    name: "messageCreate",
    async execute(message, bot) {
        if (!message.guild || message.author.bot) return;

        const content = message.content.trim().toLowerCase();
        if (content !== "s&u") return;

        let color = "LightGrey";
        const userRow = await bot.db.query(
            `SELECT * FROM user WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`
        );
        if (userRow.length) color = userRow[0].color || "LightGrey";

        await statsCommand.run(bot, message, [], color);
    }
};
