const { addXp, parseChannelConfig } = require('../../utils/xp');

const cooldowns = new Map();

module.exports = {
  name: 'messageCreate',
  async execute(message, bot) {
    if (!message.guild || message.author.bot || !message.member) return;
    const guildRows = await bot.db.query(`SELECT * FROM guild WHERE guildId = '${message.guild.id}'`);
    const prefix = guildRows[0]?.prefix || '&';
    if (message.content.startsWith(prefix)) return;

    const config = await bot.db.query(`SELECT * FROM xp WHERE guildId = '${message.guild.id}'`);
    const xp = config[0];
    if (!xp || xp.xp === 'off') return;

    // Respecte le &msg (opt-out des gains sur message, comme &vocal pour le vocal)
    const userRow = await bot.db.query(`SELECT * FROM user WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
    if (!userRow.length || userRow[0].msg === 'off') return;

    const channelConfig = parseChannelConfig(xp.channelConfig);
    const override = channelConfig[message.channel.id];

    let amount, cooldownMs;

    if (override) {
      // Ce salon a une config dédiée (gain + temps) -> elle prime sur tout le reste
      amount = Number(override.amount);
      cooldownMs = Number(override.cooldown || 60) * 1000;
    } else {
      // Sinon on retombe sur la config globale + liste blanche de salons classique
      const allowed = (xp.messageChannels || '').split(',').filter(Boolean);
      if (allowed.length && !allowed.includes(message.channel.id)) return;
      amount = Number(xp.msg);
      cooldownMs = Number(xp.msgCooldown || 60) * 1000;
    }

    if (!(amount > 0)) return;

    const key = `${message.guild.id}:${message.author.id}:${message.channel.id}`;
    const last = cooldowns.get(key);
    if (last && Date.now() - last < cooldownMs) return;
    cooldowns.set(key, Date.now());

    await addXp(bot, message.member, amount, 'message');
  }
};
