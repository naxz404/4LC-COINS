const Discord = require("discord.js");
const { createUserProfile } = require("../../utils/profile.js");
const { toV2 } = require("../../utils/embedV2.js");
module.exports = {
  'name': "messageCreate",
  async 'execute'(message, bot) {
    if (!message.guild) {
      return;
    }
    if (message.author.bot) {
      return;
    }
    const guildRows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`);
    const prefix = guildRows[0]?.prefix || '&';
    message.prefix = prefix;
    if (message.content == '<@' + bot.user.id + '>') {
      message.reply(":star: Mon prefix sur ce serveur est : " + prefix);
    }
    let _0x42e814 = prefix;
    if (_0x42e814 == undefined) {
      _0x42e814 = '&';
    }
    if (message.author.bot) {
      return;
    }
    let _0x2ae75e = message.content.split(" ");
    let _0x14795f = _0x2ae75e[0x0].toLowerCase();
    let _0x556d27 = _0x2ae75e.slice(0x1);
    if (!_0x14795f.startsWith(_0x42e814)) {
      return;
    }
    let _0x31bcf1;
    if (_0x14795f.startsWith(_0x42e814)) {
      _0x31bcf1 = _0x14795f.slice(_0x42e814.length);
    }
    await bot.db.query("SELECT * FROM user WHERE guildId = \"" + message.guild.id + "\" AND userId = \"" + message.author.id + "\"", async (_0x2272c4, req) => {
      if (req.length < 0x1) {
        if (message.content == _0x42e814 + "start") {
          createUserProfile(bot, message.guild.id, message.author.id);
          // Confirmation de création du profil
          const welcome = new Discord.EmbedBuilder()
            .setTitle("✅ Profil créé !")
            .setDescription(
              `Bienvenue ${message.author}, ton profil économique vient d'être créé.\n\n` +
              `Tu peux dès maintenant jouer et gagner des coins !\n` +
              `• \`${_0x42e814}daily\` pour ta récompense quotidienne\n` +
              `• \`${_0x42e814}work\` pour travailler\n` +
              `• \`${_0x42e814}help\` pour voir toutes les commandes`
            )
            .setColor("Green")
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }));
          return message.reply(toV2({ embeds: [welcome] })).catch(() => {});
        } else {
          return message.reply("Tu n'as pas commencé ta partie, fais la commande `" + _0x42e814 + "start`");
        }
      } else {
        bot.db.query("SELECT * FROM commands WHERE guildId = \"" + message.guild.id + "\"", async (_0xfc1f44, req) => {
          if (req.length < 0x1) {
            return;
          }
          if (req[0x0].adds == "off") {
            if (_0x31bcf1 == "add") {
              return message.reply(":x: Cette commande est désactivé du serveur !");
            }
          } else {
            if (req[0x0].remove == "off") {
              if (_0x31bcf1 == "remove") {
                return message.reply(":x: Cette commande est désactivé du serveur !");
              }
            } else {
              if (req[0x0].reset == "off") {
                if (_0x31bcf1 == "reset") {
                  return message.reply(":x: Cette commande est désactivé du serveur !");
                }
              }
            }
          }
          let _0x34e7d5 = bot.commands.get(_0x31bcf1);
          if (!_0x34e7d5) {
            return;
          }
          bot.db.query("SELECT * FROM commandBlock WHERE guildId = " + message.guild.id + " AND channelId = " + message.channel.id, async (_0x242fae, _0x7d14be) => {
            if (_0x7d14be.length >= 0x1) {
              const req = _0x7d14be[0x0].statut;
              if (req == "off") {
                return;
              }
            }
            let _0x108ab8 = "LightGrey";
            await bot.db.query("SELECT * FROM user WHERE guildId = \"" + message.guild.id + "\" AND userId = \"" + message.author.id + "\"", async (_0x1e7fb1, _0x7cc777) => {
              _0x108ab8 = _0x7cc777[0x0].color;
              const guildSettings = await bot.db.query("SELECT * FROM guild WHERE guildId = \"" + message.guild.id + "\"");
              const settings = guildSettings[0];
              bot.footer = settings?.footerEnabled === 'off' ? null : { text: settings?.footer || '4LC Coins', iconURL: 'https://cdn.discordapp.com/embed/avatars/0.png' };
              if (_0x34e7d5) {
                if (bot.config.ownerId.includes(message.author.id)) {
                  _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                } else {
                  if (_0x34e7d5.help.permission == "administrator") {
                    if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) {
                      return message.channel.send("`❌` Vous devez être `administrateur` pour utiliser cette commande !");
                    }
                  } else {
                    if (_0x34e7d5.help.permission == "whiteList") {
                      bot.db.query("SELECT * FROM list WHERE guildId = \"" + message.guild.id + "\" AND whitelistId = \"" + message.author.id + "\"", async (_0x49ed22, _0x2dafc0) => {
                        if (_0x2dafc0.length < 0x1) {
                          bot.db.query("SELECT * FROM list2 WHERE guildId = \"" + message.guild.id + "\" AND ownerId = \"" + message.author.id + "\"", async (_0x576d07, _0x3efe18) => {
                            if (_0x3efe18.length < 0x1) {
                              return message.channel.send("`❌` Vous devez être `whitelist` pour utiliser cette commande !");
                            } else {
                              _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                            }
                          });
                        } else {
                          _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                        }
                      });
                    } else {
                      if (_0x34e7d5.help.permission == "owner") {
                        bot.db.query("SELECT * FROM list2 WHERE guildId = \"" + message.guild.id + "\" AND ownerId = \"" + message.author.id + "\"", async (_0xa2c73b, _0x318cdf) => {
                          if (_0x318cdf.length < 0x1) {
                            return message.channel.send("`❌` Vous devez être `owner` pour utiliser cette commande !");
                          } else {
                            _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                          }
                        });
                      } else {
                        if (_0x34e7d5.help.permission == "buyer") {
                          if (bot.config.ownerId.includes(message.author.id)) {
                            _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                          } else {
                            return;
                          }
                        } else {
                          _0x34e7d5.run(bot, message, _0x556d27, _0x108ab8);
                        }
                      }
                    }
                  }
                }
              }
            });
          });
        });
      }
    });
  }
};
