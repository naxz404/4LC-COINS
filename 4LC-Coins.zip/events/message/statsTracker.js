// Suivi des messages pour la commande &stats / s&u
// Compte chaque message (guildId, userId, date UTC, channelId) pour permettre
// les statistiques 1j / 7j / 14j comme sur Statbot.

function todayUTC() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

module.exports = {
  name: "messageCreate",
  async execute(message, bot) {
    if (!message.guild || message.author.bot) return;

    const guildId = message.guild.id;
    const userId = message.author.id;
    const channelId = message.channel.id;
    const date = todayUTC();

    const existing = await bot.db.query(
      `SELECT * FROM activityMessage WHERE guildId = '${guildId}' AND userId = '${userId}' AND date = '${date}' AND channelId = '${channelId}'`
    );

    if (existing.length) {
      await bot.db.query(
        `UPDATE activityMessage SET count = count + 1 WHERE guildId = '${guildId}' AND userId = '${userId}' AND date = '${date}' AND channelId = '${channelId}'`
      );
    } else {
      await bot.db.query(
        `INSERT INTO activityMessage (guildId, userId, date, channelId, count) VALUES ('${guildId}', '${userId}', '${date}', '${channelId}', '1')`
      );
    }
  }
};
