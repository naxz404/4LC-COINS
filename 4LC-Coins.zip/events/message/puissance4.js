const { hasProfile } = require("../../utils/profile.js");

// ID du bot Puissance 4 Official à écouter
const PUISSANCE4_BOT_ID = "746476061436542997";

// Récompense / pénalité en coins (modifiable ici)
const WIN_REWARD = 50;
const LOSE_PENALTY = 20;

// Format exact envoyé par le bot Puissance 4 en fin de partie :
// "@Gagnant gagne la partie contre @Perdant !"
const RESULT_REGEX = /<@!?(\d{15,25})>\s+gagne\s+la\s+partie\s+contre\s+<@!?(\d{15,25})>\s*!/i;

// Mots-clés (insensibles à la casse) utilisés en secours si le format ci-dessus ne matche pas
// (ex: autres formulations possibles du bot comme un match nul, un abandon, etc.)
const WIN_KEYWORDS = /gagn|remport|victoire|vainqueur|a\s+battu|félicitation/i;
const LOSE_KEYWORDS = /perdu|perdant|défaite|defaite|éliminé/i;

// Le bot Puissance 4 envoie PLUSIEURS messages pour annoncer le résultat d'une même partie
// (le message de résultat dans le salon + un message de confirmation/reply juste après).
// On mémorise les salons déjà récompensés pour ne créditer/débiter qu'une seule fois par partie.
// Chaque partie se déroule dans un salon temporaire supprimé après ~2 minutes, donc on nettoie
// l'entrée après ce délai pour éviter toute fuite mémoire.
const rewardedChannels = new Set();
const CHANNEL_LOCK_TTL_MS = 3 * 60 * 1000; // 3 minutes de marge

// Récupère tout le texte exploitable d'un message (contenu + embeds)
function extractText(message) {
  let text = message.content || "";

  for (const embed of message.embeds) {
    if (embed.title) text += `\n${embed.title}`;
    if (embed.description) text += `\n${embed.description}`;
    if (embed.footer?.text) text += `\n${embed.footer.text}`;
    if (embed.author?.name) text += `\n${embed.author.name}`;
    for (const field of embed.fields || []) {
      text += `\n${field.name}\n${field.value}`;
    }
  }

  return text;
}

// Découpe le texte en "morceaux" (lignes / phrases) pour associer chaque mention à un mot-clé proche
function splitChunks(text) {
  return text.split(/\n|(?<=[.!?])\s+/).filter(Boolean);
}

module.exports = {
  name: "messageCreate",
  async execute(message, bot) {
    try {
      if (!message.guild) return;
      if (message.author.id !== PUISSANCE4_BOT_ID) return;

      const text = extractText(message);
      if (!text.trim()) return;

      let winnerId = null;
      let loserId = null;

      // 1) Format exact confirmé : "@X gagne la partie contre @Y !"
      const exactMatch = text.match(RESULT_REGEX);
      if (exactMatch) {
        winnerId = exactMatch[1];
        loserId = exactMatch[2];
      } else {
        // 2) Secours : détection par mots-clés si jamais le bot envoie une autre formulation
        const allMentionIds = [...new Set([...text.matchAll(/<@!?(\d{15,25})>/g)].map((m) => m[1]))];
        if (allMentionIds.length < 1) return;

        const chunks = splitChunks(text);
        for (const chunk of chunks) {
          const mentionsInChunk = [...chunk.matchAll(/<@!?(\d{15,25})>/g)].map((m) => m[1]);
          if (mentionsInChunk.length === 0) continue;

          if (WIN_KEYWORDS.test(chunk) && !winnerId) {
            winnerId = mentionsInChunk[0];
          }
          if (LOSE_KEYWORDS.test(chunk) && !loserId) {
            loserId = mentionsInChunk[0];
          }
        }

        if (winnerId && !loserId) {
          loserId = allMentionIds.find((id) => id !== winnerId) || null;
        } else if (loserId && !winnerId) {
          winnerId = allMentionIds.find((id) => id !== loserId) || null;
        }
      }

      // Rien de détecté avec certitude -> on ignore (ex: message "Bienvenue dans le salon de votre partie")
      if (!winnerId && !loserId) return;

      // Le bot Puissance 4 envoie plusieurs messages de résultat pour la même partie dans le même
      // salon (résultat + confirmation). On ne récompense qu'une seule fois par salon.
      const channelId = message.channel.id;
      if (rewardedChannels.has(channelId)) return;
      rewardedChannels.add(channelId);
      setTimeout(() => rewardedChannels.delete(channelId), CHANNEL_LOCK_TTL_MS);

      // Le bot Puissance 4 lui-même ne doit jamais être crédité/débité (parties perdues contre le bot)
      if (winnerId === PUISSANCE4_BOT_ID) winnerId = null;
      if (loserId === PUISSANCE4_BOT_ID) loserId = null;

      const guildId = message.guild.id;
      const lines = [];

      const checks = [];

      if (winnerId) {
        checks.push(new Promise((resolve) => {
          hasProfile(bot, guildId, winnerId, (exists) => {
            if (exists) {
              bot.db.query(`UPDATE user SET coins = coins + ${WIN_REWARD} WHERE guildId = "${guildId}" AND userId = "${winnerId}"`);
              lines.push(`🏆 <@${winnerId}> a gagné la partie de Puissance 4 et remporte **${WIN_REWARD} coins** !`);
            }
            resolve();
          });
        }));
      }

      if (loserId) {
        checks.push(new Promise((resolve) => {
          hasProfile(bot, guildId, loserId, (exists) => {
            if (!exists) return resolve();
            // Note : la mini base JSON ne comprend pas la syntaxe SQL GREATEST(...).
            // On calcule donc le résultat nous-mêmes en JS pour ne jamais stocker
            // autre chose qu'un nombre (sinon ça finit en "NaN" dans les coins).
            bot.db.query(`SELECT * FROM user WHERE guildId = "${guildId}" AND userId = "${loserId}"`, (err, req) => {
              if (err || !req.length) return resolve();
              const newCoins = Math.max(Number(req[0].coins || 0) - LOSE_PENALTY, 0);
              bot.db.query(`UPDATE user SET coins = ${newCoins} WHERE guildId = "${guildId}" AND userId = "${loserId}"`);
              lines.push(`💸 <@${loserId}> a perdu la partie et perd **${LOSE_PENALTY} coins**.`);
              resolve();
            });
          });
        }));
      }

      await Promise.all(checks);

      if (lines.length) {
        message.channel.send({ content: lines.join("\n") }).catch(() => {});
      }
    } catch (error) {
      console.error("[Puissance4]", error);
    }
  }
};

