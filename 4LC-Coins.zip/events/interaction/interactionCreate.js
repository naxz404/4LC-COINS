const Discord = require("discord.js");
const { createUserProfile } = require("../../utils/profile.js");
const { toV2 } = require("../../utils/embedV2.js");

// Salon où le bot ping le membre + envoie le message de bienvenue après avoir reçu le rôle "accès coins"
const WELCOME_CHANNEL_ID = ""; // mets l'ID de ton salon de bienvenue ici

module.exports = {
  name: "interactionCreate",
  async execute(interaction, bot) {
    try {
      if (bot.isManagedBot) return;

      // ---- Bouton "acces" : donne un rôle au clic (persistant, marche même après redémarrage) ----
      if (interaction.isButton() && interaction.customId.startsWith("acces_getrole_")) {
        const roleId = interaction.customId.replace("acces_getrole_", "");
        const role = interaction.guild?.roles.cache.get(roleId);

        if (!role) {
          return interaction.reply({ content: "`❌` Ce rôle n'existe plus sur le serveur.", ephemeral: true }).catch(() => {});
        }

        try {
          // ---- Toggle : si le membre a déjà le rôle, on le retire (accès désactivé) ----
          if (interaction.member.roles.cache.has(roleId)) {
            await interaction.member.roles.remove(role);
            return interaction.reply({ content: `\`➖\` Le rôle ${role} t'a été retiré.`, ephemeral: true });
          }

          await interaction.member.roles.add(role);

          // ---- Crée automatiquement le profil coins de l'utilisateur (plus besoin de &start) ----
          createUserProfile(bot, interaction.guild.id, interaction.user.id);

          // ---- Ping + message de bienvenue dans le salon dédié ----
          try {
            const guildRows = await bot.db.query(`SELECT * FROM guild WHERE guildId = '${interaction.guild.id}'`);
            const prefix = guildRows[0]?.prefix || '&';
            const welcomeChannel = interaction.guild.channels.cache.get(WELCOME_CHANNEL_ID);
            if (welcomeChannel) {
              const welcomeEmbed = new Discord.EmbedBuilder()
                .setTitle(`🎉 Bienvenue dans l'économie !`)
                .setDescription(
                  `Ton profil vient d'être créé automatiquement, tu peux dès maintenant jouer et gagner des coins !\n\n` +
                  `Fais \`${prefix}help\` pour voir toutes les commandes disponibles.`
                )
                .setColor("Green")
                .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

              await welcomeChannel.send(toV2({ content: `${interaction.user}`, embeds: [welcomeEmbed] }));
            }
          } catch (error) {
            console.error(error);
          }

          return interaction.reply({ content: `\`➕\` Le rôle ${role} t'a été attribué !`, ephemeral: true });
        } catch (error) {
          console.error(error);
          return interaction.reply({ content: "`❌` Impossible de modifier ce rôle (le bot n'a peut-être pas la permission ou son rôle est trop bas dans la hiérarchie).", ephemeral: true }).catch(() => {});
        }
      }

      if (!interaction.isChatInputCommand()) return;

      // Les commandes slash (/) sont entierement desactivees sur ce bot.
      return interaction.reply({ content: "`❌` Les commandes `/` sont desactivees sur ce bot.", ephemeral: true });
    } catch (error) {
      console.error(error);
      const payload = { content: "Une erreur est arrivee pendant la commande manager.", ephemeral: true };
      if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {});
      else await interaction.reply(payload).catch(() => {});
    }
  }
};
