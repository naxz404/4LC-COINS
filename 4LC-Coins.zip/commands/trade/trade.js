const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js")
const { sendCoinLog } = require("../../utils/logs.js")
const { JOBS, JOB_KEYS, jobValue, jobInfo, compareOffers } = require("../../utils/tradeValues.js")

exports.help = {
    name: "trade",
    category: "trade",
    aliases: ["echange", "échange"],
    description: "Propose un échange (métier, capacité ou argent) à un autre joueur",
    usage: "trade @user"
}

function formatOffer(offer) {
    if (!offer) return "*Aucune offre pour le moment*";
    if (offer.type === "coins") return `🪙 \`${offer.amount} coins\``;
    const info = jobInfo(offer.key);
    if (!info) return "?";
    return `${info.emoji} **${info.label}** *(${info.slot === "metier" ? "métier" : "capacité"} — valeur \`${jobValue(offer.key)} coins\`)*`;
}

function buildGuideEmbed(bot, color) {
    return new Discord.EmbedBuilder()
        .setAuthor({ name: `🔄 Comment fonctionne ${message.prefix || '&'}trade ?`, iconURL: bot.user.displayAvatarURL({ dynamic: true }) })
        .setDescription("Échange de l'argent, un métier ou une capacité avec un autre joueur, en toute sécurité.")
        .addFields(
            { name: "1️⃣ Lancer un échange", value: `\`${message.prefix || '&'}trade @user\` — ouvre un panneau visible par toi et la personne visée.` },
            { name: "2️⃣ Choisir son offre", value: "Chacun utilise le menu déroulant sous le panneau :\n🪙 **Proposer de l'argent** — entre un montant\n💼 **Proposer un métier/capacité** — uniquement parmi ce que tu possèdes déjà" },
            { name: "3️⃣ Vérifier l'équilibre", value: `Le bot indique en direct si l'échange est ⚖️ équilibré ou si quelqu'un est avantagé, en se basant sur \`${message.prefix || '&'}value\`.` },
            { name: "4️⃣ Confirmer", value: "Chacun clique sur ✅ **Confirmer mon offre**. Dès que les **deux** ont confirmé, l'échange est exécuté automatiquement." },
            { name: "↩️ Changer d'avis", value: "🗑️ **Retirer mon offre** pour recommencer, ou ❌ **Annuler l'échange** pour tout stopper (n'importe qui des deux peut le faire)." },
            { name: "📊 Voir les valeurs", value: `\`${message.prefix || '&'}value\` affiche la table complète, et \`${message.prefix || '&'}value braqueur 3000\` simule une comparaison sans lancer de vrai échange.` }
        )
        .setColor(color)
        .setFooter({ text: `Exemple : ${message.prefix || '&'}trade @Alex • Le panneau expire après 5 minutes d'inactivité` });
}

exports.run = async (bot, message, args, color) => {
    if (!args[0] || ["help", "aide", "info", "?"].includes(args[0].toLowerCase())) {
        return message.reply(toV2({ embeds: [buildGuideEmbed(bot, color)] }));
    }

    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    if (!target) return message.reply(`:x: Mentionne le joueur avec qui tu veux échanger ! Exemple : \`${message.prefix || '&'}trade @user\`\nUtilise \`${message.prefix || '&'}trade help\` pour voir comment ça marche en détail.`);
    if (target.id === message.author.id) return message.reply(":x: Tu ne peux pas échanger avec toi-même !");
    if (target.user.bot) return message.reply(":x: Tu ne peux pas échanger avec un bot !");

    const [authorRows, targetRows] = await Promise.all([
        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`),
        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${target.id}"`)
    ]);

    if (!authorRows.length) return message.reply(":x: Tu n'as pas encore de profil ! Envoie un message pour en créer un.");
    if (!targetRows.length) return message.reply(":x: Cette personne n'a pas encore de profil !");

    const state = {
        a: { member: message.member, offer: null, confirmed: false },
        b: { member: target, offer: null, confirmed: false }
    };

    const sideOf = (userId) => {
        if (userId === state.a.member.id) return "a";
        if (userId === state.b.member.id) return "b";
        return null;
    };

    const buildContainer = (note = null) => {
        const bothSet = state.a.offer && state.b.offer;
        const cmp = bothSet ? compareOffers(state.a.offer, state.b.offer) : null;

        let balanceLine = "*En attente que les deux joueurs proposent quelque chose...*";
        if (cmp) {
            if (cmp.balanced) {
                balanceLine = "✅ **Échange équilibré !** Personne n'est avantagé.";
            } else {
                const winner = state[cmp.advantaged].member.user.username;
                const loser = state[cmp.disadvantaged].member.user.username;
                balanceLine = [
                    `🟢 **${winner}** est avantagé(e) : reçoit \`+${cmp.diff} coins\` de valeur en plus`,
                    `🔴 **${loser}** est désavantagé(e) : donne \`${cmp.diff} coins\` de valeur en trop`,
                    `*(écart de ${Math.round(cmp.ratio * 100)}%)*`
                ].join("\n");
            }
        }

        const embed = new Discord.EmbedBuilder()
            .setAuthor({ name: "🔄 Proposition d'échange" })
            .setDescription([
                note ? `> ${note}\n` : "",
                `Chacun choisit ce qu'il propose (argent, métier ou capacité), puis confirme. L'échange se fait automatiquement une fois les **deux** joueurs confirmés.`
            ].join("\n"))
            .addFields(
                { name: `${state.a.confirmed ? "✅" : "⏳"} ${state.a.member.user.username}`, value: formatOffer(state.a.offer), inline: true },
                { name: `${state.b.confirmed ? "✅" : "⏳"} ${state.b.member.user.username}`, value: formatOffer(state.b.offer), inline: true },
                { name: "⚖️ Équilibre", value: balanceLine, inline: false }
            )
            .setColor(color)
            .setFooter({ text: "Menu actif pendant 5 minutes • Chacun ne peut modifier que sa propre offre" });

        const row = new Discord.ActionRowBuilder().addComponents(
            new Discord.StringSelectMenuBuilder()
                .setCustomId("trade_action")
                .setPlaceholder("Choisir une action (concerne ta propre offre)")
                .addOptions(
                    new Discord.StringSelectMenuOptionBuilder().setLabel("Proposer de l'argent").setEmoji("🪙").setValue("money").setDescription("Définir un montant de coins à proposer"),
                    new Discord.StringSelectMenuOptionBuilder().setLabel("Proposer un métier/capacité").setEmoji("💼").setValue("job").setDescription("Choisir parmi ce que tu possèdes actuellement"),
                    new Discord.StringSelectMenuOptionBuilder().setLabel("Retirer mon offre").setEmoji("🗑️").setValue("clear").setDescription("Annuler ce que tu as proposé"),
                    new Discord.StringSelectMenuOptionBuilder().setLabel("Confirmer mon offre").setEmoji("✅").setValue("confirm").setDescription("Valider ton offre actuelle"),
                    new Discord.StringSelectMenuOptionBuilder().setLabel("Annuler l'échange").setEmoji("❌").setValue("cancel").setDescription("Annule tout l'échange pour les deux joueurs")
                )
        );

        const helpRow = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("trade_help").setLabel("Comment ça marche ?").setEmoji("❓").setStyle(Discord.ButtonStyle.Secondary)
        );

        return { embed, row, helpRow };
    };

    const { embed: initEmbed, row: initRow, helpRow: initHelpRow } = buildContainer();
    const msg = await message.reply(toV2({ embeds: [initEmbed], components: [initRow, initHelpRow] }));

    const collector = msg.createMessageComponentCollector({
        time: 300000
    });

    const refreshPanel = async (note = null) => {
        const { embed, row, helpRow } = buildContainer(note);
        await msg.edit(toV2({ embeds: [embed], components: [row, helpRow] })).catch(() => {});
    };

    const finishPanel = async (note) => {
        const { embed } = buildContainer(note);
        await msg.edit(toV2({ embeds: [embed], components: [] })).catch(() => {});
        collector.stop();
    };

    // Exécute réellement l'échange en base de données, avec re-vérification des offres.
    const executeTrade = async () => {
        const gId = message.guild.id;

        const checkOffer = async (side) => {
            const offer = state[side].offer;
            const userId = state[side].member.id;
            if (offer.type === "coins") {
                const rows = await bot.db.query(`SELECT * FROM user WHERE guildId = "${gId}" AND userId = "${userId}"`);
                return Number(rows[0]?.coins || 0) >= offer.amount;
            }
            const rows = await bot.db.query(`SELECT * FROM job WHERE guildId = "${gId}" AND userId = "${userId}"`);
            return rows[0]?.[offer.key] === "yes";
        };

        const [okA, okB] = await Promise.all([checkOffer("a"), checkOffer("b")]);
        if (!okA || !okB) {
            state.a.confirmed = false;
            state.b.confirmed = false;
            await refreshPanel(`❌ L'échange a échoué : ${!okA ? state.a.member.user.username : state.b.member.user.username} ne possède plus ce qui était proposé. Merci de refaire une offre.`);
            return;
        }

        const applyOffer = async (giverSide, receiverSide) => {
            const offer = state[giverSide].offer;
            const giverId = state[giverSide].member.id;
            const receiverId = state[receiverSide].member.id;

            if (offer.type === "coins") {
                await bot.db.query(`UPDATE user SET coins = coins - ${offer.amount} WHERE guildId = '${gId}' AND userId = '${giverId}'`);
                await bot.db.query(`UPDATE user SET coins = coins + ${offer.amount} WHERE guildId = '${gId}' AND userId = '${receiverId}'`);
                return;
            }

            const info = jobInfo(offer.key);
            const slotKeys = JOB_KEYS.filter(k => JOBS[k].slot === info.slot);

            // Le donneur perd le métier/capacité
            await bot.db.query(`UPDATE job SET ${offer.key} = 'no' WHERE guildId = '${gId}' AND userId = '${giverId}'`);

            // Le receveur libère son slot (un seul métier/une seule capacité à la fois) puis reçoit le nouveau
            for (const k of slotKeys) {
                await bot.db.query(`UPDATE job SET ${k} = 'no' WHERE guildId = '${gId}' AND userId = '${receiverId}'`);
            }
            await bot.db.query(`UPDATE job SET ${offer.key} = 'yes' WHERE guildId = '${gId}' AND userId = '${receiverId}'`);
        };

        await applyOffer("a", "b");
        await applyOffer("b", "a");

        sendCoinLog(bot, message.guild, {
            type: "Échange (trade)",
            user: state.a.member.user,
            target: state.b.member.user,
            description: `${state.a.member} a donné ${formatOffer(state.a.offer)} contre ${formatOffer(state.b.offer)} de ${state.b.member}`
        });

        await finishPanel(`✅ **Échange finalisé !**\n${state.a.member.user.username} a reçu ${formatOffer(state.b.offer)}\n${state.b.member.user.username} a reçu ${formatOffer(state.a.offer)}`);
    };

    collector.on("collect", async (interaction) => {
        if (interaction.isButton() && interaction.customId === "trade_help") {
            return interaction.reply(toV2({ embeds: [buildGuideEmbed(bot, color)], ephemeral: true }));
        }

        if (!interaction.isStringSelectMenu()) return;

        const side = sideOf(interaction.user.id);
        if (!side) {
            return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Cet échange ne te concerne pas !").setColor("Red")], ephemeral: true }));
        }

        const choix = interaction.values[0];

        if (choix === "cancel") {
            await interaction.deferUpdate().catch(() => {});
            return finishPanel(`❌ Échange annulé par **${interaction.user.username}**.`);
        }

        if (choix === "clear") {
            state[side].offer = null;
            state[side].confirmed = false;
            await interaction.deferUpdate().catch(() => {});
            return refreshPanel();
        }

        if (choix === "confirm") {
            if (!state[side].offer) {
                return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Propose d'abord quelque chose avant de confirmer !").setColor("Red")], ephemeral: true }));
            }
            state[side].confirmed = true;
            await interaction.deferUpdate().catch(() => {});

            if (state.a.confirmed && state.b.confirmed) {
                await executeTrade();
            } else {
                await refreshPanel();
            }
            return;
        }

        if (choix === "money") {
            const modal = new Discord.ModalBuilder().setCustomId("trade_money_modal").setTitle("Proposer de l'argent");
            const input = new Discord.TextInputBuilder()
                .setCustomId("trade_money_amount")
                .setLabel("Montant en coins")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder("Ex: 1500")
                .setRequired(true);
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
            await interaction.showModal(modal);

            try {
                const submitted = await interaction.awaitModalSubmit({
                    filter: (i) => i.customId === "trade_money_modal" && i.user.id === interaction.user.id,
                    time: 60000
                });

                const amount = Number(submitted.fields.getTextInputValue("trade_money_amount").trim());
                if (!Number.isFinite(amount) || amount <= 0) {
                    return submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Montant invalide !").setColor("Red")], ephemeral: true }));
                }

                state[side].offer = { type: "coins", amount: Math.floor(amount) };
                state.a.confirmed = false;
                state.b.confirmed = false;

                await submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`✅ Offre mise à jour : \`${Math.floor(amount)} coins\``).setColor("Green")], ephemeral: true }));
                await refreshPanel();
            } catch (e) {
                // Timeout modale, on ne fait rien
            }
            return;
        }

        if (choix === "job") {
            const userId = state[side].member.id;
            const jobRows = await bot.db.query(`SELECT * FROM job WHERE guildId = "${message.guild.id}" AND userId = "${userId}"`);
            const jobRow = jobRows[0] || {};
            const owned = JOB_KEYS.filter(k => jobRow[k] === "yes");

            if (!owned.length) {
                return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Tu ne possèdes aucun métier ni capacité à échanger. Propose de l'argent à la place !").setColor("Red")], ephemeral: true }));
            }

            const pickRow = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId("trade_pick_job")
                    .setPlaceholder("Choisis ce que tu veux proposer")
                    .addOptions(owned.map(k => new Discord.StringSelectMenuOptionBuilder()
                        .setLabel(JOBS[k].label)
                        .setEmoji(JOBS[k].emoji)
                        .setValue(k)
                        .setDescription(`Valeur : ${jobValue(k)} coins`)))
            );

            const pickEmbed = new Discord.EmbedBuilder().setDescription("Choisis ce que tu veux proposer dans l'échange :").setColor(color);
            const promptMsg = await interaction.reply({ ...toV2({ embeds: [pickEmbed], components: [pickRow], ephemeral: true }), fetchReply: true });

            try {
                const picked = await promptMsg.awaitMessageComponent({
                    componentType: Discord.ComponentType.StringSelect,
                    filter: (i) => i.customId === "trade_pick_job" && i.user.id === interaction.user.id,
                    time: 60000
                });

                const key = picked.values[0];
                state[side].offer = { type: "job", key };
                state.a.confirmed = false;
                state.b.confirmed = false;

                await picked.update(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`✅ Offre mise à jour : ${formatOffer(state[side].offer)}`).setColor("Green")], components: [] }));
                await refreshPanel();
            } catch (e) {
                // Timeout, aucune sélection
            }
        }
    });

    collector.on("end", (collected, reason) => {
        if (reason === "time" && !(state.a.confirmed && state.b.confirmed)) {
            finishPanel("⏱️ Échange expiré (aucune action depuis 5 minutes).").catch(() => {});
        }
    });
}
