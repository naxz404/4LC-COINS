const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js")
const { JOBS, JOB_KEYS, METIER_KEYS, CAPACITE_KEYS, REP_TO_COINS, jobValue, jobInfo, compareOffers } = require("../../utils/tradeValues.js")

exports.help = {
    name: "value",
    category: "trade",
    aliases: ["valeur", "worth"],
    description: "Affiche la valeur de référence des métiers/capacités, ou compare deux offres pour savoir si un échange est équilibré",
    usage: "value | value <métier|montant> <métier|montant>"
}

// Résout un argument en offre { type: 'coins', amount } ou { type: 'job', key }
function resolveArg(arg) {
    if (!arg) return null;
    if (!isNaN(arg) && Number(arg) > 0) return { type: "coins", amount: Number(arg) };
    const key = Object.keys(JOBS).find(k => k.toLowerCase() === arg.toLowerCase());
    if (key) return { type: "job", key };
    return null;
}

function formatOffer(offer) {
    if (!offer) return "*Rien*";
    if (offer.type === "coins") return `🪙 \`${offer.amount} coins\``;
    const info = jobInfo(offer.key);
    if (!info) return "?";
    return `${info.emoji} **${info.label}** *(${info.slot === "metier" ? "métier" : "capacité"} — \`${jobValue(offer.key)} coins\`)*`;
}

function buildTableEmbed(color) {
    const lines = (keys, title) => `${title}\n` + keys
        .slice()
        .sort((a, b) => jobValue(b) - jobValue(a))
        .map(k => `${JOBS[k].emoji} **${JOBS[k].label}** — \`${jobValue(k)} coins\` *(${JOBS[k].repPrice} rep)*`)
        .join("\n");

    return new Discord.EmbedBuilder()
        .setAuthor({ name: "📊 Table de valeurs des métiers & capacités" })
        .setDescription([
            lines(METIER_KEYS, "**Métiers** *(un seul actif à la fois)*"),
            "",
            lines(CAPACITE_KEYS, "**Capacités** *(une seule active à la fois)*"),
            "",
            `-# Taux de conversion : 1 réputation ≈ \`${REP_TO_COINS} coins\` • L'argent vaut toujours sa valeur nominale (1:1)`
        ].join("\n"))
        .setColor(color)
        .setFooter({ text: `Astuce : ${message.prefix || '&'}value <métier|montant> <métier|montant> pour comparer deux offres • ${message.prefix || '&'}trade @user pour échanger réellement` });
}

exports.run = async (bot, message, args, color) => {
    // ---- Mode 1 : pas d'arguments (ou "list") -> table de référence ----
    if (!args[0] || args[0].toLowerCase() === "list") {
        return message.reply(toV2({ embeds: [buildTableEmbed(color)] }));
    }

    // ---- Mode 2 : comparaison de deux offres ----
    if (!args[1]) {
        return message.reply(`:x: Précise deux choses à comparer ! Exemple : \`${message.prefix || '&'}value braqueur 3000\` ou \`${message.prefix || '&'}value hacker cultivateur\`\nUtilise \`${message.prefix || '&'}value\` seul pour voir la table de valeurs complète.`);
    }

    const offerA = resolveArg(args[0]);
    const offerB = resolveArg(args[1]);

    if (!offerA || !offerB) {
        const invalid = new Discord.EmbedBuilder()
            .setDescription([
                `:x: Je n'ai pas reconnu ${!offerA ? `\`${args[0]}\`` : `\`${args[1]}\``}.`,
                `Utilise un montant en coins (ex: \`3000\`) ou une clé de métier/capacité parmi : ${JOB_KEYS.map(k => `\`${k}\``).join(", ")}`
            ].join("\n"))
            .setColor(color);
        return message.reply(toV2({ embeds: [invalid] }));
    }

    const cmp = compareOffers(offerA, offerB);

    let verdict;
    if (cmp.balanced) {
        verdict = "✅ **Échange équilibré !** Ces deux offres se valent à peu près.";
    } else if (cmp.valA > cmp.valB) {
        verdict = `⚖️ **Offre 1 vaut plus** que l'Offre 2 : \`+${cmp.diff} coins\` de différence (${Math.round(cmp.ratio * 100)}% d'écart)\n👉 Celui qui donne l'Offre 2 et reçoit l'Offre 1 fait une bonne affaire.`;
    } else {
        verdict = `⚖️ **Offre 2 vaut plus** que l'Offre 1 : \`+${cmp.diff} coins\` de différence (${Math.round(cmp.ratio * 100)}% d'écart)\n👉 Celui qui donne l'Offre 1 et reçoit l'Offre 2 fait une bonne affaire.`;
    }

    const resultEmbed = new Discord.EmbedBuilder()
        .setAuthor({ name: "🧮 Simulation d'échange" })
        .addFields(
            { name: "1️⃣ Offre 1", value: formatOffer(offerA), inline: true },
            { name: "2️⃣ Offre 2", value: formatOffer(offerB), inline: true }
        )
        .setDescription(verdict)
        .setColor(cmp.balanced ? "Green" : color)
        .setFooter({ text: `Tolérance d'équilibre : 15% • Ceci est une simulation, aucun échange n'a eu lieu` });

    message.reply(toV2({ embeds: [resultEmbed] }));
}
