const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

const cooldownTime = 3 * 60 * 60;   // cooldown pour retenter un kill
const protectTime = 4 * 60 * 60;    // fenêtre de protection pour la victime après un kill réussi
const SUCCESS_CHANCE = 1 / 2;
const FAIL_PENALTY = 1;             // réputation perdue par l'attaquant en cas d'échec

const cooldownsKill = new Map();

exports.help = {
    name: "kill",
    category: "job",
    aliases: ["tuer"],
    description: "Vole des points de réputation à un autre utilisateur (métier tueur)",
    usage: "Pas d'utilisation conseillée"
}

exports.run = async (bot, message, args, color) => {

    bot.db.query(`SELECT * FROM job WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, jobReq) => {
        const notueur = new Discord.EmbedBuilder()
            .setDescription(`:x: Vous devez être **tueur** pour utiliser cette commande !\nUtilisez \`${(message.prefix || '&')}job tueur\` pour le devenir.`)
            .setColor(color)
        if (!jobReq.length || jobReq[0].tueur !== "yes") return message.channel.send(toV2({ embeds: [notueur] }))

        if (cooldownsKill.has(message.author.id + message.guild.id)) {
            const cooldownExpiration = cooldownsKill.get(message.author.id + message.guild.id) + cooldownTime;
            const remainingCooldown = cooldownExpiration - Math.floor(Date.now() / 1000);

            if (remainingCooldown > 0) {
                const hours = Math.floor(remainingCooldown / 3600);
                const minutes = Math.floor((remainingCooldown % 3600) / 60);
                const seconds = Math.floor(remainingCooldown % 60);

                const cooldownEmbed = new Discord.EmbedBuilder()
                    .setDescription(`:x: Vous avez déjà tenté un kill récemment\n\nRéessayez dans ${hours} heure(s), ${minutes} minute(s) et ${seconds} seconde(s)`)
                    .setColor(color)

                return message.reply(toV2({ embeds: [cooldownEmbed] }));
            }
        }

        const mention = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if (!mention) return message.channel.send(`:x: \`ERROR:\` Pas de membre trouvé !`)
        if (mention.id === message.author.id) return message.reply(`:x: Vous ne pouvez pas vous tuer vous-même !`)

        if (bot.antikill.has(mention.id + message.guild.id)) {
            const protectExpiration = bot.antikill.get(mention.id + message.guild.id) + protectTime;
            const remainingProtect = protectExpiration - Math.floor(Date.now() / 1000);

            if (remainingProtect > 0) {
                const hours = Math.floor(remainingProtect / 3600);
                const minutes = Math.floor((remainingProtect % 3600) / 60);
                const seconds = Math.floor(remainingProtect % 60);

                const protectEmbed = new Discord.EmbedBuilder()
                    .setDescription(`:shield: ${mention.user.username} est protégé suite à un kill récent\n\nRéessayez dans ${hours} heure(s), ${minutes} minute(s) et ${seconds} seconde(s)`)
                    .setColor(color)

                return message.reply(toV2({ embeds: [protectEmbed] }));
            }
        }

        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, authorReq) => {
            if (!authorReq.length) return message.reply(':x: Vous n\'avez pas encore commencer les coins, refaîtes la commande !')

            bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`, async (err, targetReq) => {
                if (!targetReq.length) return message.reply(':x: Cette utilisateur n\'a pas encore commencer les coins !')

                const targetRep = Number(targetReq[0].reputation || 0)

                const noReput = new Discord.EmbedBuilder()
                    .setDescription(`:x: ${mention.user.username} vous ne gagnerez rien si vous tuez cette personne, elle n'a pas de réputation !`)
                    .setColor(color)
                if (targetRep <= 0) return message.channel.send(toV2({ embeds: [noReput] }))

                cooldownsKill.set(message.author.id + message.guild.id, Math.floor(Date.now() / 1000));

                if (Math.random() < SUCCESS_CHANCE) {
                    const stolen = Math.max(1, Math.floor(Math.random() * targetRep) + 1)
                    const newTargetRep = Math.max(targetRep - stolen, 0)
                    const newAuthorRep = Number(authorReq[0].reputation || 0) + stolen

                    bot.db.query(`UPDATE user SET reputation = '${newTargetRep}' WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`)
                    bot.db.query(`UPDATE user SET reputation = '${newAuthorRep}' WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`)

                    bot.antikill.set(mention.id + message.guild.id, Math.floor(Date.now() / 1000));

                    const successEmbed = new Discord.EmbedBuilder()
                        .setDescription(`:knife: Vous avez tué ${mention} et volé \`${stolen}\` point(s) de réputation !`)
                        .setColor(color)

                    return message.reply(toV2({ embeds: [successEmbed] }))
                } else {
                    const authorRep = Number(authorReq[0].reputation || 0)
                    const newAuthorRep = Math.max(authorRep - FAIL_PENALTY, 0)
                    if (authorRep > 0) {
                        bot.db.query(`UPDATE user SET reputation = '${newAuthorRep}' WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`)
                    }

                    const failEmbed = new Discord.EmbedBuilder()
                        .setDescription(`:x: Vous avez raté votre coup sur ${mention} !${authorRep > 0 ? ` Vous perdez \`${FAIL_PENALTY}\` point de réputation.` : ''}`)
                        .setColor(color)

                    return message.reply(toV2({ embeds: [failEmbed] }))
                }
            })
        })
    })
}
