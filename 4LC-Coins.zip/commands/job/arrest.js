const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "arrest",
    category: "job",
    aliases: [],
    description: "Commande du métier policier",
    usage: "Pas d'utilisation conseillée"
}

exports.run = async (bot, message, args, color) => {
    bot.db.query(`SELECT * FROM job WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, req) => {
        const nobraqueur = new Discord.EmbedBuilder()
        .setDescription(`:x: Vous devez être **policier** pour utiliser cette commande !`)
        .setColor(color)
        if(req[0].policier == "no") return message.channel.send(toV2({ embeds: [nobraqueur] }))

        message.delete().catch(() => {})

    })
}