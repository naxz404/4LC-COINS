const Discord = require('discord.js');
const { toV2 } = require("../../utils/embedV2.js");

exports.help = { name: 'setlogs', category: 'administration', aliases: ['set-logs'], description: 'Modifie les logs', usage: 'setlogs <xp/vocal/impots/transaction> <#salon>', permission: 'whiteList' };

exports.run = async (bot, message, args, color) => {
  const types = { xp: 'logsxp', vocal: 'logsvocal', impots: 'logsimpots', transaction: 'logstransac' };
  const type = (args[0] || '').toLowerCase();
  if (!types[type]) {
    return message.channel.send(toV2({ embeds: [new Discord.EmbedBuilder().setColor(color).setTitle('Informations des logs').setDescription('`xp` : passages de palier XP\n`vocal` : gains de coins vocaux\n`impots` : impôts\n`transaction` : transactions')] }));
  }
  const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
  if (!channel || !channel.isTextBased()) return message.reply(':x: Veuillez mentionner un salon texte valide.');
  await bot.db.query(`UPDATE logs SET ${types[type]} = '${channel.id}' WHERE guildId = '${message.guild.id}'`);
  return message.channel.send(`:white_check_mark: ${channel} est maintenant le salon des logs ${type}.`);
};
