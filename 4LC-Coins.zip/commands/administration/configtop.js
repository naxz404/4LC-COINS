const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "configtop",
    category: "administration",
    aliases: ["topconfig"],
    description: "Configure l'envoi automatique quotidien du classement (topall)",
    usage: "configtop",
    permission: "whiteList"
};

exports.run = async (bot, message, args, color) => {
    const rows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`);
    const g = rows[0] || {};

    const state = {
        enabled: g.topEnabled === "on",
        hour: g.topHour || "20",
        minute: g.topMinute || "00",
        channelId: g.topChannelId || null
    };

    const buildStatus = () => new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle("⏰ Configuration de l'auto-top")
        .setDescription([
            `> 🔌 Statut : ${state.enabled ? "✅ Activé" : "❌ Désactivé"}`,
            `> 🕐 Heure : \`${state.hour}:${state.minute}\``,
            `> 📌 Salon : ${state.channelId ? `<#${state.channelId}>` : "❌ non défini"}`,
            "",
            "*Le classement (\`topall\`) sera automatiquement envoyé chaque jour à l'heure définie, si activé.*"
        ].join("\n"));

    const buildComponents = () => [
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("ct_toggle").setLabel(state.enabled ? "Désactiver" : "Activer").setStyle(state.enabled ? Discord.ButtonStyle.Danger : Discord.ButtonStyle.Success).setEmoji("🔌"),
            new Discord.ButtonBuilder().setCustomId("ct_hour").setLabel("Définir l'heure").setStyle(Discord.ButtonStyle.Secondary).setEmoji("🕐")
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ChannelSelectMenuBuilder().setCustomId("ct_channel").setPlaceholder("Choisir le salon du classement").addChannelTypes(Discord.ChannelType.GuildText)
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("ct_save").setLabel("Sauvegarder").setStyle(Discord.ButtonStyle.Success).setEmoji("💾"),
            new Discord.ButtonBuilder().setCustomId("ct_close").setLabel("Fermer").setStyle(Discord.ButtonStyle.Secondary).setEmoji("❌")
        )
    ];

    const panel = await message.reply(toV2({ embeds: [buildStatus()], components: buildComponents() }));
    const collector = panel.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "`❌` Seul l'auteur de la commande peut utiliser ce panneau !", ephemeral: true });
        }

        if (interaction.customId === "ct_close") {
            await interaction.update(toV2({ content: "`❌` Panneau fermé.", embeds: [], components: [] }));
            return collector.stop();
        }

        if (interaction.customId === "ct_toggle") {
            state.enabled = !state.enabled;
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "ct_channel") {
            state.channelId = interaction.values[0];
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "ct_hour") {
            const modalId = "ct_modal_hour";
            const modal = new Discord.ModalBuilder().setCustomId(modalId).setTitle("Heure de l'auto-top (format HH:MM)");
            const input = new Discord.TextInputBuilder()
                .setCustomId("ct_modal_input")
                .setLabel("Heure (ex: 20:00)")
                .setStyle(Discord.TextInputStyle.Short)
                .setRequired(true)
                .setValue(`${state.hour}:${state.minute}`);
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
            await interaction.showModal(modal);

            try {
                const submitted = await interaction.awaitModalSubmit({
                    filter: (i) => i.customId === modalId && i.user.id === message.author.id,
                    time: 120000
                });
                const value = submitted.fields.getTextInputValue("ct_modal_input").trim();
                const match = value.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
                if (!match) {
                    await submitted.reply({ content: ":x: Format invalide, utilisez HH:MM (ex: 20:00).", ephemeral: true });
                } else {
                    state.hour = match[1].padStart(2, "0");
                    state.minute = match[2];
                    await submitted.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
                }
            } catch (error) {
                // Timeout du modal
            }
            return;
        }

        if (interaction.customId === "ct_save") {
            if (state.enabled && !state.channelId) {
                return interaction.reply({ content: ":x: Veuillez choisir un salon avant d'activer l'auto-top.", ephemeral: true });
            }
            await bot.db.query(`UPDATE guild SET topEnabled = '${state.enabled ? "on" : "off"}', topHour = '${state.hour}', topMinute = '${state.minute}', topChannelId = '${state.channelId || ""}' WHERE guildId = '${message.guild.id}'`);
            await interaction.update(toV2({ content: "`✅` Configuration de l'auto-top sauvegardée !", embeds: [buildStatus()], components: [] }));
            return collector.stop();
        }
    });

    collector.on("end", () => {
        panel.edit({ components: [] }).catch(() => {});
    });
};
