const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "reset",
    category: "administration",
    aliases: [],
    description: "Reset le serveur où un utilisateur (user / server)",
    usage: "reset",
    permission: "owner"
}

exports.run = async (bot, message, args, color) => {

    const state = {
        mode: null,      // "all" ou "user"
        targetId: null,  // id de l'utilisateur ciblé si mode === "user"
        targetTag: null  // tag/mention affichable
    }

    const buildMainEmbed = (extra = "") => {
        const embed = new Discord.EmbedBuilder()
            .setAuthor({ name: `Panel de reset de ${message.guild.name}` })
            .setDescription(
                `\`🗑️\` **Reset serveur** — Réinitialise entièrement l'économie du serveur (coins, mines, jobs, xp, équipes...)\n` +
                `\`👤\` **Reset utilisateur** — Réinitialise uniquement le profil d'un membre\n` +
                (extra ? `\n${extra}` : "")
            )
            .setFooter({ text: `${message.author.username}`, iconURL: `${message.author.displayAvatarURL({ dynamic: true })}` })
            .setColor(color)
        return embed
    }

    const buildMenuRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.StringSelectMenuBuilder()
            .setCustomId("reset_menu")
            .setMaxValues(1)
            .setMinValues(1)
            .setPlaceholder("Choisir un type de reset")
            .addOptions(
                new Discord.StringSelectMenuOptionBuilder()
                    .setLabel("Reset serveur")
                    .setEmoji("🗑️")
                    .setValue("reset_all")
                    .setDescription("Réinitialise toute l'économie du serveur"),
                new Discord.StringSelectMenuOptionBuilder()
                    .setLabel("Reset utilisateur")
                    .setEmoji("👤")
                    .setValue("reset_user")
                    .setDescription("Réinitialise le profil d'un membre précis")
            )
    )

    const buildConfirmRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder().setCustomId("reset_confirm").setLabel("Confirmer").setEmoji("✅").setStyle(Discord.ButtonStyle.Danger),
        new Discord.ButtonBuilder().setCustomId("reset_cancel").setLabel("Annuler").setEmoji("❌").setStyle(Discord.ButtonStyle.Secondary)
    )

    const buildBackRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder().setCustomId("reset_back").setLabel("Retour").setEmoji("↩️").setStyle(Discord.ButtonStyle.Secondary)
    )

    const panel = await message.reply(toV2({ embeds: [buildMainEmbed()], components: [buildMenuRow()] }))

    const collector = panel.createMessageComponentCollector({ time: 300000 })

    collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "`❌` Seul l'auteur de la commande peut utiliser ce panneau !", ephemeral: true })
        }

        // ---- Retour au menu principal ----
        if (interaction.customId === "reset_back") {
            state.mode = null
            state.targetId = null
            state.targetTag = null
            return interaction.update(toV2({ embeds: [buildMainEmbed()], components: [buildMenuRow()] }))
        }

        // ---- Annulation ----
        if (interaction.customId === "reset_cancel") {
            state.mode = null
            state.targetId = null
            state.targetTag = null
            return interaction.update(toV2({ embeds: [buildMainEmbed("`❌` Action annulée.")], components: [buildMenuRow()] }))
        }

        // ---- Choix dans le menu ----
        if (interaction.customId === "reset_menu") {
            const choix = interaction.values[0]

            if (choix === "reset_all") {
                state.mode = "all"
                const warnEmbed = new Discord.EmbedBuilder()
                    .setTitle("⚠️ Reset du serveur")
                    .setDescription(`Êtes-vous sûr de vouloir reset l'**économie complète** de ${message.guild.name} ?\nCette action est **irréversible**.`)
                    .setColor(color)
                return interaction.update(toV2({ embeds: [warnEmbed], components: [buildConfirmRow(), buildBackRow()] }))
            }

            if (choix === "reset_user") {
                const modal = new Discord.ModalBuilder().setCustomId("reset_user_modal").setTitle("Reset d'un utilisateur")
                const input = new Discord.TextInputBuilder()
                    .setCustomId("reset_user_input")
                    .setLabel("ID ou mention de l'utilisateur à reset")
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder("Ex: 123456789012345678 ou @Membre")
                    .setRequired(true)

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(input))
                await interaction.showModal(modal)

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === "reset_user_modal" && i.user.id === message.author.id,
                        time: 120000
                    })

                    const raw = submitted.fields.getTextInputValue("reset_user_input").trim()
                    const cleanId = raw.replace(/[<@!>]/g, "")
                    const member = message.guild.members.cache.get(cleanId)

                    if (!member) {
                        return submitted.update(toV2({ embeds: [buildMainEmbed("`❌` Utilisateur introuvable, réessayez.")], components: [buildMenuRow()] }))
                    }

                    state.mode = "user"
                    state.targetId = member.id
                    state.targetTag = member.toString()

                    const warnEmbed = new Discord.EmbedBuilder()
                        .setTitle("⚠️ Reset d'un utilisateur")
                        .setDescription(`Êtes-vous sûr de vouloir reset le profil de ${state.targetTag} ?\nCette action est **irréversible**.`)
                        .setColor(color)

                    return submitted.update(toV2({ embeds: [warnEmbed], components: [buildConfirmRow(), buildBackRow()] }))
                } catch (error) {
                    // Timeout du modal : on ne fait rien
                }
                return
            }
        }

        // ---- Confirmation ----
        if (interaction.customId === "reset_confirm") {
            if (state.mode === "all") {
                await interaction.update(toV2({ embeds: [new Discord.EmbedBuilder().setDescription("♻️ Reset du serveur en cours...").setColor(color)], components: [] }))

                bot.db.query(`DELETE FROM user WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM mine WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM team WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM gain WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM batiment WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM tmembers WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM juge WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM job WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM xp WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM items WHERE guildId = ${message.guild.id}`)
                bot.db.query(`DELETE FROM cards WHERE guildId = ${message.guild.id}`)

                const doneEmbed = new Discord.EmbedBuilder()
                    .setDescription(`✅ L'économie du serveur a été reset !`)
                    .setColor(color)

                return message.channel.send(toV2({ embeds: [doneEmbed] }))
            }

            if (state.mode === "user" && state.targetId) {
                await interaction.update(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`♻️ Reset de ${state.targetTag} en cours...`).setColor(color)], components: [] }))

                bot.db.query(`DELETE FROM user WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM mine WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM batiment WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM tmembers WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM juge WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM job WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)
                bot.db.query(`DELETE FROM cards WHERE guildId = ${message.guild.id} AND userId = ${state.targetId}`)

                // Retire le rôle "accès coins" : le profil ne pourra revenir que quand on lui
                // redonnera le rôle, et il repartira alors bien à 0 (voir events/member/roleAccess.js)
                try {
                    const guildSettings = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`)
                    const accessRoleId = guildSettings[0]?.accessRoleId
                    if (accessRoleId) {
                        const targetMember = message.guild.members.cache.get(state.targetId) || await message.guild.members.fetch(state.targetId).catch(() => null)
                        if (targetMember?.roles.cache.has(accessRoleId)) {
                            await targetMember.roles.remove(accessRoleId).catch(() => {})
                        }
                    }
                } catch (error) {
                    console.error(error)
                }

                const doneEmbed = new Discord.EmbedBuilder()
                    .setDescription(`✅ ${state.targetTag} a été reset ! (rôle d'accès coins retiré, il repartira à 0 en le redonnant)`)
                    .setColor(color)

                return message.channel.send(toV2({ embeds: [doneEmbed] }))
            }

            return interaction.reply({ content: "`❌` Rien à confirmer, revenez au menu.", ephemeral: true })
        }
    })

    collector.on("end", () => {
        panel.edit({ components: [] }).catch(() => {})
    })
}
