const Discord = require('discord.js');
const { parseChannelConfig, stringifyChannelConfig } = require('../../utils/xp');
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
  name: 'setxp', category: 'administration', aliases: ['set-xp'],
  description: "Configure les gains d'expérience", usage: 'setxp <msg/vocal/off/salon>', permission: 'whiteList'
};

function validGain(value) {
  return value !== undefined && !isNaN(value) && Number(value) > 0;
}

function validTime(value) {
  return value !== undefined && !isNaN(value) && Number(value) > 0;
}

// Résout un salon texte OU une catégorie (mention ou ID) en liste de salons texte
function resolveTextChannels(message, arg) {
  const mentioned = message.mentions.channels.first();
  const target = mentioned || message.guild.channels.cache.get(arg);
  if (!target) return null;

  if (target.type === Discord.ChannelType.GuildCategory) {
    return target.children.cache.filter(c => c.isTextBased()).map(c => c);
  }
  if (target.isTextBased()) return [target];
  return null;
}

exports.run = async (bot, message, args, color) => {
  const action = (args[0] || '').toLowerCase();

  if (!action) {
    return message.channel.send(toV2({ embeds: [new Discord.EmbedBuilder().setColor(color).setTitle('Configuration XP').setDescription(
      `\`${(message.prefix || '&')}setxp msg <gain> [temps]\` — gain par message par défaut (temps en secondes, 60 par défaut)\n` +
      `\`${(message.prefix || '&')}setxp vocal <gain>\` — gain toutes les 15 minutes en vocal\n` +
      `\`${(message.prefix || '&')}setxp salon <#salon/#catégorie/id> <gain> <temps>\` — configure un salon (ou toute une catégorie d'un coup)\n` +
      `\`${(message.prefix || '&')}setxp salon remove <#salon/#catégorie/id>\` — retire la config dédiée du salon (ou catégorie)\n` +
      `\`${(message.prefix || '&')}setxp salon list\` — liste les salons ayant une config dédiée\n` +
      `\`${(message.prefix || '&')}setxp salons <add/remove/list/clear> [#salon]\` — liste blanche classique (gain par défaut uniquement)\n` +
      `\`${(message.prefix || '&')}setxp off\` — désactive l'XP`
    ).setFooter(bot.footer)] }));
  }

  if (action === 'off') {
    await bot.db.query(`UPDATE xp SET xp = 'off' WHERE guildId = '${message.guild.id}'`);
    return message.reply(':white_check_mark: Le système d’expérience est désactivé.');
  }

  if (action === 'msg' || action === 'vocal') {
    if (!validGain(args[1])) return message.reply(':x: Indiquez un gain positif valide.');

    if (action === 'msg' && args[2] !== undefined) {
      if (!validTime(args[2])) return message.reply(':x: Indiquez un temps (en secondes) positif valide.');
      await bot.db.query(`UPDATE xp SET xp = 'on', msg = '${Number(args[1])}', msgCooldown = '${Number(args[2])}' WHERE guildId = '${message.guild.id}'`);
      return message.reply(`:white_check_mark: Gain XP par message réglé sur \`${Number(args[1])}\` toutes les \`${Number(args[2])}s\` (par défaut, hors salons configurés individuellement).`);
    }

    await bot.db.query(`UPDATE xp SET xp = 'on', ${action} = '${Number(args[1])}' WHERE guildId = '${message.guild.id}'`);
    const label = action === 'msg' ? 'par message' : 'toutes les 15 minutes en vocal';
    return message.reply(`:white_check_mark: Gain XP ${label} réglé sur \`${Number(args[1])}\`.`);
  }

  // ---- Config dédiée par salon / catégorie ----
  if (action === 'salon' || action === 'salons' || action === 'channel') {
    const sub = (args[1] || '').toLowerCase();

    // Ancienne liste blanche simple (compatibilité)
    if (['add', 'remove', 'list', 'clear'].includes(sub) && (action === 'salons' || action === 'channel')) {
      const current = await bot.db.query(`SELECT * FROM xp WHERE guildId = '${message.guild.id}'`);
      let ids = (current[0]?.messageChannels || '').split(',').filter(Boolean);
      if (sub === 'list') return message.reply(ids.length ? `Salons texte XP : ${ids.map(id => `<#${id}>`).join(', ')}` : 'Tous les salons texte sont actuellement autorisés.');
      if (sub === 'clear') {
        await bot.db.query(`UPDATE xp SET messageChannels = '' WHERE guildId = '${message.guild.id}'`);
        return message.reply(':white_check_mark: Tous les salons texte sont autorisés pour l’XP.');
      }
      const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[2]);
      if (!['add', 'remove'].includes(sub) || !channel || !channel.isTextBased()) return message.reply(`Usage : \`${(message.prefix || '&')}setxp salons <add/remove/list/clear> [#salon]\``);
      if (sub === 'add' && !ids.includes(channel.id)) ids.push(channel.id);
      if (sub === 'remove') ids = ids.filter(id => id !== channel.id);
      await bot.db.query(`UPDATE xp SET messageChannels = '${ids.join(',')}' WHERE guildId = '${message.guild.id}'`);
      return message.reply(`:white_check_mark: ${channel} ${sub === 'add' ? 'est autorisé' : 'est retiré'} pour l’XP par message.`);
    }

    const current = await bot.db.query(`SELECT * FROM xp WHERE guildId = '${message.guild.id}'`);
    const channelConfig = parseChannelConfig(current[0]?.channelConfig);

    // ---- Liste des salons ayant une config dédiée ----
    if (sub === 'list') {
      const entries = Object.entries(channelConfig);
      if (!entries.length) return message.reply('Aucun salon n’a de configuration XP dédiée pour le moment.');
      const desc = entries.map(([id, cfg]) => `<#${id}> — \`${cfg.amount} xp\` toutes les \`${cfg.cooldown}s\``).join('\n');
      return message.channel.send(toV2({ embeds: [new Discord.EmbedBuilder().setColor(color).setTitle('Salons avec config XP dédiée').setDescription(desc)] }));
    }

    // ---- Retrait de la config dédiée d'un salon / d'une catégorie ----
    if (sub === 'remove') {
      const channels = resolveTextChannels(message, args[2]);
      if (!channels || !channels.length) return message.reply(':x: Salon ou catégorie introuvable.');
      for (const c of channels) delete channelConfig[c.id];
      await bot.db.query(`UPDATE xp SET channelConfig = '${stringifyChannelConfig(channelConfig).replace(/'/g, "\\'")}' WHERE guildId = '${message.guild.id}'`);
      return message.reply(`:white_check_mark: Config XP dédiée retirée pour ${channels.map(c => c.toString()).join(', ')}.`);
    }

    // ---- Ajout / mise à jour : &setxp salon <#salon|#catégorie|id> <gain> <temps> ----
    const targetArg = args[1];
    const gainArg = args[2];
    const timeArg = args[3];

    if (!validGain(gainArg) || !validTime(timeArg)) {
      return message.reply(`Usage : \`${(message.prefix || '&')}setxp salon <#salon/#catégorie/id> <gain> <temps_en_secondes>\``);
    }

    const channels = resolveTextChannels(message, targetArg);
    if (!channels || !channels.length) return message.reply(':x: Salon ou catégorie introuvable (ou catégorie sans salon texte).');

    for (const c of channels) {
      channelConfig[c.id] = { amount: Number(gainArg), cooldown: Number(timeArg) };
    }

    await bot.db.query(`UPDATE xp SET xp = 'on', channelConfig = '${stringifyChannelConfig(channelConfig).replace(/'/g, "\\'")}' WHERE guildId = '${message.guild.id}'`);

    return message.reply(`:white_check_mark: Config XP appliquée à ${channels.length > 1 ? `**${channels.length} salons**` : channels[0].toString()} : \`${Number(gainArg)} xp\` toutes les \`${Number(timeArg)}s\`.`);
  }

  return message.reply(`Usage : \`${(message.prefix || '&')}setxp <msg/vocal/off/salon>\``);
};
