const Discord = require("discord.js");
const managerStore = require("../../utils/managerStore");
const { activeClients, inviteUrl, startManagedBot, stopManagedBot } = require("../../utils/managedBots");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
  name: "mybot",
  category: "administration",
  aliases: ["my-bot", "bot"],
  description: "Active et gere ton bot manager 4LC",
  usage: "mybot <status|activer|stop|restart|token|transfer|key|keys>",
  managerOnly: true
};

exports.data = new Discord.SlashCommandBuilder()
  .setName("mybot")
  .setDescription("Active et gere ton bot manager 4LC")
  .addSubcommand((subcommand) => subcommand
    .setName("status")
    .setDescription("Voir tes bots clients et leur lien d'invitation"))
  .addSubcommand((subcommand) => subcommand
    .setName("activer")
    .setDescription("Activer un bot client avec une key et un token")
    .addStringOption((option) => option.setName("key").setDescription("Key d'activation").setRequired(true))
    .addStringOption((option) => option.setName("token").setDescription("Token du bot client").setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName("stop")
    .setDescription("Arreter ton bot client"))
  .addSubcommand((subcommand) => subcommand
    .setName("restart")
    .setDescription("Redemarrer ton bot client"))
  .addSubcommand((subcommand) => subcommand
    .setName("token")
    .setDescription("Changer le token de ton bot client")
    .addStringOption((option) => option.setName("token").setDescription("Nouveau token").setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName("transfer")
    .setDescription("Transferer ton bot client a un autre utilisateur")
    .addUserOption((option) => option.setName("membre").setDescription("Nouveau proprietaire").setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName("key")
    .setDescription("Creer une key client")
    .addStringOption((option) => option
      .setName("duree")
      .setDescription("Duree de la key")
      .setRequired(true)
      .addChoices(
        { name: "1 mois", value: "1mois" },
        { name: "2 mois", value: "2mois" },
        { name: "3 mois", value: "3mois" },
        { name: "12 mois", value: "12mois" },
        { name: "Infinie", value: "infinie" }
      ))
    .addStringOption((option) => option.setName("note").setDescription("Note interne")))
  .addSubcommand((subcommand) => subcommand
    .setName("keys")
    .setDescription("Voir les dernieres keys creees"));

exports.run = async (bot, message, args, color) => {
  const action = (args[0] || "status").toLowerCase();

  if (action === "key") {
    if (!bot.config.ownerId.includes(message.author.id)) return message.reply(":x: Reserve au createur du manager.");
    const duration = args[1] || "1mois";
    if (!managerStore.durations.hasOwnProperty(duration)) {
      return message.reply(`Duree invalide. Durées: ${Object.keys(managerStore.durations).join(", ")}`);
    }
    const license = managerStore.createLicense(duration, message.author.id, args.slice(2).join(" "));
    return message.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Key creee")
          .setDescription(`Key: \`${license.key}\`\nDuree: **${duration}**\nActivation: \`${(message.prefix || '&')}mybot activer ${license.key} <token>\``)
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ]
    }));
  }

  if (action === "keys") {
    if (!bot.config.ownerId.includes(message.author.id)) return message.reply(":x: Reserve au createur du manager.");
    const licenses = managerStore.listLicenses().slice(0, 10);
    const description = licenses.length
      ? licenses.map((license) => {
        const expire = license.expiresAt ? `<t:${Math.floor(license.expiresAt / 1000)}:R>` : license.activatedAt ? "infinie" : "pas encore activee";
        const state = license.revoked ? "revoke" : license.activatedBy ? "active" : "libre";
        return `\`${license.key}\` - ${state} - ${license.duration} - ${expire}`;
      }).join("\n")
      : "Aucune key creee.";

    return message.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Keys 4LC")
          .setDescription(description)
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ]
    }));
  }

  if (action === "activer") {
    const key = (args[1] || "").toUpperCase();
    const token = args.slice(2).join(" ").trim();
    if (!key || !token) return message.reply(`Usage: \`${(message.prefix || '&')}mybot activer <key> <token>\``);

    const result = managerStore.activateLicense(key, token, message.author.id);
    if (result.error === "missing") return message.reply(":x: Key introuvable.");
    if (result.error === "revoked") return message.reply(":x: Cette key est desactivee.");
    if (result.error === "expired") return message.reply(":x: Cette key a expire.");
    if (result.error === "used") return message.reply(":x: Cette key est deja utilisee par quelqu'un d'autre.");

    try {
      await startManagedBot(result.bot, bot);
    } catch (error) {
      return message.reply(`:x: Token refuse ou bot impossible a connecter: \`${error.message}\``);
    }

    return message.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Bot active")
          .setDescription(`Ton bot 4LC se connecte. Fais \`${(message.prefix || '&')}mybot status\` pour recuperer son invitation.`)
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ]
    }));
  }

  const bots = managerStore.userBots(message.author.id);
  const current = bots[0];

  if (action === "status") {
    if (!current) return message.reply(`Tu n'as aucun bot actif. Achète-en un avec \`${(message.prefix || '&')}mybots\`.`);
    const client = activeClients.get(current.id);
    const clientId = client?.user?.id || current.clientId;
    const link = current.inviteUrl || (clientId ? inviteUrl(clientId) : null);
    const expire = current.license?.expiresAt ? `<t:${Math.floor(current.license.expiresAt / 1000)}:R>` : "infinie";

    return message.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Vos bots")
          .setDescription([
            `Bot: **${client?.user?.tag || current.tag || current.username || "Pas encore connecte"}**`,
            `Etat: **${client ? "online" : current.status}**`,
            `Key: \`${current.key}\``,
            `Expiration: ${expire}`,
            link ? `Invitation: [Inviter le bot](${link})` : "Invitation: indisponible tant que le bot n'est pas connecte",
            current.lastError ? `Erreur: \`${current.lastError}\`` : null
          ].filter(Boolean).join("\n"))
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ]
    }));
  }

  if (action === "stop") {
    if (!current) return message.reply(":x: Tu n'as aucun bot actif.");
    managerStore.stopUserBot(message.author.id, current.id);
    await stopManagedBot(current.id);
    return message.reply("Ton bot est maintenant offline.");
  }

  if (action === "restart") {
    if (!current) return message.reply(":x: Tu n'as aucun bot actif.");
    await stopManagedBot(current.id);
    try {
      await startManagedBot(current, bot);
    } catch (error) {
      return message.reply(`:x: Impossible de relancer ton bot: \`${error.message}\``);
    }
    return message.reply("Ton bot a ete relance.");
  }

  if (action === "token") {
    if (!current) return message.reply(":x: Tu n'as aucun bot actif.");
    const token = args.slice(1).join(" ").trim();
    if (!token) return message.reply(`Usage: \`${(message.prefix || '&')}mybot token <nouveau_token>\``);
    const updated = managerStore.updateBot(current.id, { token, status: "pending", lastError: null });
    await stopManagedBot(current.id);
    try {
      await startManagedBot(updated, bot);
    } catch (error) {
      return message.reply(`:x: Token refuse ou bot impossible a connecter: \`${error.message}\``);
    }
    return message.reply("Token mis a jour, ton bot redemarre.");
  }

  if (action === "transfer") {
    if (!current) return message.reply(":x: Tu n'as aucun bot actif.");
    const target = message.mentions.users.first() || await bot.users.fetch((args[1] || "").replace(/[<@!>]/g, "")).catch(() => null);
    if (!target || target.bot) return message.reply(`Usage: \`${(message.prefix || '&')}mybot transfer @membre\``);
    managerStore.transferUserBot(message.author.id, target.id, current.id);
    return message.reply(`Ton bot appartient maintenant a ${target}.`);
  }

  return message.reply(`Action inconnue. Usage: \`${exports.help.usage}\``);
};

exports.runSlash = async (bot, interaction) => {
  const action = interaction.options.getSubcommand();
  const color = 0x2b2d31;

  if (action === "key") {
    if (!bot.config.ownerId.includes(interaction.user.id)) {
      return interaction.reply({ content: ":x: Reserve au createur du manager.", ephemeral: true });
    }
    const duration = interaction.options.getString("duree", true);
    const note = interaction.options.getString("note") || "";
    const license = managerStore.createLicense(duration, interaction.user.id, note);
    return interaction.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Key creee")
          .setDescription(`Key: \`${license.key}\`\nDuree: **${duration}**\nActivation: \`/mybot activer\``)
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ],
      ephemeral: true
    }));
  }

  if (action === "keys") {
    if (!bot.config.ownerId.includes(interaction.user.id)) {
      return interaction.reply({ content: ":x: Reserve au createur du manager.", ephemeral: true });
    }
    const licenses = managerStore.listLicenses().slice(0, 10);
    const description = licenses.length
      ? licenses.map((license) => {
        const expire = license.expiresAt ? `<t:${Math.floor(license.expiresAt / 1000)}:R>` : license.activatedAt ? "infinie" : "pas encore activee";
        const state = license.revoked ? "revoke" : license.activatedBy ? "active" : "libre";
        return `\`${license.key}\` - ${state} - ${license.duration} - ${expire}`;
      }).join("\n")
      : "Aucune key creee.";

    return interaction.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Keys 4LC")
          .setDescription(description)
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ],
      ephemeral: true
    }));
  }

  if (action === "activer") {
    await interaction.deferReply({ ephemeral: true });
    const key = interaction.options.getString("key", true).toUpperCase();
    const token = interaction.options.getString("token", true).trim();
    const result = managerStore.activateLicense(key, token, interaction.user.id);

    if (result.error === "missing") return interaction.editReply(":x: Key introuvable.");
    if (result.error === "revoked") return interaction.editReply(":x: Cette key est desactivee.");
    if (result.error === "expired") return interaction.editReply(":x: Cette key a expire.");
    if (result.error === "used") return interaction.editReply(":x: Cette key est deja utilisee par quelqu'un d'autre.");

    try {
      await startManagedBot(result.bot, bot);
    } catch (error) {
      return interaction.editReply(`:x: Token refuse ou bot impossible a connecter: \`${error.message}\``);
    }

    return interaction.editReply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Bot active")
          .setDescription("Ton bot 4LC se connecte. Fais `/mybot status` pour recuperer son invitation.")
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ]
    }));
  }

  const bots = managerStore.userBots(interaction.user.id);
  const current = bots[0];

  if (action === "status") {
    if (!current) return interaction.reply({ content: "Tu n'as aucun bot actif. Achete-en un avec `/mybots`.", ephemeral: true });
    const client = activeClients.get(current.id);
    const clientId = client?.user?.id || current.clientId;
    const link = current.inviteUrl || (clientId ? inviteUrl(clientId) : null);
    const expire = current.license?.expiresAt ? `<t:${Math.floor(current.license.expiresAt / 1000)}:R>` : "infinie";

    return interaction.reply(toV2({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle("Vos bots")
          .setDescription([
            `Bot: **${client?.user?.tag || current.tag || current.username || "Pas encore connecte"}**`,
            `Etat: **${client ? "online" : current.status}**`,
            `Key: \`${current.key}\``,
            `Expiration: ${expire}`,
            link ? `Invitation: [Inviter le bot](${link})` : "Invitation: indisponible tant que le bot n'est pas connecte",
            current.lastError ? `Erreur: \`${current.lastError}\`` : null
          ].filter(Boolean).join("\n"))
          .setColor(color)
          .setFooter({ text: "4LC - Bot manager" })
      ],
      ephemeral: true
    }));
  }

  if (action === "stop") {
    if (!current) return interaction.reply({ content: ":x: Tu n'as aucun bot actif.", ephemeral: true });
    managerStore.stopUserBot(interaction.user.id, current.id);
    await stopManagedBot(current.id);
    return interaction.reply({ content: "Ton bot est maintenant offline.", ephemeral: true });
  }

  if (action === "restart") {
    if (!current) return interaction.reply({ content: ":x: Tu n'as aucun bot actif.", ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    await stopManagedBot(current.id);
    try {
      await startManagedBot(current, bot);
    } catch (error) {
      return interaction.editReply(`:x: Impossible de relancer ton bot: \`${error.message}\``);
    }
    return interaction.editReply("Ton bot a ete relance.");
  }

  if (action === "token") {
    if (!current) return interaction.reply({ content: ":x: Tu n'as aucun bot actif.", ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    const token = interaction.options.getString("token", true).trim();
    const updated = managerStore.updateBot(current.id, { token, status: "pending", lastError: null });
    await stopManagedBot(current.id);
    try {
      await startManagedBot(updated, bot);
    } catch (error) {
      return interaction.editReply(`:x: Token refuse ou bot impossible a connecter: \`${error.message}\``);
    }
    return interaction.editReply("Token mis a jour, ton bot redemarre.");
  }

  if (action === "transfer") {
    if (!current) return interaction.reply({ content: ":x: Tu n'as aucun bot actif.", ephemeral: true });
    const target = interaction.options.getUser("membre", true);
    if (target.bot) return interaction.reply({ content: ":x: Choisis un utilisateur, pas un bot.", ephemeral: true });
    managerStore.transferUserBot(interaction.user.id, target.id, current.id);
    return interaction.reply({ content: `Ton bot appartient maintenant a ${target}.`, ephemeral: true });
  }
};
