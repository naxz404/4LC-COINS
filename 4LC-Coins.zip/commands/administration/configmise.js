const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "configmise",
    category: "administration",
    aliases: ["configupdate", "misesconfig"],
    description: "Configure le salon qui reçoit les notifications de redémarrage / mise à jour du bot",
    usage: "configmise",
    permission: "whiteList"
};

exports.run = async (bot, message, args, color) => {
    const rows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`);
    const g = rows[0] || {};

    const state = {
        enabled: g.updateEnabled === "on",
        channelId: g.updateChannelId || null
    };

    const buildStatus = (note = null) => new Discord.EmbedBuilder()
        .setColor(color)
        .setAuthor({ name: "🛠️ Configuration des mises à jour", iconURL: bot.user.displayAvatarURL({ dynamic: true }) })
        .setDescription([
            note ? `> ${note}\n` : "",
            `> 🔌 Statut : ${state.enabled ? "✅ Activé" : "❌ Désactivé"}`,
            `> 📌 Salon : ${state.channelId ? `<#${state.channelId}>` : "❌ non défini"}`,
            "",
            "*À chaque redémarrage du bot, un embed sera envoyé dans ce salon indiquant si le code a changé (commandes ajoutées, modifiées ou supprimées) depuis le dernier démarrage.*"
        ].join("\n"))
        .setFooter({ text: "Pratique pour suivre les mises à jour d'un bot auto-hébergé ou géré par un dev" });

    const buildComponents = () => [
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("cm_toggle").setLabel(state.enabled ? "Désactiver" : "Activer").setStyle(state.enabled ? Discord.ButtonStyle.Danger : Discord.ButtonStyle.Success).setEmoji("🔌"),
            new Discord.ButtonBuilder().setCustomId("cm_test").setLabel("Envoyer un test").setStyle(Discord.ButtonStyle.Primary).setEmoji("🧪").setDisabled(!state.channelId)
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ChannelSelectMenuBuilder().setCustomId("cm_channel").setPlaceholder("Choisir le salon des notifications").addChannelTypes(Discord.ChannelType.GuildText)
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("cm_save").setLabel("Sauvegarder").setStyle(Discord.ButtonStyle.Success).setEmoji("💾"),
            new Discord.ButtonBuilder().setCustomId("cm_close").setLabel("Fermer").setStyle(Discord.ButtonStyle.Secondary).setEmoji("❌")
        )
    ];

    const panel = await message.reply(toV2({ embeds: [buildStatus()], components: buildComponents() }));
    const collector = panel.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription("`❌` Seul l'auteur de la commande peut utiliser ce panneau !").setColor("Red")], ephemeral: true }));
        }

        if (interaction.customId === "cm_close") {
            await interaction.update(toV2({ content: "`❌` Panneau fermé.", embeds: [], components: [] }));
            return collector.stop();
        }

        if (interaction.customId === "cm_toggle") {
            state.enabled = !state.enabled;
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "cm_channel") {
            state.channelId = interaction.values[0];
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "cm_test") {
            const channel = message.guild.channels.cache.get(state.channelId);
            if (!channel) {
                return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription("`❌` Salon introuvable, choisis-en un autre.").setColor("Red")], ephemeral: true }));
            }

            const testEmbed = new Discord.EmbedBuilder()
                .setAuthor({ name: `${bot.user.username} — Test de notification`, iconURL: bot.user.displayAvatarURL({ dynamic: true }) })
                .setDescription("🧪 Ceci est un message de test.\nVoici à quoi ressemblera une notification de redémarrage sur ce salon.")
                .addFields(
                    { name: "🆕 Commandes ajoutées", value: "`exemple`, `autreexemple`", inline: false },
                    { name: "✏️ Commandes modifiées", value: "`cduel`", inline: false }
                )
                .setColor(color)
                .setTimestamp()
                .setFooter({ text: "Suivi des mises à jour • configmise" });

            await channel.send(toV2({ embeds: [testEmbed] })).catch(() => {});
            return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`\`✅\` Message de test envoyé dans ${channel} !`).setColor("Green")], ephemeral: true }));
        }

        if (interaction.customId === "cm_save") {
            if (state.enabled && !state.channelId) {
                return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription("`❌` Choisis un salon avant d'activer les notifications.").setColor("Red")], ephemeral: true }));
            }
            await bot.db.query(`UPDATE guild SET updateEnabled = '${state.enabled ? "on" : "off"}', updateChannelId = '${state.channelId || ""}' WHERE guildId = '${message.guild.id}'`);
            await interaction.update(toV2({ embeds: [buildStatus("`✅` Configuration sauvegardée !")], components: [] }));
            return collector.stop();
        }
    });

    collector.on("end", () => {
        panel.edit({ components: [] }).catch(() => {});
    });
};
