const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "acces",
    category: "administration",
    aliases: ["accès", "panel"],
    description: "Ouvre un panneau de configuration pour créer et envoyer un embed personnalisé avec un bouton donneur de rôle",
    usage: "acces",
    permission: "owner"
};

exports.run = async (bot, message, args, color) => {

    const state = {
        channelId: null,
        roleId: null,       // rôle mentionné (ping) dans le message envoyé
        giveRoleId: null,   // rôle donné au clic sur le bouton
        buttonLabel: null,  // texte du bouton
        title: null,
        description: null,
        footer: null,
        image: null
    };

    // ---- Embed d'aperçu en direct : c'est exactement ce qui sera envoyé ----
    const buildPreview = () => {
        const embed = new Discord.EmbedBuilder().setColor(color);
        embed.setTitle(state.title || "Titre non défini");
        embed.setDescription(state.description || "*Configurez la description via le menu ci-dessous...*");
        if (state.image) embed.setImage(state.image); // Discord affiche toujours l'image sous la description
        if (state.footer) embed.setFooter({ text: state.footer });
        return embed;
    };

    // ---- Embed de statut au-dessus de l'aperçu ----
    const buildStatusEmbed = (extra = "") => {
        const salon = state.channelId ? `<#${state.channelId}>` : "❌ non défini";
        const role = state.roleId ? `<@&${state.roleId}>` : "⚪ (facultatif)";
        const giveRole = state.giveRoleId ? `<@&${state.giveRoleId}>` : "⚪ (facultatif)";
        const bouton = state.buttonLabel || "Obtenir le rôle";
        const titre = state.title ? "✅" : "❌";
        const desc = state.description ? "✅" : "❌";
        const footer = state.footer ? "✅" : "⚪ (facultatif)";
        const image = state.image ? "✅" : "⚪ (facultatif)";

        const lines = [
            `> 📌 Salon : ${salon}`,
            `> 🔔 Rôle à mentionner : ${role}`,
            `> 🎁 Rôle donné au clic : ${giveRole}`,
            `> 🔘 Nom du bouton : \`${bouton}\``,
            `> 📝 Titre : ${titre}  •  📄 Description : ${desc}  •  🔻 Footer : ${footer}  •  🖼️ Image : ${image}`,
            "",
            "*Astuce : les emojis du serveur (et de Discord en général) fonctionnent dans le titre, la description et le footer !*"
        ];
        if (extra) lines.push(extra);

        return new Discord.EmbedBuilder()
            .setColor(color)
            .setTitle("📋 Panneau de configuration — 4LC")
            .setDescription(lines.join("\n"));
    };

    const buildMenuRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.StringSelectMenuBuilder()
            .setCustomId("acces_menu")
            .setPlaceholder("Choisir un élément à configurer")
            .addOptions(
                new Discord.StringSelectMenuOptionBuilder().setLabel("Salon").setEmoji("📌").setValue("salon").setDescription("Choisir le salon où sera envoyé le message"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Rôle à mentionner").setEmoji("🔔").setValue("role").setDescription("Choisir un rôle à mentionner (facultatif)"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Rôle donné au clic").setEmoji("🎁").setValue("donnerole").setDescription("Rôle donné automatiquement quand on clique sur le bouton"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Nom du bouton").setEmoji("🔘").setValue("boutonnom").setDescription("Changer le texte affiché sur le bouton"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Titre").setEmoji("📝").setValue("titre").setDescription("Définir le titre de l'embed"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Description").setEmoji("📄").setValue("description").setDescription("Définir la description de l'embed"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Footer").setEmoji("🔻").setValue("footer").setDescription("Définir le footer de l'embed"),
                new Discord.StringSelectMenuOptionBuilder().setLabel("Image").setEmoji("🖼️").setValue("image").setDescription("Ajouter une image sous la description (facultatif)")
            )
    );

    const buildButtonRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
            .setCustomId("acces_send")
            .setLabel("Envoyer")
            .setEmoji("📨")
            .setStyle(Discord.ButtonStyle.Success)
            .setDisabled(!state.channelId || (!state.title && !state.description)),
        new Discord.ButtonBuilder().setCustomId("acces_reset").setLabel("Réinitialiser").setEmoji("♻️").setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder().setCustomId("acces_close").setLabel("Fermer").setEmoji("❌").setStyle(Discord.ButtonStyle.Danger)
    );

    const buildChannelRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.ChannelSelectMenuBuilder()
            .setCustomId("acces_channel")
            .setPlaceholder("Choisir un salon")
            .addChannelTypes(Discord.ChannelType.GuildText, Discord.ChannelType.GuildAnnouncement)
    );

    const buildRoleRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.RoleSelectMenuBuilder()
            .setCustomId("acces_role")
            .setPlaceholder("Choisir un rôle à mentionner (facultatif)")
    );

    const buildDonneRoleRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.RoleSelectMenuBuilder()
            .setCustomId("acces_donnerole")
            .setPlaceholder("Choisir le rôle donné au clic sur le bouton")
    );

    const buildBackRow = () => new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder().setCustomId("acces_back").setLabel("Retour").setEmoji("↩️").setStyle(Discord.ButtonStyle.Secondary)
    );

    const mainComponents = () => [buildMenuRow(), buildButtonRow()];

    const panel = await message.reply(toV2({
        embeds: [buildStatusEmbed(), buildPreview()],
        components: mainComponents()
    }));

    const collector = panel.createMessageComponentCollector({ time: 600000 });

    collector.on("collect", async (interaction) => {
        // ---- Seul l'auteur de la commande peut utiliser les boutons/menus ----
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "`❌` Seul l'auteur de la commande peut utiliser ce panneau !", ephemeral: true });
        }

        // ---- Fermer le panneau ----
        if (interaction.customId === "acces_close") {
            await interaction.update(toV2({ content: "`❌` Panneau fermé.", embeds: [], components: [] }));
            return collector.stop();
        }

        // ---- Réinitialiser la configuration ----
        if (interaction.customId === "acces_reset") {
            state.channelId = null;
            state.roleId = null;
            state.giveRoleId = null;
            state.buttonLabel = null;
            state.title = null;
            state.description = null;
            state.footer = null;
            state.image = null;
            return interaction.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
        }

        // ---- Envoyer le message final dans le salon choisi ----
        if (interaction.customId === "acces_send") {
            const channel = message.guild.channels.cache.get(state.channelId);
            if (!channel) return interaction.reply({ content: "`❌` Le salon configuré est introuvable.", ephemeral: true });

            try {
                const pingContent = state.roleId ? `<@&${state.roleId}>` : undefined;

                const sendComponents = [];
                if (state.giveRoleId) {
                    sendComponents.push(new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId(`acces_getrole_${state.giveRoleId}`)
                            .setLabel(state.buttonLabel || "Obtenir le rôle")
                            // .setEmoji("🎟️")
                            .setStyle(Discord.ButtonStyle.Primary)
                    ));
                }

                await channel.send(toV2({ content: pingContent, embeds: [buildPreview()], components: sendComponents }));

                // Mémorise ce rôle comme étant LE rôle "accès coins" du serveur : sert au reset
                // (retire le rôle) et à la recréation automatique du profil (quand le rôle est
                // redonné, même manuellement, en dehors du bouton).
                if (state.giveRoleId) {
                    await bot.db.query(`UPDATE guild SET accessRoleId = '${state.giveRoleId}' WHERE guildId = '${message.guild.id}'`);
                }

                await interaction.update(toV2({ content: `\`✅\` Message envoyé dans <#${state.channelId}> !`, embeds: [buildPreview()], components: [] }));
                collector.stop();
            } catch (error) {
                await interaction.reply({ content: "`❌` Impossible d'envoyer le message dans ce salon (permissions manquantes ?).", ephemeral: true });
            }
            return;
        }

        // ---- Retour au menu principal sans rien changer ----
        if (interaction.customId === "acces_back") {
            return interaction.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
        }

        // ---- Sélection du salon ----
        if (interaction.customId === "acces_channel") {
            state.channelId = interaction.values[0];
            return interaction.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
        }

        // ---- Sélection du rôle à mentionner ----
        if (interaction.customId === "acces_role") {
            state.roleId = interaction.values[0] || null;
            return interaction.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
        }

        // ---- Sélection du rôle donné au clic ----
        if (interaction.customId === "acces_donnerole") {
            state.giveRoleId = interaction.values[0] || null;
            return interaction.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
        }

        // ---- Menu principal : ouvre le sélecteur de salon/rôle ou un modal texte ----
        if (interaction.customId === "acces_menu") {
            const choix = interaction.values[0];

            if (choix === "salon") {
                return interaction.update(toV2({
                    embeds: [buildStatusEmbed("📌 Sélectionnez un salon ci-dessous :"), buildPreview()],
                    components: [buildChannelRow(), buildBackRow()]
                }));
            }

            if (choix === "role") {
                return interaction.update(toV2({
                    embeds: [buildStatusEmbed("🔔 Sélectionnez un rôle à mentionner (facultatif) :"), buildPreview()],
                    components: [buildRoleRow(), buildBackRow()]
                }));
            }

            if (choix === "donnerole") {
                return interaction.update(toV2({
                    embeds: [buildStatusEmbed("🎁 Sélectionnez le rôle donné au clic sur le bouton (facultatif) :"), buildPreview()],
                    components: [buildDonneRoleRow(), buildBackRow()]
                }));
            }

            const fields = {
                boutonnom: { key: "buttonLabel", modalId: "acces_modal_boutonnom", title: "Nom du bouton", label: "Texte du bouton", style: Discord.TextInputStyle.Short, max: 80 },
                titre: { key: "title", modalId: "acces_modal_titre", title: "Titre de l'embed", label: "Titre", style: Discord.TextInputStyle.Short, max: 256 },
                description: { key: "description", modalId: "acces_modal_description", title: "Description de l'embed", label: "Description", style: Discord.TextInputStyle.Paragraph, max: 4000 },
                footer: { key: "footer", modalId: "acces_modal_footer", title: "Footer de l'embed", label: "Footer", style: Discord.TextInputStyle.Short, max: 2048 },
                image: { key: "image", modalId: "acces_modal_image", title: "Image de l'embed (facultatif)", label: "Lien de l'image (URL)", style: Discord.TextInputStyle.Short, max: 512 }
            };
            const field = fields[choix];
            if (!field) return;

            const modal = new Discord.ModalBuilder().setCustomId(field.modalId).setTitle(field.title);
            const input = new Discord.TextInputBuilder()
                .setCustomId("acces_modal_input")
                .setLabel(field.label)
                .setStyle(field.style)
                .setMaxLength(field.max)
                .setRequired(false)
                .setPlaceholder("Les emojis du serveur fonctionnent ici !");

            if (state[field.key]) input.setValue(state[field.key]);

            modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
            await interaction.showModal(modal);

            try {
                const submitted = await interaction.awaitModalSubmit({
                    filter: (i) => i.customId === field.modalId && i.user.id === message.author.id,
                    time: 120000
                });

                const value = submitted.fields.getTextInputValue("acces_modal_input").trim();
                state[field.key] = value.length ? value : null;

                await submitted.update(toV2({ embeds: [buildStatusEmbed(), buildPreview()], components: mainComponents() }));
            } catch (error) {
                // Timeout : rien soumis, on ne fait rien
            }
        }
    });

    collector.on("end", () => {
        panel.edit({ components: [] }).catch(() => {});
    });
};
