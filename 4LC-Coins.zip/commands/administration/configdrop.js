const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "configdrop",
    category: "administration",
    aliases: ["dropconfig"],
    description: "Configure un drop automatique quotidien (heure, salon, montant)",
    usage: "configdrop",
    permission: "whiteList"
};

exports.run = async (bot, message, args, color) => {
    const rows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`);
    const g = rows[0] || {};

    const state = {
        enabled: g.dropEnabled === "on",
        hour: g.dropHour || "20",
        minute: g.dropMinute || "00",
        channelId: g.dropChannelId || null,
        amount: g.dropAmount || "100"
    };

    const buildStatus = () => new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle("⏰ Configuration de l'auto-drop")
        .setDescription([
            `> 🔌 Statut : ${state.enabled ? "✅ Activé" : "❌ Désactivé"}`,
            `> 🕐 Heure : \`${state.hour}:${state.minute}\``,
            `> 📌 Salon : ${state.channelId ? `<#${state.channelId}>` : "❌ non défini"}`,
            `> 💰 Montant : \`${state.amount} coins\``,
            "",
            "*Un colis sera automatiquement lancé chaque jour à l'heure définie, si activé.*"
        ].join("\n"));

    const buildComponents = () => [
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("cd_toggle").setLabel(state.enabled ? "Désactiver" : "Activer").setStyle(state.enabled ? Discord.ButtonStyle.Danger : Discord.ButtonStyle.Success).setEmoji("🔌"),
            new Discord.ButtonBuilder().setCustomId("cd_hour").setLabel("Définir l'heure").setStyle(Discord.ButtonStyle.Secondary).setEmoji("🕐"),
            new Discord.ButtonBuilder().setCustomId("cd_amount").setLabel("Définir le montant").setStyle(Discord.ButtonStyle.Secondary).setEmoji("💰")
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ChannelSelectMenuBuilder().setCustomId("cd_channel").setPlaceholder("Choisir le salon du drop").addChannelTypes(Discord.ChannelType.GuildText)
        ),
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("cd_save").setLabel("Sauvegarder").setStyle(Discord.ButtonStyle.Success).setEmoji("💾"),
            new Discord.ButtonBuilder().setCustomId("cd_close").setLabel("Fermer").setStyle(Discord.ButtonStyle.Secondary).setEmoji("❌")
        )
    ];

    const panel = await message.reply(toV2({ embeds: [buildStatus()], components: buildComponents() }));
    const collector = panel.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "`❌` Seul l'auteur de la commande peut utiliser ce panneau !", ephemeral: true });
        }

        if (interaction.customId === "cd_close") {
            await interaction.update(toV2({ content: "`❌` Panneau fermé.", embeds: [], components: [] }));
            return collector.stop();
        }

        if (interaction.customId === "cd_toggle") {
            state.enabled = !state.enabled;
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "cd_channel") {
            state.channelId = interaction.values[0];
            return interaction.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
        }

        if (interaction.customId === "cd_hour" || interaction.customId === "cd_amount") {
            const isHour = interaction.customId === "cd_hour";
            const modalId = isHour ? "cd_modal_hour" : "cd_modal_amount";
            const modal = new Discord.ModalBuilder()
                .setCustomId(modalId)
                .setTitle(isHour ? "Heure du drop (format HH:MM)" : "Montant du drop");
            const input = new Discord.TextInputBuilder()
                .setCustomId("cd_modal_input")
                .setLabel(isHour ? "Heure (ex: 20:00)" : "Montant en coins")
                .setStyle(Discord.TextInputStyle.Short)
                .setRequired(true)
                .setValue(isHour ? `${state.hour}:${state.minute}` : `${state.amount}`);
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
            await interaction.showModal(modal);

            try {
                const submitted = await interaction.awaitModalSubmit({
                    filter: (i) => i.customId === modalId && i.user.id === message.author.id,
                    time: 120000
                });
                const value = submitted.fields.getTextInputValue("cd_modal_input").trim();

                if (isHour) {
                    const match = value.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
                    if (!match) {
                        await submitted.reply({ content: ":x: Format invalide, utilisez HH:MM (ex: 20:00).", ephemeral: true });
                    } else {
                        state.hour = match[1].padStart(2, "0");
                        state.minute = match[2];
                        await submitted.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
                    }
                } else {
                    if (isNaN(value) || Number(value) <= 0) {
                        await submitted.reply({ content: ":x: Montant invalide.", ephemeral: true });
                    } else {
                        state.amount = String(Math.floor(Number(value)));
                        await submitted.update(toV2({ embeds: [buildStatus()], components: buildComponents() }));
                    }
                }
            } catch (error) {
                // Timeout du modal, rien à faire
            }
            return;
        }

        if (interaction.customId === "cd_save") {
            if (state.enabled && !state.channelId) {
                return interaction.reply({ content: ":x: Veuillez choisir un salon avant d'activer l'auto-drop.", ephemeral: true });
            }
            await bot.db.query(`UPDATE guild SET dropEnabled = '${state.enabled ? "on" : "off"}', dropHour = '${state.hour}', dropMinute = '${state.minute}', dropChannelId = '${state.channelId || ""}', dropAmount = '${state.amount}' WHERE guildId = '${message.guild.id}'`);
            await interaction.update(toV2({ content: "`✅` Configuration de l'auto-drop sauvegardée !", embeds: [buildStatus()], components: [] }));
            return collector.stop();
        }
    });

    collector.on("end", () => {
        panel.edit({ components: [] }).catch(() => {});
    });
};
