const Discord = require("discord.js")
const ms = require("ms")
const { toV2 } = require("../../utils/embedV2.js");
const { sendCoinLog } = require("../../utils/logs.js");
const IMAGES = require("../../utils/images.js");

exports.help = {
    name: "course",
    category: "administration",
    aliases: ["cheval", "chevaux", "horseracing"],
    description: "Lance une course de chevaux : chacun mise ce qu'il veut sur le cheval de son choix !",
    usage: "cheval [durée des mises] [#salon]",
    permission: "whiteList"
}

const TRACK_LENGTH = 22;
const TICK_MS = 1300;

const HORSES = [
    { key: 1, emoji: "🔴", customId: "cheval_bet_1" },
    { key: 2, emoji: "🔵", customId: "cheval_bet_2" },
    { key: 3, emoji: "🟢", customId: "cheval_bet_3" },
    { key: 4, emoji: "🟡", customId: "cheval_bet_4" }
];

exports.run = async (bot, message, args, color) => {
    // ---- Durée des mises : optionnelle, défaut 30 secondes ----
    let duration = 30000;
    if (args[0]) {
        try {
            const parsed = ms(args[0]);
            if (parsed && parsed >= 5000) duration = parsed;
        } catch (e) { /* argument invalide -> on garde le défaut, on lance quand même */ }
    }

    // ---- Salon : optionnel, défaut le salon actuel ----
    let salon = message.channel;
    if (args[1]) {
        const mentionned = message.mentions.channels.first();
        const byId = message.guild.channels.cache.get(args[1].replace(/[<#>]/g, ""));
        salon = mentionned || byId || message.channel;
    }

    const bets = new Map(); // userId -> { horse, amount, username }

    const potFor = (horseKey) => {
        let total = 0;
        for (const b of bets.values()) if (b.horse === horseKey) total += b.amount;
        return total;
    };

    const buildBetEmbed = (timestamp, note = null) => {
        const embed = new Discord.EmbedBuilder()
            .setAuthor({ name: "🏇 Course de chevaux" })
            .setDescription([
                note ? `> ${note}\n` : "",
                `Les paris ferment <t:${timestamp}:R> — clique sur le bouton de ton cheval pour miser le montant de ton choix !`,
                `*Le pot total est reversé aux gagnants au prorata de leur mise (plus tu mises gros sur le bon cheval, plus tu gagnes gros).*`
            ].join("\n"))
            .addFields(
                HORSES.map(h => ({
                    name: `${h.emoji} Cheval ${h.key}`,
                    value: `\`${potFor(h.key)} coins\` misés`,
                    inline: true
                }))
            )
            .setColor(color)
            .setFooter({ text: `${bets.size} parieur(s) • Mise libre, aucun minimum` });

        if (IMAGES.horseRaceBanner) embed.setImage(IMAGES.horseRaceBanner);
        return embed;
    };

    const buildBetRow = () => new Discord.ActionRowBuilder().addComponents(
        HORSES.map(h => new Discord.ButtonBuilder()
            .setCustomId(h.customId)
            .setLabel(`Cheval ${h.key}`)
            .setEmoji(h.emoji)
            .setStyle(Discord.ButtonStyle.Secondary))
    );

    const now = Date.now();
    const timestamp = Math.floor((now + duration) / 1000);

    const msg = await salon.send(toV2({ embeds: [buildBetEmbed(timestamp)], components: [buildBetRow()] }));
    if (salon.id !== message.channel.id) message.channel.send(`*Course lancée dans ${salon}*`);

    const collector = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: duration });

    collector.on("collect", async (interaction) => {
        const horse = HORSES.find(h => h.customId === interaction.customId);
        if (!horse) return;

        if (bets.has(interaction.user.id)) {
            return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Tu as déjà misé sur cette course !").setColor("Red")], ephemeral: true }));
        }

        const rows = await bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${interaction.user.id}"`);
        if (!rows.length) {
            return interaction.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Tu n'as pas encore de profil ! Envoie un message pour en créer un.").setColor("Red")], ephemeral: true }));
        }
        const currentCoins = Number(rows[0].coins || 0);

        const modal = new Discord.ModalBuilder().setCustomId(`cheval_montant_${horse.key}`).setTitle(`Miser sur le cheval ${horse.key}`);
        const input = new Discord.TextInputBuilder()
            .setCustomId("cheval_montant_input")
            .setLabel(`Montant à miser (tu as ${currentCoins} coins)`)
            .setStyle(Discord.TextInputStyle.Short)
            .setPlaceholder("Ex: 500")
            .setRequired(true);
        modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);

        try {
            const submitted = await interaction.awaitModalSubmit({
                filter: (i) => i.customId === `cheval_montant_${horse.key}` && i.user.id === interaction.user.id,
                time: 60000
            });

            const amount = Math.floor(Number(submitted.fields.getTextInputValue("cheval_montant_input").trim()));

            if (!Number.isFinite(amount) || amount <= 0) {
                return submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Montant invalide !").setColor("Red")], ephemeral: true }));
            }
            if (bets.has(interaction.user.id)) {
                return submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Tu as déjà misé sur cette course !").setColor("Red")], ephemeral: true }));
            }

            const freshRows = await bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${interaction.user.id}"`);
            const freshCoins = Number(freshRows[0]?.coins || 0);
            if (amount > freshCoins) {
                return submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`:x: Tu n'as que \`${freshCoins} coins\` !`).setColor("Red")], ephemeral: true }));
            }

            await bot.db.query(`UPDATE user SET coins = coins - ${amount} WHERE guildId = '${message.guild.id}' AND userId = '${interaction.user.id}'`);
            bets.set(interaction.user.id, { horse: horse.key, amount, username: interaction.user.username });

            await submitted.reply(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`✅ Tu as misé \`${amount} coins\` sur le cheval ${horse.emoji} **${horse.key}** !`).setColor("Green")], ephemeral: true }));
            await msg.edit(toV2({ embeds: [buildBetEmbed(timestamp)], components: [buildBetRow()] })).catch(() => {});
        } catch (e) {
            // Timeout de la modale
        }
    });

    collector.on("end", async () => {
        if (bets.size === 0) {
            await msg.edit(toV2({ embeds: [buildBetEmbed(timestamp, "❌ Course annulée : personne n'a misé.")], components: [] })).catch(() => {});
            return;
        }

        await msg.edit(toV2({ embeds: [buildBetEmbed(timestamp, "🔒 Les paris sont fermés !")], components: [] })).catch(() => {});
        salon.send(`:checkered_flag: **La course commence !**`);

        const positions = { 1: 0, 2: 0, 3: 0, 4: 0 };

        const buildTrackEmbed = (winnerKey = null) => {
            const lines = HORSES.map(h => {
                const pos = Math.min(positions[h.key], TRACK_LENGTH);
                const track = "─".repeat(pos) + "🐎" + "─".repeat(TRACK_LENGTH - pos);
                return `${h.emoji} \`${h.key}\` │${track}│🏁`;
            }).join("\n");

            const embed = new Discord.EmbedBuilder()
                .setAuthor({ name: winnerKey ? "🏆 Résultat de la course" : "🏇 Course en cours..." })
                .setDescription("```\n" + lines + "\n```")
                .setColor(winnerKey ? "Green" : color);

            if (winnerKey) {
                const winnerHorse = HORSES.find(h => h.key === winnerKey);
                embed.addFields({ name: "Gagnant", value: `${winnerHorse.emoji} **Cheval ${winnerKey}**` });
            }

            return embed;
        };

        await new Promise((resolve) => {
            const interval = setInterval(async () => {
                let winnerKey = null;
                let bestPos = -1;

                for (const h of HORSES) {
                    positions[h.key] += Math.floor(Math.random() * 5); // 0 à 4 cases, pour du suspense
                    if (positions[h.key] >= TRACK_LENGTH && positions[h.key] > bestPos) {
                        bestPos = positions[h.key];
                        winnerKey = h.key;
                    }
                }

                if (winnerKey) {
                    clearInterval(interval);
                    await msg.edit(toV2({ embeds: [buildTrackEmbed(winnerKey)] })).catch(() => {});
                    resolve(winnerKey);
                    return;
                }

                await msg.edit(toV2({ embeds: [buildTrackEmbed()] })).catch(() => {});
            }, TICK_MS);
        }).then(async (winnerKey) => {
            const totalPot = [...bets.values()].reduce((s, b) => s + b.amount, 0);
            const winningBets = [...bets.entries()].filter(([, b]) => b.horse === winnerKey);
            const sumWinning = winningBets.reduce((s, [, b]) => s + b.amount, 0);

            let resultLines = [];

            if (sumWinning === 0) {
                // Personne n'a misé sur le bon cheval : tout le monde est remboursé
                for (const [userId, b] of bets.entries()) {
                    await bot.db.query(`UPDATE user SET coins = coins + ${b.amount} WHERE guildId = '${message.guild.id}' AND userId = '${userId}'`);
                }
                resultLines.push("😅 Personne n'avait misé sur le bon cheval ! Tout le monde est remboursé.");
            } else {
                for (const [userId, b] of winningBets) {
                    const payout = Math.floor((b.amount / sumWinning) * totalPot);
                    await bot.db.query(`UPDATE user SET coins = coins + ${payout} WHERE guildId = '${message.guild.id}' AND userId = '${userId}'`);
                    resultLines.push(`🏆 <@${userId}> remporte \`${payout} coins\` (misé \`${b.amount}\`)`);
                }
                const losers = [...bets.entries()].filter(([, b]) => b.horse !== winnerKey);
                if (losers.length) {
                    resultLines.push("", `💸 Perdants : ${losers.map(([userId]) => `<@${userId}>`).join(", ")}`);
                }
            }

            const winnerHorse = HORSES.find(h => h.key === winnerKey);
            const resultsEmbed = new Discord.EmbedBuilder()
                .setAuthor({ name: `🏆 Le cheval ${winnerKey} a gagné !` })
                .setDescription(resultLines.join("\n"))
                .setColor("Gold")
                .setFooter({ text: `Pot total : ${totalPot} coins • ${bets.size} parieur(s)` });

            await salon.send(toV2({ embeds: [resultsEmbed] }));

            sendCoinLog(bot, message.guild, {
                type: "Course de chevaux",
                description: `${winnerHorse.emoji} Le cheval ${winnerKey} a gagné (pot total : ${totalPot} coins, ${bets.size} parieur(s))`
            });
        });
    });
}
