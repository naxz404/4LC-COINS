exports.help = { name: 'footer', category: 'administration', aliases: ['setfooter', 'set-footer'], description: 'Modifie ou désactive le footer des embeds', usage: 'footer <texte/off>', permission: 'whiteList' };

exports.run = async (bot, message, args) => {
  if (!args.length) return message.reply(`Usage : \`${(message.prefix || '&')}footer <texte/off>\``);
  if (args[0].toLowerCase() === 'off') {
    await bot.db.query(`UPDATE guild SET footerEnabled = 'off' WHERE guildId = '${message.guild.id}'`);
    bot.footer = null;
    return message.reply(':white_check_mark: Footer désactivé.');
  }
  const text = args.join(' ').trim().slice(0, 2048);
  if (!text) return message.reply(':x: Le footer ne peut pas être vide.');
  await bot.db.query(`UPDATE guild SET footer = '${text.replace(/'/g, "\\'")}', footerEnabled = 'on' WHERE guildId = '${message.guild.id}'`);
  bot.footer = { text, iconURL: 'https://cdn.discordapp.com/embed/avatars/0.png' };
  return message.reply(`:white_check_mark: Footer modifié : \`${text}\``);
};
