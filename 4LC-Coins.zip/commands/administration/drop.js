const Discord = require("discord.js")
const { sendCoinLog } = require("../../utils/logs.js")
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "drop",
    category: "administration",
    aliases: ["dropmoney"],
    description: "Envois de l'argent à un autre joueur",
    usage: "drop 100 <#channel / none>",
    permission: "whiteList"
}

const claimCooldownTime = 20; // 20 secondes avant qu'un joueur puisse re-claim un drop
const claimCooldowns = new Map(); // userId -> timestamp du dernier claim

exports.run = async (bot, message, args, color) => {
    let channel
    if(!args[0]) return message.channel.send(`:clipboard: Pas de récompense précisée | drop <amount> <#channel/none>`)
    if(isNaN(args[0])) return message.channel.send(`:clipboard: Pas de récompense précisée | drop <amount> <#channel/none>`)
    if(Number(args[0]) <= 0) return message.channel.send(":clipboard: Pas de récompense précisée | drop <amount> <#channel/none>")

    if(args[1]) {
        let i = args[1].replace("<#", "").split(">").join("")
        const a = bot.channels.cache.get(i) ? bot.channels.cache.get(i).name ? "yes" : "no" : "no"
        channel =  bot.channels.cache.get(i)
        if(a === "no") channel = message.channel
    } else channel = message.channel

    message.channel.send(`*Drop lancé dans ${channel}*`)
    await runDrop(bot, channel, Number(args[0]), color, message.guild);
}

/**
 * Lance un drop (colis à attraper) dans un salon donné. Réutilisée par &drop et par l'auto-drop planifié.
 */
async function runDrop(bot, channel, amount, color, guild) {
    const embed = new Discord.EmbedBuilder()
    .setTitle(`🎉 Un colis tombe du ciel !`)
    .setDescription(`Cliques sur le boutton ci-dessous pour l'attraper et gagner \`${amount} coins\``)
    .setFooter({ text: `Expire au bout de 60 secondes` })
    .setColor(color)

    const buttondropdd = new Discord.ActionRowBuilder()
    .addComponents(
        new Discord.ButtonBuilder()
        .setLabel(`Go !`)
        .setCustomId("dropgo")
        .setDisabled(false)
        .setEmoji(`🏆`)
        .setStyle(Discord.ButtonStyle.Primary),
    )

    const buttondropddd = new Discord.ActionRowBuilder()
    .addComponents(
        new Discord.ButtonBuilder()
        .setLabel(`Go !`)
        .setCustomId("dropgo")
        .setDisabled(true)
        .setEmoji(`🏆`)
        .setStyle(Discord.ButtonStyle.Primary),
    )

    const msg = await channel.send(toV2({ embeds: [embed], components: [buttondropdd] }))

    let claimedBy = null;

    // Pas de "max: 1" : sinon un clic rejeté (à cause du cooldown) consommerait le drop pour rien.
    // On s'arrête manuellement (collector2.stop) uniquement quand quelqu'un a vraiment réussi à claim.
    const collector2 = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 60000 });

    collector2.on('collect', async (button) => {
        if (button.customId !== "dropgo") return;

        const now = Math.floor(Date.now() / 1000);
        const lastClaim = claimCooldowns.get(button.user.id);
        const remaining = lastClaim ? claimCooldownTime - (now - lastClaim) : 0;

        if (remaining > 0) {
            return button.reply({
                content: `:x: Tu dois attendre encore ${remaining} seconde(s) avant de pouvoir attraper un autre drop !`,
                flags: Discord.MessageFlags.Ephemeral
            }).catch(() => {});
        }

        await button.deferUpdate();
        claimCooldowns.set(button.user.id, now);
        claimedBy = button.user;

        bot.db.query(`UPDATE user SET coins = coins + ${amount} WHERE guildId = '${guild.id}' AND userId = '${button.user.id}'`)
        channel.send(`${button.user} a attrapé le colis ! Il vient de gagner \`${amount} coins\``)
        sendCoinLog(bot, guild, {
            type: "Drop attrapé",
            user: button.user,
            amount: amount,
            description: `${button.user} a attrapé un drop de \`${amount} coins\` dans ${channel}`
        })

        collector2.stop("claimed");
    })

    collector2.on('end', (collected) => {
        const embed = new Discord.EmbedBuilder()
        .setTitle(`Drop terminé`)
        .setColor(color)
        msg.edit(toV2({ embeds: [embed], components: [buttondropddd] })).catch(() => {})
    })
}

exports.runDrop = runDrop;