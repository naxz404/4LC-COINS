const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "msg",
    category: "gestioncoins",
    aliases: ["message", "msgxp"],
    description: "Empêche de recevoir des coins/xp lorsque vous envoyez des messages (équivalent de la commande vocal pour les messages)",
    usage: "Pas d'utilisation conseillée"
}

exports.run = async (bot, message, args, color) => {
    bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, req) => {
        if (req.length < 1) return message.reply(':x: Vous n\'avez pas encore commencer les coins, refaîtes la commande !')

        const msgactivate = req[0].msg
        if (msgactivate == "on") {
            const embed = new Discord.EmbedBuilder()
            .setDescription(`:no_entry: Vous ne recevrez plus de coins/xp lorsque vous envoyez des messages, refaite la commande \`msg\` pour réactiver le gain !`)
            .setColor(color)

            bot.db.query(`UPDATE user SET msg = 'off' WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`);

            message.reply(toV2({ embeds: [embed] }))
        } else {
            const embed = new Discord.EmbedBuilder()
            .setDescription(`:ballot_box_with_check: Vous recevrez désormais les coins/xp lorsque vous envoyez des messages !`)
            .setColor(color)

            bot.db.query(`UPDATE user SET msg = 'on' WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`);

            message.reply(toV2({ embeds: [embed] }))
        }
    })
}
