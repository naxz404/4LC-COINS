const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "help",
    category: "utilitaire",
    aliases: ["aide"],
    description: "Affiche les commandes du bot",
    usage: "help [commande]"
};

const CATEGORY_TITLES = {
    gestioncoins: "🪙 • Gestion des coins",
    jeux: "🎲 • Jeux",
    minijeux: "🚀 • Mini-jeux",
    cartes: "🃏 • Cartes",
    recompenses: "⌚️ • Récompenses",
    job: "🔑 • Job",
    team: "⚔️ • Team",
    illegal: "💊 • Illégal",
    trade: "🔄 • Échanges",
    administration: "🔰 • Administration",
    utilitaire: "ℹ️ • Utilitaire",
    proprietaire: "✋ • Propriétaires"
};

exports.run = async (bot, message, args, color) => {

    const prefix = (message.prefix || '&');

    // ---- Aide détaillée sur une commande précise ----
    if (args[0]) {
        const cmdname = args[0].toLowerCase();
        const cmdad = bot.commands.get(cmdname);

        if (!cmdad) {
            return message.channel.send(`:x: Commande inexistante !`);
        }

        let aliases = cmdad.help.aliases?.length ? cmdad.help.aliases.join(", ") : "Aucun";

        const embedArgs = new Discord.EmbedBuilder()
            .setAuthor({ name: `Page d'aide de la commande ${cmdname}`, iconURL: bot.user.displayAvatarURL({ dynamic: true }), url: 'https://discord.gg/ddJMXWYJ29' })
            .setDescription(`**Commande -** [ \`${cmdad.help.name}\` ]\n\n**Description -** [ \`${cmdad.help.description}\` ]\n\n**Usage -** [ \`${cmdad.help.usage}\` ]\n\n**Aliases -** [ \`${aliases}\` ]`)
            .setFooter({ text: `4LC Coins`, iconURL: bot.user.displayAvatarURL({ dynamic: true }) })
            .setColor(color);

        return message.reply(toV2({ embeds: [embedArgs] }));
    }

    // ---- Récupération des infos de gain pour la page 1 ----
    bot.db.query(`SELECT * FROM gain WHERE guildId = ${message.guild.id}`, async (err, req) => {
        if (err) console.error(err);

        let gainvoc = req?.[0]?.vocal ?? "0";
        let gaincam = req?.[0]?.cam ?? "0";
        let gainstream = req?.[0]?.stream ?? "0";
        if (gainvoc == "0") gainvoc = "rien coins";
        if (gaincam == "0") gaincam = "rien coins";
        if (gainstream == "0") gainstream = "rien coins";

        // ---- Regroupement dynamique des commandes par catégorie ----
        const uniqueCommands = [...new Map([...bot.commands.values()].map((c) => [c.help?.name, c])).values()]
            .filter((c) => c.help?.name);

        const categories = {};
        for (const command of uniqueCommands) {
            const category = command.help.category || "autres";
            categories[category] ||= [];
            categories[category].push(command);
        }

        const categoryPages = Object.entries(categories).map(([category, commands]) => {
            const lines = commands
                .sort((a, b) => a.help.name.localeCompare(b.help.name))
                .map((c) => `\`${prefix}${c.help.name}\`\n> ${c.help.description || "Aucune description."}`)
                .join("\n");

            return new Discord.EmbedBuilder()
                .setTitle(CATEGORY_TITLES[category] || category)
                .setDescription(`Utilisez \`${prefix}help [commande]\` pour obtenir des informations sur une commande\n\n${lines || "Aucune commande."}`)
                .setColor(color);
        });

        const introPage = new Discord.EmbedBuilder()
            .setTitle(`👤 • Serveur Informations`)
            .setDescription(`Utilise \`${prefix}help [commande]\` pour obtenir des informations sur une commande\n\n> 🔊 Vous gagnez \`${gainvoc}\` toutes les 15 minutes lorsque vous êtes en vocal\n> 🎥 Vous gagnez \`${gainstream}\` lorsque vous êtes en stream\n> 📹 Et vous gagnez \`${gaincam}\` lorsque vous activez votre caméra !\n\n*Appuyez sur les flèches ci-dessous pour changer de page !*`)
            .setColor(color);

        const pages = [introPage, ...categoryPages];
        const total = pages.length;

        pages.forEach((page, i) => {
            page.setFooter({ text: `4LC • Page ${i + 1}/${total}`, iconURL: bot.user.displayAvatarURL({ dynamic: true }) });
        });

        let index = 0;

        const buttons = (disabled = false) => [
            new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setEmoji("◀️")
                    .setCustomId("help_prev")
                    .setStyle(Discord.ButtonStyle.Primary)
                    .setDisabled(disabled),
                new Discord.ButtonBuilder()
                    .setEmoji("🔎")
                    .setCustomId("help_search")
                    .setStyle(Discord.ButtonStyle.Secondary)
                    .setDisabled(disabled),
                new Discord.ButtonBuilder()
                    .setEmoji("▶️")
                    .setCustomId("help_next")
                    .setStyle(Discord.ButtonStyle.Primary)
                    .setDisabled(disabled)
            )
        ];

        const msg = await message.reply(toV2({ embeds: [pages[index]], components: buttons() }));
        const collector = msg.createMessageComponentCollector({ time: 180000 });

        collector.on("collect", async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: `Désolé, mais vous n'avez pas la permission d'utiliser ces boutons !`, ephemeral: true });
            }

            if (interaction.customId === "help_search") {
                const modal = new Discord.ModalBuilder().setCustomId("help_search_modal").setTitle("Rechercher une commande");
                const input = new Discord.TextInputBuilder()
                    .setCustomId("help_search_input")
                    .setLabel("Nom de la commande")
                    .setStyle(Discord.TextInputStyle.Short)
                    .setRequired(true)
                    .setPlaceholder("ex: dragon");
                modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
                await interaction.showModal(modal);

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === "help_search_modal" && i.user.id === message.author.id,
                        time: 60000
                    });
                    const query = submitted.fields.getTextInputValue("help_search_input").trim().toLowerCase();
                    const found = bot.commands.get(query);

                    if (!found) {
                        return submitted.reply({ content: `\`❌\` Aucune commande trouvée pour \`${query}\`.`, ephemeral: true });
                    }

                    const aliases = found.help.aliases?.length ? found.help.aliases.join(", ") : "Aucun";
                    const embedArgs = new Discord.EmbedBuilder()
                        .setAuthor({ name: `Page d'aide de la commande ${found.help.name}`, url: 'https://discord.gg/ddJMXWYJ29' })
                        .setDescription(`**Commande -** [ \`${found.help.name}\` ]\n\n**Description -** [ \`${found.help.description}\` ]\n\n**Usage -** [ \`${found.help.usage}\` ]\n\n**Aliases -** [ \`${aliases}\` ]`)
                        .setFooter({ text: `4LC Coins` })
                        .setColor(color);

                    return submitted.reply(toV2({ embeds: [embedArgs], ephemeral: true }));
                } catch (error) {
                    // Timeout du modal, rien à faire
                }
                return;
            }

            if (interaction.customId === "help_prev") index = index === 0 ? total - 1 : index - 1;
            if (interaction.customId === "help_next") index = index === total - 1 ? 0 : index + 1;

            await interaction.update(toV2({ embeds: [pages[index]], components: buttons() }));
        });

        collector.on("end", () => {
            msg.edit({ components: buttons(true) }).catch(() => {});
        });
    });
};