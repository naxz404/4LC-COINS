const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
  name: "helpall",
  category: "utilitaire",
  aliases: ["help-all"],
  description: "Affiche toutes les commandes en une page",
  usage: "helpall"
};

exports.run = async (bot, message, args, color) => {
  const prefix = (message.prefix || '&') || "&";
  const uniqueCommands = [...new Map([...bot.commands.values()].map((command) => [command.help?.name, command])).values()]
    .filter((command) => command.help?.name)
    .sort((a, b) => a.help.name.localeCompare(b.help.name));

  const lines = uniqueCommands.map((command) => `\`${prefix}${command.help.name}\` - ${command.help.description || "Aucune description."}`);
  const embed = new Discord.EmbedBuilder()
    .setTitle("Toutes les commandes")
    .setDescription(lines.join("\n").slice(0, 4096))
    .setColor(color)
    .setFooter({ text: "4LC - Help" });

  return message.reply(toV2({ embeds: [embed] }));
};
