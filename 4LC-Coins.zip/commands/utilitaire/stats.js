const Discord = require("discord.js");
const axios = require("axios");
const { toV2 } = require("../../utils/embedV2.js");
const { renderStatsBoard } = require("../../utils/imagelib/statsBoard.js");
const { decodePNG } = require("../../utils/imagelib/pngDecode.js");

exports.help = {
    name: "stats",
    category: "utilitaire",
    aliases: ["stat", "statbot"],
    description: "Affiche une carte de statistiques d'activité (messages, vocal, classement) façon Statbot",
    usage: "stats [@membre]"
};

// ---- Utilitaires dates (UTC, comme le tracker) ----
function lastNDates(n) {
    const dates = [];
    const now = new Date();
    for (let i = 0; i < n; i++) {
        const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - i));
        dates.push(d.toISOString().slice(0, 10));
    }
    return dates;
}

function fmtHours(seconds) {
    return (Number(seconds || 0) / 3600).toFixed(2);
}

function fmtDate(timestamp) {
    const d = new Date(timestamp);
    const dd = String(d.getUTCDate()).padStart(2, "0");
    const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
    return `${dd}/${mm}/${d.getUTCFullYear()}`;
}

function colorToRGB(colorName) {
    try {
        const int = Discord.resolveColor(colorName || "LightGrey");
        return [(int >> 16) & 255, (int >> 8) & 255, int & 255, 255];
    } catch {
        return [90, 160, 240, 255];
    }
}

function channelName(guild, channelId) {
    const chan = guild.channels.cache.get(channelId);
    return chan ? chan.name : "salon supprime";
}

exports.run = async (bot, message, args, color) => {
    const target =
        message.mentions.members?.first() ||
        (args[0] && message.guild.members.cache.get(args[0].replace(/[<@!>]/g, ""))) ||
        message.member;

    const guildId = message.guild.id;

    const [msgRows, vocRows] = await Promise.all([
        bot.db.query(`SELECT * FROM activityMessage WHERE guildId = '${guildId}'`),
        bot.db.query(`SELECT * FROM activityVoice WHERE guildId = '${guildId}'`)
    ]);

    const dates14 = lastNDates(14);
    const set1 = new Set(dates14.slice(0, 1));
    const set7 = new Set(dates14.slice(0, 7));
    const set14 = new Set(dates14);

    const sumFor = (rows, userId, dateSet, field) =>
        rows.reduce((acc, r) => (r.userId === userId && dateSet.has(r.date) ? acc + Number(r[field] || 0) : acc), 0);

    // ---- Messages / vocal du membre visé ----
    const msg1 = sumFor(msgRows, target.id, set1, "count");
    const msg7 = sumFor(msgRows, target.id, set7, "count");
    const msg14 = sumFor(msgRows, target.id, set14, "count");

    const voc1 = sumFor(vocRows, target.id, set1, "seconds");
    const voc7 = sumFor(vocRows, target.id, set7, "seconds");
    const voc14 = sumFor(vocRows, target.id, set14, "seconds");

    // ---- Classement serveur (sur 14 jours) ----
    const totalsMsg = {};
    for (const r of msgRows) {
        if (set14.has(r.date)) totalsMsg[r.userId] = (totalsMsg[r.userId] || 0) + Number(r.count || 0);
    }
    const rankedMsg = Object.entries(totalsMsg).sort((a, b) => b[1] - a[1]).map(([id]) => id);
    const msgRank = rankedMsg.indexOf(target.id) + 1;

    const totalsVoc = {};
    for (const r of vocRows) {
        if (set14.has(r.date)) totalsVoc[r.userId] = (totalsVoc[r.userId] || 0) + Number(r.seconds || 0);
    }
    const rankedVoc = Object.entries(totalsVoc).sort((a, b) => b[1] - a[1]).map(([id]) => id);
    const vocRank = rankedVoc.indexOf(target.id) + 1;

    const totalRanked = new Set([...rankedMsg, ...rankedVoc]).size;

    // ---- Salons les plus actifs (sur 14 jours) ----
    const chanMsg = {};
    for (const r of msgRows) {
        if (r.userId === target.id && set14.has(r.date)) chanMsg[r.channelId] = (chanMsg[r.channelId] || 0) + Number(r.count || 0);
    }
    const topMsgChannels = Object.entries(chanMsg).sort((a, b) => b[1] - a[1]).slice(0, 2);

    const chanVoc = {};
    for (const r of vocRows) {
        if (r.userId === target.id && set14.has(r.date)) chanVoc[r.channelId] = (chanVoc[r.channelId] || 0) + Number(r.seconds || 0);
    }
    const topVocChannels = Object.entries(chanVoc).sort((a, b) => b[1] - a[1]).slice(0, 1);

    const topChannels = [
        ...topMsgChannels.map(([id, count]) => ({
            label: channelName(message.guild, id),
            value: `${count} MSG`,
            ratio: count,
            color: [95, 222, 142, 255]
        })),
        ...topVocChannels.map(([id, seconds]) => ({
            label: channelName(message.guild, id),
            value: `${fmtHours(seconds)}H`,
            ratio: Number(seconds) / 60,
            color: [232, 92, 172, 255]
        }))
    ];

    // ---- Série 14 jours (du plus ancien au plus récent) pour le graphique ----
    const series = dates14.slice().reverse().map((date) => {
        const m = msgRows.reduce((acc, r) => (r.userId === target.id && r.date === date ? acc + Number(r.count || 0) : acc), 0);
        const v = vocRows.reduce((acc, r) => (r.userId === target.id && r.date === date ? acc + Number(r.seconds || 0) : acc), 0) / 3600;
        return { msg: m, voc: v };
    });

    // ---- Récupération de la vraie photo de profil (avec repli propre si ça échoue) ----
    let avatarImage = null;
    try {
        const avatarUrl = target.user.displayAvatarURL({ extension: "png", size: 256, forceStatic: true });
        const resp = await axios.get(avatarUrl, { responseType: "arraybuffer", timeout: 6000 });
        avatarImage = decodePNG(Buffer.from(resp.data));
    } catch (e) {
        avatarImage = null;
    }

    // ---- Génération de l'image ----
    const accent = colorToRGB(color);
    const png = renderStatsBoard({
        username: target.user.username,
        avatarImage,
        serverName: `${message.guild.name}`,
        accent,
        createdOn: fmtDate(target.user.createdTimestamp),
        joinedOn: fmtDate(target.joinedTimestamp),
        msgRank: msgRank > 0 ? msgRank : null,
        vocRank: vocRank > 0 ? vocRank : null,
        totalRanked,
        messages: { d1: msg1, d7: msg7, d14: msg14 },
        voice: { d1: fmtHours(voc1), d7: fmtHours(voc7), d14: fmtHours(voc14) },
        topChannels,
        series
    });

    const attachment = new Discord.AttachmentBuilder(png, { name: "stats_board.png" });

    const embed = new Discord.EmbedBuilder()
        .setColor(color || "LightGrey")
        .setAuthor({ name: `Statistiques de ${target.user.username}`, iconURL: target.user.displayAvatarURL({ dynamic: true }) })
        .setImage("attachment://stats_board.png")
        .setFooter(bot.footer);

    return message.channel.send(toV2({ embeds: [embed], files: [attachment] }));
};
