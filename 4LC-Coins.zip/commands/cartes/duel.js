const Discord = require("discord.js")
const { parseCollection, totalPower, totalCards } = require("../../utils/cards.js")
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "cduel",
    category: "cartes",
    aliases: ["cardduel", "duelcarte"],
    description: "Lance un duel de cartes contre un autre joueur, mise des coins à la clé",
    usage: "cduel @membre <montant>"
}

// Empêche un joueur de lancer plusieurs duels en même temps (userId -> true tant qu'un duel est en attente/en cours)
const activeDuels = new Set()

// ---------- Petits builders d'embeds réutilisés partout dans la commande ----------

function usageEmbed(bot, color, note = null) {
    return new Discord.EmbedBuilder()
        .setAuthor({ name: "⚔️ Duel de cartes — Aide" })
        .setDescription(
            (note ? `${note}\n\n` : "") +
            "Défie un autre joueur dans un duel de cartes ! Le vainqueur remporte la mise, tiré au sort selon la puissance totale de chaque collection."
        )
        .addFields(
            { name: "📝 Utilisation", value: `\`${(message.prefix || '&')}cduel @membre <montant>\`` },
            { name: "💡 Exemple", value: `\`${(message.prefix || '&')}cduel @Pseudo 500\`` },
            { name: "🔤 Alias", value: "`cardduel`, `duelcarte`" },
            { name: "🎴 Besoin de cartes ?", value: `Utilise \`${(message.prefix || '&')}mycard\` pour voir ta collection ou en tirer une nouvelle.` }
        )
        .setColor(color)
        .setFooter({ text: "Astuce : plus ta puissance totale est élevée, plus tu as de chances de gagner !" })
}

function errorEmbed(bot, description) {
    return new Discord.EmbedBuilder()
        .setAuthor({ name: "❌ Duel impossible" })
        .setDescription(description)
        .setColor("Red")
        .setFooter({ text: `Utilisation correcte : ${(message.prefix || '&')}cduel @membre <montant>` })
}

exports.run = async (bot, message, args, color) => {
    const mention = message.mentions.members.first() || message.guild.members.cache.get(args[0])

    // ---- Aucun membre précisé ou mal précisé -> on explique comment faire ----
    if (!mention) {
        return message.reply(toV2({ embeds: [usageEmbed(bot, color, "`❌` Tu dois mentionner un membre valide à défier.")] }))
    }
    if (mention.id === message.author.id) {
        return message.reply(toV2({ embeds: [errorEmbed(bot, "Tu ne peux pas te défier toi-même !")] }))
    }
    if (mention.user.bot) {
        return message.reply(toV2({ embeds: [errorEmbed(bot, "Tu ne peux pas défier un bot !")] }))
    }

    // ---- Montant manquant ou invalide -> on explique comment faire ----
    if (!args[1]) {
        return message.reply(toV2({ embeds: [usageEmbed(bot, color, "`❌` Tu dois préciser un montant à miser.")] }))
    }
    if (isNaN(args[1]) || Number(args[1]) <= 0) {
        return message.reply(toV2({ embeds: [usageEmbed(bot, color, "`❌` Le montant précisé n'est pas un nombre valide.")] }))
    }
    const mise = Number(args[1])

    // ---- Anti-doublon : un joueur ne peut pas être dans deux duels en même temps ----
    if (activeDuels.has(message.author.id)) {
        return message.reply(toV2({ embeds: [errorEmbed(bot, "Tu as déjà un duel en attente ou en cours ! Termine-le avant d'en lancer un autre.")] }))
    }
    if (activeDuels.has(mention.id)) {
        return message.reply(toV2({ embeds: [errorEmbed(bot, `${mention.user.username} a déjà un duel en attente ou en cours !`)] }))
    }

    bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, authorUser) => {
        if (!authorUser.length) return message.reply(toV2({ embeds: [errorEmbed(bot, "Tu n'as pas encore commencé les coins, refais la commande une première fois !")] }))
        if (Number(authorUser[0].coins) < mise) return message.reply(toV2({ embeds: [errorEmbed(bot, `Tu n'as pas assez de coins pour miser \`${mise} coins\` !\nTon solde : \`${authorUser[0].coins} coins\``)] }))

        bot.db.query(`SELECT * FROM cards WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, authorCards) => {
            const authorCollection = parseCollection(authorCards[0]?.collection)
            if (!totalCards(authorCollection)) return message.reply(toV2({ embeds: [errorEmbed(bot, `Tu n'as pas de carte pour lancer un duel ! Utilise \`${(message.prefix || '&')}mycard\` pour en tirer une.`)] }))

            bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`, async (err, targetUser) => {
                if (!targetUser.length) return message.reply(toV2({ embeds: [errorEmbed(bot, `${mention.user.username} n'a pas encore commencé les coins !`)] }))
                if (Number(targetUser[0].coins) < mise) return message.reply(toV2({ embeds: [errorEmbed(bot, `${mention.user.username} n'a pas assez de coins pour cette mise !\nSon solde : \`${targetUser[0].coins} coins\``)] }))

                bot.db.query(`SELECT * FROM cards WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`, async (err, targetCards) => {
                    const targetCollection = parseCollection(targetCards[0]?.collection)
                    if (!totalCards(targetCollection)) return message.reply(toV2({ embeds: [errorEmbed(bot, `${mention.user.username} n'a pas de carte pour lancer un duel !`)] }))

                    // ---- On verrouille les deux joueurs pour la durée du duel ----
                    activeDuels.add(message.author.id)
                    activeDuels.add(mention.id)

                    const authorPowerBase = totalPower(authorCollection)
                    const targetPowerBase = totalPower(targetCollection)

                    const buildAskEmbed = (note = null) => new Discord.EmbedBuilder()
                        .setAuthor({ name: "⚔️ Duel de cartes", iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                        .setDescription(
                            (note ? `${note}\n\n` : "") +
                            `${mention}, ${message.author} te défie en duel de cartes !\nTu as **60 secondes** pour répondre.`
                        )
                        .addFields(
                            { name: "🗡️ Challenger", value: `${message.author}\nPuissance totale : \`${authorPowerBase}\``, inline: true },
                            { name: "🛡️ Défié", value: `${mention}\nPuissance totale : \`${targetPowerBase}\``, inline: true },
                            { name: "💰 Mise", value: `\`${mise} coins\` chacun`, inline: false }
                        )
                        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                        .setColor(color)
                        .setFooter({ text: `${mention.user.username} : Accepte ou refuse avec les boutons ci-dessous` })

                    const confirmRow = new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder().setCustomId("cduel_accept").setLabel("Accepter").setEmoji("⚔️").setStyle(Discord.ButtonStyle.Success),
                        new Discord.ButtonBuilder().setCustomId("cduel_refuse").setLabel("Refuser").setEmoji("❌").setStyle(Discord.ButtonStyle.Secondary),
                        new Discord.ButtonBuilder().setCustomId("cduel_cancel").setLabel("Annuler").setEmoji("🚫").setStyle(Discord.ButtonStyle.Danger)
                    )

                    const releaseLock = () => {
                        activeDuels.delete(message.author.id)
                        activeDuels.delete(mention.id)
                    }

                    const panel = await message.reply(toV2({ embeds: [buildAskEmbed()], components: [confirmRow] }))
                    const collector = panel.createMessageComponentCollector({ time: 60000, max: 1 })

                    collector.on("collect", async (interaction) => {
                        // ---- Le challenger peut annuler sa propre demande ----
                        if (interaction.customId === "cduel_cancel") {
                            if (interaction.user.id !== message.author.id) {
                                return interaction.reply(toV2({ embeds: [errorEmbed(bot, "Seul le challenger peut annuler ce duel !")], ephemeral: true }))
                            }
                            releaseLock()
                            return interaction.update(toV2({
                                embeds: [new Discord.EmbedBuilder().setDescription(`🚫 ${message.author} a annulé le duel proposé à ${mention.user.username}.`).setColor("Grey")],
                                components: []
                            }))
                        }

                        if (interaction.user.id !== mention.id) {
                            return interaction.reply(toV2({ embeds: [errorEmbed(bot, "Seule la personne défiée peut accepter ou refuser ce duel !")], ephemeral: true }))
                        }

                        if (interaction.customId === "cduel_refuse") {
                            releaseLock()
                            return interaction.update(toV2({
                                embeds: [new Discord.EmbedBuilder().setDescription(`❌ ${mention.user.username} a refusé le duel de ${message.author.username}.`).setColor("Red")],
                                components: []
                            }))
                        }

                        // ---- Duel accepté : tirage pondéré par la puissance ----
                        const authorPower = authorPowerBase + 1
                        const targetPower = targetPowerBase + 1
                        const authorWins = Math.random() < authorPower / (authorPower + targetPower)

                        const winner = authorWins ? message.member : mention
                        const loser = authorWins ? mention : message.member

                        const newWinnerCoins = Number((authorWins ? authorUser : targetUser)[0].coins) + mise
                        const newLoserCoins = Number((authorWins ? targetUser : authorUser)[0].coins) - mise

                        bot.db.query(`UPDATE user SET coins = '${newWinnerCoins}' WHERE guildId = "${message.guild.id}" AND userId = "${winner.id}"`)
                        bot.db.query(`UPDATE user SET coins = '${newLoserCoins}' WHERE guildId = "${message.guild.id}" AND userId = "${loser.id}"`)

                        const winChance = Math.round((authorWins ? authorPower / (authorPower + targetPower) : targetPower / (authorPower + targetPower)) * 100)

                        const resultEmbed = new Discord.EmbedBuilder()
                            .setAuthor({ name: "⚔️ Duel de cartes — Résultat", iconURL: winner.user.displayAvatarURL({ dynamic: true }) })
                            .setDescription(`🏆 ${winner} l'emporte face à ${loser} !\n*(${winChance}% de chances de victoire)*`)
                            .addFields(
                                { name: "🏆 Vainqueur", value: `${winner}\nNouveau solde : \`${newWinnerCoins} coins\``, inline: true },
                                { name: "💀 Perdant", value: `${loser}\nNouveau solde : \`${newLoserCoins} coins\``, inline: true },
                                { name: "💰 Gain net", value: `\`+${mise} coins\``, inline: false },
                                { name: `Puissance ${message.author.username}`, value: `\`${authorPowerBase}\``, inline: true },
                                { name: `Puissance ${mention.user.username}`, value: `\`${targetPowerBase}\``, inline: true }
                            )
                            .setThumbnail(winner.user.displayAvatarURL({ dynamic: true }))
                            .setColor("Gold")

                        releaseLock()
                        await interaction.update(toV2({ embeds: [resultEmbed], components: [] }))
                    })

                    collector.on("end", (collected) => {
                        if (!collected.size) {
                            releaseLock()
                            panel.edit(toV2({
                                embeds: [new Discord.EmbedBuilder().setDescription(`⌛ Le duel proposé à ${mention.user.username} a expiré sans réponse.`).setColor("Grey")],
                                components: []
                            })).catch(() => {})
                        }
                    })
                })
            })
        })
    })
}
