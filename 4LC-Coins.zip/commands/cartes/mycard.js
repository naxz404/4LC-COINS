const Discord = require("discord.js")
const { pickRandomCard, getCard, parseCollection, stringifyCollection, totalCards, totalPower, totalValue } = require("../../utils/cards.js")
const { toV2 } = require("../../utils/embedV2.js");

const DRAW_COOLDOWN = 4 * 60 * 60; // 4h entre deux tirages

exports.help = {
    name: "mycard",
    category: "cartes",
    aliases: ["cards", "card", "mycards"],
    description: "Affiche votre collection de cartes et permet d'en tirer une nouvelle",
    usage: "mycards"
}

exports.run = async (bot, message, args, color) => {
    const mention = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member
    const isSelf = mention.id === message.author.id

    bot.db.query(`SELECT * FROM cards WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`, async (err, req) => {
        if (!req.length) return message.reply(':x: Cette personne n\'a pas encore de profil, refaîtes la commande !')

        const collection = parseCollection(req[0].collection)
        const lastDraw = Number(req[0].lastDraw || 0)

        const buildEmbed = (extra = "") => {
            const entries = Object.entries(collection).filter(([, n]) => Number(n) > 0)
            const lines = entries.length
                ? entries
                    .map(([id, n]) => {
                        const card = getCard(id)
                        if (!card) return null
                        return `${card.emoji} **${card.name}** (${card.rarity}) x${n} — puissance ${card.power}`
                    })
                    .filter(Boolean)
                    .join("\n")
                : "*Aucune carte pour le moment...*"

            return new Discord.EmbedBuilder()
                .setAuthor({ name: `Cartes de ${mention.user.username}`, iconURL: mention.user.displayAvatarURL({ dynamic: true }) })
                .setDescription(`${lines}\n\n**Total** : ${totalCards(collection)} carte(s) • Puissance totale : \`${totalPower(collection)}\` • Valeur estimée : \`${totalValue(collection)} coins\`${extra ? `\n\n${extra}` : ""}`)
                .setColor(color)
        }

        const components = []
        if (isSelf) {
            const remaining = lastDraw + DRAW_COOLDOWN - Math.floor(Date.now() / 1000)
            const canDraw = remaining <= 0
            components.push(new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId("mycard_draw")
                    .setLabel(canDraw ? "🎴 Tirer une carte" : `⏳ Prochain tirage dans ${Math.ceil(remaining / 60)} min`)
                    .setStyle(Discord.ButtonStyle.Primary)
                    .setDisabled(!canDraw)
            ))
        }

        const panel = await message.reply(toV2({ embeds: [buildEmbed()], components }))
        if (!isSelf) return

        const collector = panel.createMessageComponentCollector({ time: 60000, max: 1 })

        collector.on("collect", async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: "`❌` Seul l'auteur de la commande peut tirer une carte !", ephemeral: true })
            }
            if (interaction.customId !== "mycard_draw") return

            const fresh = await bot.db.query(`SELECT * FROM cards WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`)
            const freshLastDraw = Number(fresh[0]?.lastDraw || 0)
            const remaining = freshLastDraw + DRAW_COOLDOWN - Math.floor(Date.now() / 1000)
            if (remaining > 0) {
                return interaction.reply({ content: `\`⏳\` Reviens dans ${Math.ceil(remaining / 60)} minute(s) !`, ephemeral: true })
            }

            const drawn = pickRandomCard()
            const freshCollection = parseCollection(fresh[0]?.collection)
            freshCollection[drawn.id] = (freshCollection[drawn.id] || 0) + 1
            const now = Math.floor(Date.now() / 1000)

            await bot.db.query(`UPDATE cards SET collection = '${stringifyCollection(freshCollection).replace(/'/g, "\\'")}', lastDraw = '${now}' WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`)

            await interaction.update(toV2({
                embeds: [buildEmbed(`🎉 Nouvelle carte tirée : ${drawn.emoji} **${drawn.name}** (${drawn.rarity}) !`)],
                components: []
            }))
        })

        collector.on("end", (collected) => {
            if (!collected.size) panel.edit({ components: [] }).catch(() => {})
        })
    })
}
