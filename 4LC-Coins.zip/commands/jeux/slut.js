const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

const cooldownTime = 6 * 60 * 60;

const cooldownsSlut = new Map();

exports.help = {
    name: "slut",
    category: "jeux",
    aliases: ["st"],
    description: "Fais gagner une somme de coins",
    usage: "Pas d'utilisation conseillée"
}

exports.run = async (bot, message, args, color) => {
    if (cooldownsSlut.has(message.author.id + message.guild.id)) {
        const cooldownExpiration = cooldownsSlut.get(message.author.id + message.guild.id) + cooldownTime;
        const remainingCooldown = cooldownExpiration - Math.floor(Date.now() / 1000);

        if (remainingCooldown > 0) {
            const hours = Math.floor(remainingCooldown / 3600);
            const minutes = Math.floor((remainingCooldown % 3600) / 60);
            const seconds = Math.floor(remainingCooldown % 60);

            const cooldownEmbed = new Discord.EmbedBuilder()
                .setDescription(`:x: Vous avez déjà utilisé la commande récemment\n\nRéessayez dans ${hours} heures, ${minutes} minutes et ${seconds} secondes`)
                .setFooter(bot.footer)
                .setColor(color)

            return message.reply(toV2({ embeds: [cooldownEmbed] }));
        }
    }

    bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, req) => {
        if (req.length < 1) return message.reply(':x: Vous n\'avez pas encore commencer refaîtes la commande !')

        const coinsUser = Number(req[0].coins)
        const gain = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;
        const newCoins = coinsUser + gain;

        bot.db.query(`UPDATE user SET coins = '${newCoins}' WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`)

        const winEmbed = new Discord.EmbedBuilder()
            .setDescription(`:coin: Vous venez de gagner **${gain} coins**`)
            .setFooter(bot.footer)
            .setColor(color)

        cooldownsSlut.set(message.author.id + message.guild.id, Math.floor(Date.now() / 1000));

        message.reply(toV2({ embeds: [winEmbed] }))
    })
}
