const Discord = require("discord.js");
const { sendCoinLog } = require("../../utils/logs.js");
const { renderDragonBoard } = require("../../utils/imagelib/dragonBoard.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
    name: "dragon",
    category: "minijeux",
    aliases: ["dragontower", "tower"],
    description: "Grimpe la tour et évite les dragons ! Chaque œuf sûr augmente le multiplicateur, encaisse quand tu veux.",
    usage: "dragon <mise> [difficulté 1-4]"
};

const ROWS = 8;

// Plus la difficulté est haute, plus il y a de dragons par palier (donc moins de cases sûres),
// mais plus le gain par palier franchi est important.
const TIERS = {
    1: { cols: 4, dragons: 1, mult: 1.25, label: "Facile" },
    2: { cols: 4, dragons: 2, mult: 1.90, label: "Moyen" },
    3: { cols: 4, dragons: 3, mult: 3.60, label: "Difficile" },
    4: { cols: 5, dragons: 4, mult: 4.50, label: "Extrême" }
};

// Empêche un joueur de lancer 2 parties de dragon en même temps
const activeGames = new Set();

exports.run = async (bot, message, args, color) => {
    if (!args[0] || isNaN(args[0]) || Number(args[0]) <= 0) {
        return message.reply("Veuillez indiquer une mise valide.");
    }

    const mise = Math.floor(Number(args[0]));
    const tierChoice = TIERS[Number(args[1])] ? Number(args[1]) : 1;
    const { cols, dragons, mult, label } = TIERS[tierChoice];

    const key = `${message.author.id}${message.guild.id}`;
    if (activeGames.has(key)) {
        return message.reply(":x: Vous avez déjà une partie de `dragon` en cours !");
    }

    const req = await bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`);
    if (!req.length) return message.reply(":x: Vous n'avez pas encore commencé les coins, refaîtes la commande !");
    if (Number(req[0].coins) < mise) return message.reply(":x: Vous n'avez pas assez de coins pour cette mise !");

    await bot.db.query(`UPDATE user SET coins = coins - ${mise} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
    activeGames.add(key);

    // Génère les positions des dragons pour chaque palier (0 = tout en bas)
    const board = [];
    for (let r = 0; r < ROWS; r++) {
        board.push(shuffleArray([...Array(cols).keys()]).slice(0, dragons));
    }

    let level = 0;
    let multiplier = 1;
    let finished = false;
    const chosenCols = []; // chosenCols[r] = colonne cliquée par le joueur pour la ligne r (une fois validée)

    // Construit l'image du plateau + son attachment Discord pour l'état actuel de la partie.
    const buildBoardAttachment = (statusText = null, outcome = null) => {
        const png = renderDragonBoard({
            mise,
            multiplier,
            level,
            rows: ROWS,
            cols,
            board,
            difficultyLabel: label,
            finished,
            outcome,
            statusText,
            chosenCols
        });
        return new Discord.AttachmentBuilder(png, { name: "dragon_board.png" });
    };

    const buildEmbed = () => {
        const embed = new Discord.EmbedBuilder()
            .setTitle(`🐉 Tour du Dragon — ${label}`)
            .setImage("attachment://dragon_board.png")
            .setColor(color)
            .setFooter({ text: finished ? "Partie terminée" : "Retire tes gains à tout moment avec le bouton ci-dessous" });
        return embed;
    };

    const buildComponents = (disabled = false) => {
        const rowChoices = new Discord.ActionRowBuilder().addComponents(
            Array.from({ length: cols }, (_, c) =>
                new Discord.ButtonBuilder()
                    .setCustomId(`dragon_col_${c}`)
                    .setLabel(`${c + 1}`)
                    .setStyle(Discord.ButtonStyle.Primary)
                    .setDisabled(disabled)
            )
        );
        const rowCashout = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("dragon_cashout")
                .setLabel("Encaisser")
                .setEmoji("💰")
                .setStyle(Discord.ButtonStyle.Success)
                .setDisabled(disabled)
        );
        return [rowChoices, rowCashout];
    };

    const msg = await message.reply(toV2({ embeds: [buildEmbed()], components: buildComponents(), files: [buildBoardAttachment()] }));

    const endGame = async () => {
        finished = true;
        activeGames.delete(key);
    };

    const collector = msg.createMessageComponentCollector({
        componentType: Discord.ComponentType.Button,
        idle: 60000,
        filter: (i) => i.user.id === message.author.id
    });

    collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "`❌` Seul l'auteur de la partie peut jouer !", ephemeral: true });
        }

        if (interaction.customId === "dragon_cashout") {
            const payout = Math.floor(mise * multiplier);
            await bot.db.query(`UPDATE user SET coins = coins + ${payout} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
            await endGame();
            await interaction.update(toV2({ embeds: [buildEmbed()], components: buildComponents(true), files: [buildBoardAttachment(`ENCAISSE ! +${payout} coins`, "win")] }));
            sendCoinLog(bot, message.guild, {
                type: "Dragon (encaissé)",
                user: message.author,
                amount: payout,
                description: `${message.author} a encaissé une partie de \`dragon\` (mise \`${mise}\`, x${multiplier.toFixed(2)}) et gagne \`${payout} coins\``
            });
            return collector.stop();
        }

        if (interaction.customId.startsWith("dragon_col_")) {
            const col = Number(interaction.customId.replace("dragon_col_", ""));
            const hitDragon = board[level].includes(col);

            if (hitDragon) {
                await endGame();
                await interaction.update(toV2({ embeds: [buildEmbed()], components: buildComponents(true), files: [buildBoardAttachment("PERDU !", "lose")] }));
                sendCoinLog(bot, message.guild, {
                    type: "Dragon (perdu)",
                    user: message.author,
                    amount: -mise,
                    description: `${message.author} a perdu une partie de \`dragon\` (mise \`${mise}\`, atteint palier ${level}/${ROWS})`
                });
                return collector.stop();
            }

            chosenCols[level] = col;
            level++;
            multiplier *= mult;

            if (level === ROWS) {
                const payout = Math.floor(mise * multiplier);
                await bot.db.query(`UPDATE user SET coins = coins + ${payout} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
                await endGame();
                await interaction.update(toV2({ embeds: [buildEmbed()], components: buildComponents(true), files: [buildBoardAttachment(`TOUR CONQUISE ! +${payout} coins`, "win")] }));
                sendCoinLog(bot, message.guild, {
                    type: "Dragon (tour conquise)",
                    user: message.author,
                    amount: payout,
                    description: `${message.author} a conquis toute la tour du \`dragon\` (mise \`${mise}\`, x${multiplier.toFixed(2)}) et gagne \`${payout} coins\``
                });
                return collector.stop();
            }

            return interaction.update(toV2({ embeds: [buildEmbed()], components: buildComponents(), files: [buildBoardAttachment()] }));
        }
    });

    collector.on("end", async () => {
        if (finished) return;
        // Partie inactive trop longtemps : encaissement automatique pour ne pas pénaliser le joueur
        const payout = Math.floor(mise * multiplier);
        await bot.db.query(`UPDATE user SET coins = coins + ${payout} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
        await endGame();
        msg.edit(toV2({ embeds: [buildEmbed()], components: buildComponents(true), files: [buildBoardAttachment(`Partie expiree, encaissement auto : +${payout} coins`, "win")] })).catch(() => {});
    });
};

function shuffleArray(array) {
    const a = array.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}
