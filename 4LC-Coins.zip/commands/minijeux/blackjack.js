const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");

exports.help = {
  name: "blackjack",
  category: "minijeux",
  aliases: ["bj"],
  description: "Joue une vraie partie de blackjack avec tes coins (Tirer / Rester)",
  usage: "blackjack <montant/all>"
};

const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const suits = ["♥", "♦", "♣", "♠"];

exports.run = async (bot, message, args, color) => {
  bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`, async (err, req) => {
    if (req.length < 1) return message.reply(':x: Vous n\'avez pas encore commencer refaîtes la commande !')

    const coins = Number(req[0]?.coins || 0);
    const bet = parseBet(args[0], coins);

    if (!bet || bet < 1) return message.reply(toV2({ embeds: [errorEmbed("Précise une mise valide: blackjack <montant/all>", color)] }));
    if (coins < bet) return message.reply(toV2({ embeds: [errorEmbed("Tu n'as pas assez de coins.", color)] }));

    const deck = makeDeck();
    const player = [draw(deck), draw(deck)];
    const dealer = [draw(deck), draw(deck)];

    // Blackjack naturel dès la distribution
    if (handValue(player) === 21) {
      return finishGame(bot, message, color, coins, bet, player, dealer, deck, true);
    }

    const buttons = () => new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder().setCustomId("bj_hit").setLabel("Tirer").setStyle(Discord.ButtonStyle.Primary),
      new Discord.ButtonBuilder().setCustomId("bj_stand").setLabel("Rester").setStyle(Discord.ButtonStyle.Secondary)
    );

    const embed = buildEmbed(message, color, player, dealer, bet, false);
    const msg = await message.reply(toV2({ embeds: [embed], components: [buttons()] }));

    const collector = msg.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 60000
    });

    collector.on("collect", async (interaction) => {
      if (interaction.customId === "bj_hit") {
        player.push(draw(deck));

        if (handValue(player) > 21) {
          collector.stop("bust");
          await interaction.update(toV2({ embeds: [buildEmbed(message, color, player, dealer, bet, true)], components: [] }));
          return finishGame(bot, message, color, coins, bet, player, dealer, deck, false, interaction);
        }

        if (handValue(player) === 21) {
          collector.stop("stand");
          await interaction.update(toV2({ embeds: [buildEmbed(message, color, player, dealer, bet, true)], components: [] }));
          return finishGame(bot, message, color, coins, bet, player, dealer, deck, false, interaction);
        }

        await interaction.update(toV2({ embeds: [buildEmbed(message, color, player, dealer, bet, false)], components: [buttons()] }));
      } else if (interaction.customId === "bj_stand") {
        collector.stop("stand");
        await interaction.update(toV2({ embeds: [buildEmbed(message, color, player, dealer, bet, true)], components: [] }));
        return finishGame(bot, message, color, coins, bet, player, dealer, deck, false, interaction);
      }
    });

    collector.on("end", async (collected, reason) => {
      if (reason === "time") {
        // Timeout -> on considère que le joueur reste
        try {
          await msg.edit(toV2({ embeds: [buildEmbed(message, color, player, dealer, bet, true)], components: [] }));
        } catch (e) {}
        finishGame(bot, message, color, coins, bet, player, dealer, deck, false);
      }
    });
  });
};

function finishGame(bot, message, color, coins, bet, player, dealer, deck, isNaturalBlackjack, interaction) {
  const playerValue = handValue(player);
  let dealerValue = handValue(dealer);

  if (playerValue <= 21) {
    while (dealerValue < 17) {
      dealer.push(draw(deck));
      dealerValue = handValue(dealer);
    }
  }

  let delta = 0;
  let title = "Égalité";

  if (playerValue > 21) {
    delta = -bet;
    title = "Vous avez perdu";
  } else if (isNaturalBlackjack && dealerValue !== 21) {
    delta = Math.ceil(bet * 1.5);
    title = "Blackjack ! Vous avez gagné";
  } else if (dealerValue > 21 || playerValue > dealerValue) {
    delta = bet;
    title = "Vous avez gagné";
  } else if (dealerValue > playerValue) {
    delta = -bet;
    title = "Vous avez perdu";
  }

  const newCoins = Math.max(0, coins + delta);
  bot.db.query(`UPDATE user SET coins = '${newCoins}' WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);

  const resultEmbed = new Discord.EmbedBuilder()
    .setTitle(`${title} !`)
    .setDescription([
      `Votre main: **${formatHand(player)}** (${playerValue})`,
      `Main de ${message.client.user.username}: **${formatHand(dealer)}** (${dealerValue})`,
      delta === 0 ? "Résultat: mise rendue." : `Résultat: ${delta > 0 ? "+" : ""}${delta} coins.`,
      `Solde: **${newCoins} coins**`
    ].join("\n"))
    .setColor(color)
    .setFooter(bot.footer);

  if (interaction) {
    interaction.followUp(toV2({ embeds: [resultEmbed] }));
  } else {
    message.channel.send(toV2({ embeds: [resultEmbed] }));
  }
}

function buildEmbed(message, color, player, dealer, bet, revealDealer) {
  const playerValue = handValue(player);
  const dealerDisplay = revealDealer
    ? `**${formatHand(dealer)}** (${handValue(dealer)})`
    : `**${dealer[0].rank}${dealer[0].suit}, ?**`;

  return new Discord.EmbedBuilder()
    .setTitle(`Blackjack - Mise: ${bet} coins`)
    .setDescription([
      `Votre main: **${formatHand(player)}** (${playerValue})`,
      `Main de ${message.client.user.username}: ${dealerDisplay}`
    ].join("\n"))
    .setColor(color)
    .setFooter({ text: "Tirer pour piocher une carte, Rester pour arrêter" });
}

function parseBet(value, coins) {
  if (!value) return 0;
  if (String(value).toLowerCase() === "all") return coins;
  const amount = Number(value);
  if (!Number.isInteger(amount)) return 0;
  return amount;
}

function makeDeck() {
  return suits.flatMap((suit) => ranks.map((rank) => ({ rank, suit })));
}

function draw(deck) {
  return deck.splice(Math.floor(Math.random() * deck.length), 1)[0];
}

function valueOf(rank) {
  if (rank === "A") return 11;
  if (["J", "Q", "K"].includes(rank)) return 10;
  return Number(rank);
}

function handValue(hand) {
  let value = hand.reduce((sum, card) => sum + valueOf(card.rank), 0);
  let aces = hand.filter((card) => card.rank === "A").length;
  while (value > 21 && aces > 0) {
    value -= 10;
    aces -= 1;
  }
  return value;
}

function formatHand(hand) {
  return hand.map((card) => `${card.rank}${card.suit}`).join(", ");
}

function errorEmbed(text, color) {
  return new Discord.EmbedBuilder().setDescription(`:x: ${text}`).setColor(color);
}
