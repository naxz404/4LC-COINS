const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");

const PUISSANCE4_BOT_ID = "746476061436542997"

exports.help = {
    name: "puissance4",
    category: "minijeux",
    aliases: ["p4", "puissance"],
    description: "Invite les membres à jouer au Puissance 4 pour gagner (ou perdre) des coins",
    usage: "puissance4"
}

exports.run = async (bot, message, args, color) => {
    const embed = new Discord.EmbedBuilder()
        .setTitle(`🔴 🟡 Envie de jouer au Puissance 4 ?`)
        .setDescription(
            `Affrontez un(e) ami(e) et gagnez des coins en remportant la partie !\n\n` +
            `Pour commencer, faites la commande \`/start\` avec le bot <@${PUISSANCE4_BOT_ID}> et choisissez votre adversaire.\n\n` +
            `\`🏆\` En cas de victoire vous gagnez des coins\n` +
            `\`💸\` En cas de défaite vous en perdez`
        )
        .setColor(color)
        .setFooter(bot.footer)

    message.channel.send(toV2({ embeds: [embed] }))
}
