const Discord = require("discord.js");
const { toV2 } = require("../../utils/embedV2.js");
const { renderMorpionBoard } = require("../../utils/imagelib/morpionBoard.js");
const { sendCoinLog } = require("../../utils/logs.js");

exports.help = {
    name: "morpion",
    category: "minijeux",
    aliases: ["tictactoe", "ttt"],
    description: "Défie un membre au morpion : chacun choisit sa propre mise depuis l'embed, le gagnant remporte tout !",
    usage: "morpion @user"
    // Pas de "permission" ici : tout le monde peut utiliser cette commande, comme &dragon.
};

// Empêche un joueur de lancer/configurer/jouer 2 morpions en même temps
const activePlayers = new Set();

const LINES = [
    [[0, 0], [0, 1], [0, 2]],
    [[1, 0], [1, 1], [1, 2]],
    [[2, 0], [2, 1], [2, 2]],
    [[0, 0], [1, 0], [2, 0]],
    [[0, 1], [1, 1], [2, 1]],
    [[0, 2], [1, 2], [2, 2]],
    [[0, 0], [1, 1], [2, 2]],
    [[0, 2], [1, 1], [2, 0]]
];

function checkWinner(grid) {
    for (const line of LINES) {
        const [[r1, c1], [r2, c2], [r3, c3]] = line;
        if (grid[r1][c1] && grid[r1][c1] === grid[r2][c2] && grid[r1][c1] === grid[r3][c3]) {
            return { symbol: grid[r1][c1], line };
        }
    }
    return null;
}

function isFull(grid) {
    return grid.every((row) => row.every((cell) => cell !== null));
}

exports.run = async (bot, message, args, color) => {
    if (!args[0]) {
        const helpEmbed = new Discord.EmbedBuilder()
            .setAuthor({ name: "❌ ⭕ Morpion — Comment ça marche ?" })
            .setDescription([
                "Défie un membre du serveur dans un morpion (tic-tac-toe) avec mise de coins !",
                "",
                "**Utilisation :**",
                `\`${message.prefix || '&'}morpion @membre\``,
                "",
                "**Déroulement :**",
                "1️⃣ Un embed de configuration s'affiche avec un bouton **💰 Définir ma mise**.",
                "2️⃣ Toi **et** ton adversaire cliquez chacun sur ce bouton pour choisir, dans une fenêtre, combien de coins vous misez (vous pouvez miser des montants différents).",
                "3️⃣ Dès que les deux mises sont posées, la partie démarre automatiquement avec un plateau 3x3 en boutons.",
                "4️⃣ Vous jouez chacun votre tour (❌ commence). Cliquez sur une case pour y poser votre symbole.",
                "",
                "**Résultat :**",
                "🏆 Le gagnant remporte la mise de l'adversaire (le pot des deux mises).",
                "🤝 Match nul → chacun récupère sa propre mise.",
                "❌ Le bouton **Annuler** rembourse tout avant le début de la partie."
            ].join("\n"))
            .setColor(color)
            .setFooter(bot.footer);
        return message.reply(toV2({ embeds: [helpEmbed] }));
    }

    const opponent = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user;
    if (!opponent) return message.reply(":x: `ERROR:` Pas de membre trouvé !");
    if (opponent.id === message.author.id) return message.reply(":x: Tu ne peux pas jouer contre toi-même !");
    if (opponent.bot) return message.reply(":x: Tu ne peux pas jouer contre un bot !");

    const key1 = message.author.id + message.guild.id;
    const key2 = opponent.id + message.guild.id;
    if (activePlayers.has(key1)) return message.reply(":x: Tu as déjà une partie de `morpion` en cours !");
    if (activePlayers.has(key2)) return message.reply(`:x: **${opponent.username}** a déjà une partie de \`morpion\` en cours !`);

    const [authorRows, opponentRows] = await Promise.all([
        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${message.author.id}"`),
        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${opponent.id}"`)
    ]);
    if (!authorRows.length) return message.reply(":x: Tu n'as pas encore de profil, refais la commande !");
    if (!opponentRows.length) return message.reply(`:x: **${opponent.username}** n'a pas encore de profil !`);

    activePlayers.add(key1);
    activePlayers.add(key2);

    const players = { [message.author.id]: { user: message.author, symbol: "X" }, [opponent.id]: { user: opponent, symbol: "O" } };
    const stakes = {}; // stakes[userId] = montant misé (une fois confirmé et déduit)
    let setupCancelled = false;

    const buildSetupEmbed = (note) => {
        const stakeLine = (userId) => {
            const p = players[userId];
            return stakes[userId] !== undefined
                ? `${p.user} (${p.symbol}) : ✅ \`${stakes[userId]} coins\` misés`
                : `${p.user} (${p.symbol}) : ⏳ en attente...`;
        };
        return new Discord.EmbedBuilder()
            .setAuthor({ name: "❌ ⭕ Défi Morpion — Configuration" })
            .setDescription([
                `Chacun choisit **sa propre mise** avec le bouton ci-dessous.`,
                `Le gagnant remporte la mise de l'adversaire, le perdant perd la sienne !`,
                "",
                stakeLine(message.author.id),
                stakeLine(opponent.id),
                "",
                note ? note : "*Vous avez 90 secondes pour configurer la partie.*"
            ].join("\n"))
            .setColor(color);
    };

    const buildSetupComponents = (disabled = false) => [
        new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId("morpion_setmise").setLabel("Définir ma mise").setEmoji("💰").setStyle(Discord.ButtonStyle.Success).setDisabled(disabled),
            new Discord.ButtonBuilder().setCustomId("morpion_cancel").setLabel("Annuler").setEmoji("❌").setStyle(Discord.ButtonStyle.Danger).setDisabled(disabled)
        )
    ];

    const refundStakes = async () => {
        for (const userId in stakes) {
            await bot.db.query(`UPDATE user SET coins = coins + ${stakes[userId]} WHERE guildId = '${message.guild.id}' AND userId = '${userId}'`);
        }
    };

    const setupMsg = await message.reply(toV2({ embeds: [buildSetupEmbed()], components: buildSetupComponents() }));

    const setupCollector = setupMsg.createMessageComponentCollector({ time: 90000 });

    setupCollector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id && interaction.user.id !== opponent.id) {
            return interaction.reply({ content: ":x: Cette partie ne te concerne pas !", flags: Discord.MessageFlags.Ephemeral });
        }

        if (interaction.customId === "morpion_cancel") {
            setupCancelled = true;
            await refundStakes();
            activePlayers.delete(key1);
            activePlayers.delete(key2);
            setupCollector.stop("cancelled");
            return interaction.update(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(`:x: ${interaction.user} a annulé le défi. Mises remboursées.`).setColor(color)], components: [] }));
        }

        if (interaction.customId === "morpion_setmise") {
            if (stakes[interaction.user.id] !== undefined) {
                return interaction.reply({ content: ":x: Tu as déjà défini ta mise !", flags: Discord.MessageFlags.Ephemeral });
            }

            const modal = new Discord.ModalBuilder().setCustomId(`morpion_modal_${interaction.user.id}`).setTitle("Ta mise pour le morpion");
            const input = new Discord.TextInputBuilder()
                .setCustomId("morpion_amount")
                .setLabel("Combien de coins veux-tu miser ?")
                .setStyle(Discord.TextInputStyle.Short)
                .setPlaceholder("Ex: 500")
                .setRequired(true);
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
            await interaction.showModal(modal);

            try {
                const submitted = await interaction.awaitModalSubmit({
                    filter: (i) => i.customId === `morpion_modal_${interaction.user.id}` && i.user.id === interaction.user.id,
                    time: 60000
                });

                if (setupCancelled || stakes[interaction.user.id] !== undefined) {
                    return submitted.reply({ content: ":x: Trop tard, la mise n'a pas pu être prise en compte !", flags: Discord.MessageFlags.Ephemeral });
                }

                const amount = Math.floor(Number(submitted.fields.getTextInputValue("morpion_amount").trim()));
                if (!Number.isFinite(amount) || amount <= 0) {
                    return submitted.reply({ content: ":x: Montant invalide !", flags: Discord.MessageFlags.Ephemeral });
                }

                const rows = await bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${interaction.user.id}"`);
                const coins = Number(rows[0]?.coins || 0);
                if (coins < amount) {
                    return submitted.reply({ content: `:x: Tu n'as pas assez de coins ! (Tu as \`${coins} coins\`)`, flags: Discord.MessageFlags.Ephemeral });
                }

                await bot.db.query(`UPDATE user SET coins = coins - ${amount} WHERE guildId = "${message.guild.id}" AND userId = "${interaction.user.id}"`);
                stakes[interaction.user.id] = amount;

                await submitted.reply({ content: `✅ Mise confirmée : \`${amount} coins\` !`, flags: Discord.MessageFlags.Ephemeral });
                await setupMsg.edit(toV2({ embeds: [buildSetupEmbed()], components: buildSetupComponents() })).catch(() => {});

                if (stakes[message.author.id] !== undefined && stakes[opponent.id] !== undefined) {
                    setupCollector.stop("ready");
                }
            } catch (e) {
                // Timeout de la modale, rien n'est déduit
            }
        }
    });

    setupCollector.on("end", async (collected, reason) => {
        if (reason === "cancelled") return;

        if (reason !== "ready") {
            // Temps écoulé sans que les deux joueurs aient misé : on rembourse et on annule
            await refundStakes();
            activePlayers.delete(key1);
            activePlayers.delete(key2);
            return setupMsg.edit(toV2({ embeds: [new Discord.EmbedBuilder().setDescription(":x: Configuration expirée, défi annulé. Mises remboursées.").setColor(color)], components: [] })).catch(() => {});
        }

        await setupMsg.edit(toV2({ embeds: [buildSetupEmbed("🎮 Les deux mises sont posées, la partie commence !")], components: [] })).catch(() => {});
        startGame();
    });

    async function startGame() {
        const pot = stakes[message.author.id] + stakes[opponent.id];
        const grid = [[null, null, null], [null, null, null], [null, null, null]];
        let turn = "X";
        let finished = false;

        const buildAttachment = (statusText = null, outcome = null, winnerLine = []) => {
            const png = renderMorpionBoard({ grid, turnSymbol: turn, pot, finished, outcome, winnerLine, statusText });
            return new Discord.AttachmentBuilder(png, { name: "morpion_board.png" });
        };

        const currentPlayerId = () => (turn === "X" ? message.author.id : opponent.id);

        const buildEmbed = () => new Discord.EmbedBuilder()
            .setTitle(`❌ ${message.author.username} (${stakes[message.author.id]}) 🆚 ${opponent.username} (${stakes[opponent.id]}) ⭕`)
            .setImage("attachment://morpion_board.png")
            .setColor(color)
            .setFooter({ text: finished ? "Partie terminée" : `C'est au tour de ${players[currentPlayerId()].user.username} (${turn})` });

        const buildComponents = (disabled = false) => {
            const rows = [];
            for (let r = 0; r < 3; r++) {
                const row = new Discord.ActionRowBuilder();
                for (let col = 0; col < 3; col++) {
                    const cellValue = grid[r][col];
                    row.addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId(`morpion_${r}_${col}`)
                            .setLabel(cellValue || "\u200b")
                            .setStyle(cellValue === "X" ? Discord.ButtonStyle.Danger : cellValue === "O" ? Discord.ButtonStyle.Primary : Discord.ButtonStyle.Secondary)
                            .setDisabled(disabled || cellValue !== null)
                    );
                }
                rows.push(row);
            }
            return rows;
        };

        const endGame = () => {
            finished = true;
            activePlayers.delete(key1);
            activePlayers.delete(key2);
        };

        const gameMsg = await message.channel.send(toV2({ embeds: [buildEmbed()], components: buildComponents(), files: [buildAttachment()] }));

        const collector = gameMsg.createMessageComponentCollector({
            componentType: Discord.ComponentType.Button,
            idle: 90000
        });

        collector.on("collect", async (interaction) => {
            const expectedId = currentPlayerId();
            if (interaction.user.id !== expectedId) {
                return interaction.reply({ content: `:x: Ce n'est pas ton tour ! C'est à **${players[expectedId].user.username}** de jouer.`, flags: Discord.MessageFlags.Ephemeral });
            }

            const [, rStr, cStr] = interaction.customId.split("_");
            const r = Number(rStr), col = Number(cStr);
            if (grid[r][col] !== null) return interaction.reply({ content: ":x: Cette case est déjà prise !", flags: Discord.MessageFlags.Ephemeral });

            grid[r][col] = turn;

            const winner = checkWinner(grid);
            if (winner) {
                const winnerId = winner.symbol === "X" ? message.author.id : opponent.id;
                const loserId = winner.symbol === "X" ? opponent.id : message.author.id;
                await bot.db.query(`UPDATE user SET coins = coins + ${pot} WHERE guildId = '${message.guild.id}' AND userId = '${winnerId}'`);
                endGame();
                await interaction.update(toV2({
                    embeds: [buildEmbed()],
                    components: buildComponents(true),
                    files: [buildAttachment(`VICTOIRE DE ${winner.symbol} (+${pot} COINS)`, "win", winner.line)]
                }));
                sendCoinLog(bot, message.guild, {
                    type: "Morpion (gagné)",
                    user: players[winnerId].user,
                    amount: pot,
                    description: `${players[winnerId].user} a battu ${players[loserId].user} au \`morpion\` (mises \`${stakes[message.author.id]}\`/\`${stakes[opponent.id]}\`) et remporte \`${pot} coins\`.`
                });
                return collector.stop();
            }

            if (isFull(grid)) {
                await bot.db.query(`UPDATE user SET coins = coins + ${stakes[message.author.id]} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
                await bot.db.query(`UPDATE user SET coins = coins + ${stakes[opponent.id]} WHERE guildId = '${message.guild.id}' AND userId = '${opponent.id}'`);
                endGame();
                await interaction.update(toV2({
                    embeds: [buildEmbed()],
                    components: buildComponents(true),
                    files: [buildAttachment("MATCH NUL, MISES REMBOURSEES", "draw")]
                }));
                sendCoinLog(bot, message.guild, {
                    type: "Morpion (nul)",
                    user: message.author,
                    description: `Match nul entre ${message.author} et ${opponent} au \`morpion\` (mises remboursées à chacun).`
                });
                return collector.stop();
            }

            turn = turn === "X" ? "O" : "X";
            await interaction.update(toV2({ embeds: [buildEmbed()], components: buildComponents(), files: [buildAttachment()] }));
        });

        collector.on("end", async () => {
            if (finished) return;
            // Partie inactive trop longtemps : les mises sont remboursées, personne n'est pénalisé
            await bot.db.query(`UPDATE user SET coins = coins + ${stakes[message.author.id]} WHERE guildId = '${message.guild.id}' AND userId = '${message.author.id}'`);
            await bot.db.query(`UPDATE user SET coins = coins + ${stakes[opponent.id]} WHERE guildId = '${message.guild.id}' AND userId = '${opponent.id}'`);
            endGame();
            gameMsg.edit(toV2({
                embeds: [buildEmbed()],
                components: buildComponents(true),
                files: [buildAttachment("PARTIE EXPIREE, MISES REMBOURSEES", "draw")]
            })).catch(() => {});
        });
    }
};
