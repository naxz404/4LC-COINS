const Discord = require("discord.js")
const { toV2 } = require("../../utils/embedV2.js");
const { renderProfileBoard } = require("../../utils/imagelib/profileBoard.js");

exports.help = {
    name: "profil",
    category: "gestioncoins",
    aliases: ["profile", "inv", "inventaire"],
    description: "Affiche les informations d'un utilisateur",
    usage: "Pas d'utilisation conseillée"
}

const cooldownTime2 = 2 * 60 * 60;

exports.run = async (bot, message, args, color) => {
    const mention = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    // ---- Récupération de toutes les données en parallèle (corrige le bug de course de l'ancienne version) ----
    const [userRows, batimentRows, jobRows] = await Promise.all([
        bot.db.query(`SELECT * FROM user WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`),
        bot.db.query(`SELECT * FROM batiment WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`),
        bot.db.query(`SELECT * FROM job WHERE guildId = "${message.guild.id}" AND userId = "${mention.id}"`)
    ]);

    if (!userRows.length) return message.reply(":x: Cet utilisateur n'a pas encore de profil !");
    const user = userRows[0];
    const bat = batimentRows[0] || {};
    const jobRow = jobRows[0] || {};

    let teamname = "Aucune team";
    const teamid = user.team && user.team !== "no" ? user.team : null;
    if (teamid) {
        const teamRows = await bot.db.query(`SELECT * FROM team WHERE guildId = "${message.guild.id}" AND id = "${teamid}"`);
        if (teamRows.length) teamname = teamRows[0].nom;
    }

    let antirob = "Non actif";
    let antirobActive = false;
    if (bot.antirob.has(mention.id + message.guild.id)) {
        const cooldownExpiration = bot.antirob.get(mention.id + message.guild.id) + cooldownTime2;
        const remainingCooldown = cooldownExpiration - Math.floor(Date.now() / 1000);
        if (remainingCooldown > 0) {
            const hours = Math.floor(remainingCooldown / 3600);
            const minutes = Math.floor((remainingCooldown % 3600) / 60);
            antirob = `Actif (${hours}h ${minutes}m)`;
            antirobActive = true;
        }
    }

    let job = "Chômeur";
    for (const columnName in jobRow) {
        if (columnName !== "cultivateur" && columnName !== "blanchisseur" && jobRow[columnName] === "yes") {
            job = columnName;
            break;
        }
    }

    const png = renderProfileBoard({
        coins: user.coins || 0,
        banque: user.banque || 0,
        reputation: user.reputation || 0,
        job,
        entrepot: bat.entrepot || 0,
        antirobText: antirob,
        antirobActive,
        batiments: {
            bar: bat.bar === "yes",
            garage: bat.garage === "yes",
            magasin: bat.magasin === "yes",
            cinema: bat.cinema === "yes",
            gare: bat.gare === "yes",
            mairie: bat.mairie === "yes"
        }
    });
    const attachment = new Discord.AttachmentBuilder(png, { name: "profil_board.png" });

    const coinsEmbed = new Discord.EmbedBuilder()
        .setAuthor({ name: `Profil de ${mention.user.username}`, iconURL: mention.user.displayAvatarURL({ dynamic: true }), url: 'https://discord.gg/ddJMXWYJ29' })
        .setThumbnail(mention.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`⚔️ **Team :** ${teamname}`)
        .setImage("attachment://profil_board.png")
        .setColor(color)
        .setFooter(bot.footer);

    message.reply(toV2({ embeds: [coinsEmbed], files: [attachment] }));
}

