const Discord = require('discord.js');
const { toV2 } = require('../../utils/embedV2.js');

exports.help = { name: 'topall', category: 'gestioncoins', aliases: ['tops'], description: 'Affiche les cinq classements', usage: 'topall' };

/**
 * Construit les 5 embeds de classement d'un serveur. Réutilisée par &topall et par l'auto-top planifié.
 */
async function buildTopAllEmbeds(bot, guild, color) {
  const rows = await bot.db.query(`SELECT * FROM user WHERE guildId = '${guild.id}'`);
  const rankings = [
    ['Coins en poche', 'coins', 'coins :coin:'],
    ['Coins en banque', 'banque', 'coins :bank:'],
    ['Réputation', 'reputation', 'réputation :small_red_triangle:'],
    ['Paliers XP', 'palier', 'palier :star:'],
    ['Victoires en duel', 'victoires', 'victoires :crossed_swords:']
  ];
  return rankings.map(([title, key, label]) => {
    const lines = rows.slice().sort((a, b) => Number(b[key] || 0) - Number(a[key] || 0)).slice(0, 10).map((row, index) => {
      const member = guild.members.cache.get(row.userId);
      return member ? `**${index + 1}.** ${member.user.username} — \`${row[key] || 0} ${label}\`` : null;
    }).filter(Boolean);
    return new Discord.EmbedBuilder().setColor(color).setTitle(`Top ${title} — ${guild.name}`).setDescription(lines.join('\n') || 'Aucune donnée.').setFooter(bot.footer);
  });
}

exports.buildTopAllEmbeds = buildTopAllEmbeds;

exports.run = async (bot, message, args, color) => {
  const embeds = await buildTopAllEmbeds(bot, message.guild, color);
  return message.channel.send(toV2({ embeds }));
};
