const Discord = require("discord.js")

exports.help = {
    name: "setprofil",
    category: "administration",
    aliases: ["setprofile"],
    description: "Modifie avatar, pseudo ou encore activité du bot !",
    usage: "Pas d'utilisation conseillée",
    permission: "buyer"
}

const ACTIVITY_EMOJIS = {
    Playing: "🎮",
    Watching: "📺",
    Listening: "🎧",
    Streaming: "🔴"
}

const ACTIVITY_LABELS_FR = {
    Playing: "Joue à",
    Watching: "Regarde",
    Listening: "Écoute",
    Streaming: "Stream"
}

// Validation volontairement permissive : accepte tout lien http/https (cdn Discord,
// jfif, liens avec paramètres ?ex=...&format=webp, etc.). C'est Discord qui validera
// réellement le contenu au moment de l'upload (setAvatar / setBanner géré via try/catch).
const isValidHttpUrl = (str) => {
    try {
        const u = new URL(str);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch (e) {
        return false;
    }
}

exports.run = async (bot, message, args, color) => {

    bot.db.query(`SELECT * FROM bot WHERE botId = "${bot.user.id}"`, async (err, req) => {
        if (err) console.error(err);

        let statut = req?.[0]?.statut || null;
        let type = req?.[0]?.type || null;
        const accent = Discord.resolveColor(color ?? "LightGrey");

        // Le champ banner n'est pas toujours mis en cache par le gateway : on force un fetch
        await bot.user.fetch().catch(() => {});

        // ---------- Construction du panneau principal (Components V2) ----------
        const buildMainContainer = (note = null) => {
            const container = new Discord.ContainerBuilder().setAccentColor(accent);

            container.addSectionComponents(
                new Discord.SectionBuilder()
                    .addTextDisplayComponents(
                        new Discord.TextDisplayBuilder().setContent(
                            `# ⚙️ Paramètres du profil\n**${bot.user.username}**`
                        ),
                        new Discord.TextDisplayBuilder().setContent(
                            `Personnalise l'apparence et le comportement du bot directement depuis ce panneau.`
                        )
                    )
                    .setThumbnailAccessory(
                        new Discord.ThumbnailBuilder()
                            .setURL(bot.user.displayAvatarURL({ size: 256 }))
                            .setDescription("Avatar actuel du bot")
                    )
            );

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(true).setSpacing(Discord.SeparatorSpacingSize.Large)
            );

            container.addTextDisplayComponents(
                new Discord.TextDisplayBuilder().setContent(
                    [
                        `### ✏️ Nom d'utilisateur`,
                        `\`${bot.user.username}\``
                    ].join("\n")
                )
            );

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(false).setSpacing(Discord.SeparatorSpacingSize.Small)
            );

            container.addTextDisplayComponents(
                new Discord.TextDisplayBuilder().setContent(
                    [
                        `### 🎬 Avatar`,
                        `[Voir l'image en grand](${bot.user.displayAvatarURL({ size: 1024 })})`
                    ].join("\n")
                )
            );

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(false).setSpacing(Discord.SeparatorSpacingSize.Small)
            );

            const bannerURL = bot.user.bannerURL({ size: 1024 }) || null;

            container.addTextDisplayComponents(
                new Discord.TextDisplayBuilder().setContent(
                    [
                        `### 🖼️ Bannière`,
                        bannerURL ? `[Voir l'image en grand](${bannerURL})` : "*Aucune bannière définie*"
                    ].join("\n")
                )
            );

            if (bannerURL) {
                container.addMediaGalleryComponents(
                    new Discord.MediaGalleryBuilder().addItems(
                        new Discord.MediaGalleryItemBuilder()
                            .setURL(bannerURL)
                            .setDescription("Bannière actuelle du bot")
                    )
                );
            }

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(false).setSpacing(Discord.SeparatorSpacingSize.Small)
            );

            container.addTextDisplayComponents(
                new Discord.TextDisplayBuilder().setContent(
                    [
                        `### 📱 Activité`,
                        statut
                            ? `${ACTIVITY_EMOJIS[type] || "📱"} ${ACTIVITY_LABELS_FR[type] || type} \`${statut}\``
                            : "*Aucune activité définie*"
                    ].join("\n")
                )
            );

            if (note) {
                container.addSeparatorComponents(
                    new Discord.SeparatorBuilder().setDivider(true).setSpacing(Discord.SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new Discord.TextDisplayBuilder().setContent(note)
                );
            }

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(true).setSpacing(Discord.SeparatorSpacingSize.Large)
            );

            container.addActionRowComponents(
                new Discord.ActionRowBuilder().addComponents(
                    new Discord.StringSelectMenuBuilder()
                        .setCustomId('profilbotselect')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setPlaceholder("Faire une action")
                        .addOptions(
                            new Discord.StringSelectMenuOptionBuilder()
                                .setLabel("Changer le nom")
                                .setEmoji(`✏️`)
                                .setValue("namebot")
                                .setDescription(`Change le nom du bot`),
                            new Discord.StringSelectMenuOptionBuilder()
                                .setLabel("Changer l'avatar")
                                .setEmoji(`🎬`)
                                .setValue("avatarbot")
                                .setDescription(`Change l'image de profil du bot`),
                            new Discord.StringSelectMenuOptionBuilder()
                                .setLabel("Changer la bannière")
                                .setEmoji(`🖼️`)
                                .setValue("bannerbot")
                                .setDescription(`Change la bannière du profil du bot`),
                            new Discord.StringSelectMenuOptionBuilder()
                                .setLabel("Changer l'activité")
                                .setEmoji(`📱`)
                                .setValue("activitybot")
                                .setDescription(`Change l'activité et le type d'activité du bot`),
                            new Discord.StringSelectMenuOptionBuilder()
                                .setLabel("Fermer")
                                .setEmoji(`❌`)
                                .setValue("checkmenu")
                                .setDescription(`Ferme le menu`)
                        )
                )
            );

            const linkButtons = [
                new Discord.ButtonBuilder()
                    .setLabel("Voir l'avatar")
                    .setEmoji("🔗")
                    .setStyle(Discord.ButtonStyle.Link)
                    .setURL(bot.user.displayAvatarURL({ size: 1024 }))
            ];

            if (bannerURL) {
                linkButtons.push(
                    new Discord.ButtonBuilder()
                        .setLabel("Voir la bannière")
                        .setEmoji("🖼️")
                        .setStyle(Discord.ButtonStyle.Link)
                        .setURL(bannerURL)
                );
            }

            container.addActionRowComponents(
                new Discord.ActionRowBuilder().addComponents(...linkButtons)
            );

            container.addSeparatorComponents(
                new Discord.SeparatorBuilder().setDivider(false).setSpacing(Discord.SeparatorSpacingSize.Small)
            );

            container.addTextDisplayComponents(
                new Discord.TextDisplayBuilder().setContent(
                    `-# ID: ${bot.user.id} • Menu actif pendant 3 minutes • ${new Date().toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })}`
                )
            );

            return container;
        };

        // ---------- Petit panneau de statut (succès / erreur) pour les réponses éphémères ----------
        const buildStatusContainer = (ok, text, thumbnailURL = null) => {
            const container = new Discord.ContainerBuilder().setAccentColor(ok ? accent : Discord.resolveColor("Red"));

            if (thumbnailURL) {
                container.addSectionComponents(
                    new Discord.SectionBuilder()
                        .addTextDisplayComponents(
                            new Discord.TextDisplayBuilder().setContent(`${ok ? "✅" : "❌"} ${text}`)
                        )
                        .setThumbnailAccessory(
                            new Discord.ThumbnailBuilder().setURL(thumbnailURL)
                        )
                );
            } else {
                container.addTextDisplayComponents(
                    new Discord.TextDisplayBuilder().setContent(`${ok ? "✅" : "❌"} ${text}`)
                );
            }

            return container;
        };

        const msg = await message.reply({
            components: [buildMainContainer()],
            flags: Discord.MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({
            componentType: Discord.ComponentType.StringSelect,
            time: 180000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({
                    components: [buildStatusContainer(false, "Tu n'as pas la permission d'utiliser ce menu !")],
                    flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                });
            }

            const choix = interaction.values[0];

            // ---- Fermer le menu ----
            if (choix === 'checkmenu') {
                const closedContainer = buildMainContainer("*Menu fermé.*");
                await interaction.update({ components: [closedContainer], flags: Discord.MessageFlags.IsComponentsV2 });
                return collector.stop();
            }

            // ---- Changer le nom du bot ----
            if (choix === 'namebot') {
                const modal = new Discord.ModalBuilder()
                    .setCustomId('modal_namebot')
                    .setTitle('Changer le nom du bot');

                const input = new Discord.TextInputBuilder()
                    .setCustomId('namebot_input')
                    .setLabel('Nouveau nom du bot')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder('Ex: 4LC Coins')
                    .setValue(bot.user.username)
                    .setMinLength(2)
                    .setMaxLength(32)
                    .setRequired(true);

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
                await interaction.showModal(modal);

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === 'modal_namebot' && i.user.id === message.author.id,
                        time: 60000
                    });

                    const username = submitted.fields.getTextInputValue('namebot_input').trim();

                    try {
                        await bot.user.setUsername(username);
                        await submitted.reply({
                            components: [buildStatusContainer(true, `Le nom du bot a été changé en \`${username}\`.`)],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                        await msg.edit({ components: [buildMainContainer()], flags: Discord.MessageFlags.IsComponentsV2 }).catch(() => {});
                    } catch (e) {
                        await submitted.reply({
                            components: [buildStatusContainer(false, "Impossible de changer le nom du bot ! (Discord limite cette action à deux fois par heure)")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }
                } catch (e) {
                    // Timeout, l'utilisateur n'a rien soumis
                }
            }

            // ---- Changer l'avatar du bot ----
            if (choix === 'avatarbot') {
                const modal = new Discord.ModalBuilder()
                    .setCustomId('modal_avatarbot')
                    .setTitle('Changer l\'avatar du bot');

                const input = new Discord.TextInputBuilder()
                    .setCustomId('avatarbot_input')
                    .setLabel('Lien de la nouvelle image (URL)')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder('https://exemple.com/image.png')
                    .setRequired(true);

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
                await interaction.showModal(modal);

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === 'modal_avatarbot' && i.user.id === message.author.id,
                        time: 60000
                    });

                    const avatar = submitted.fields.getTextInputValue('avatarbot_input').trim();

                    if (!isValidHttpUrl(avatar)) {
                        return submitted.reply({
                            components: [buildStatusContainer(false, "Ce lien n'est pas une URL valide (doit commencer par http:// ou https://).")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }

                    try {
                        await bot.user.setAvatar(avatar);
                        await submitted.reply({
                            components: [buildStatusContainer(true, "L'avatar du bot a été changé.", avatar)],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                        await msg.edit({ components: [buildMainContainer()], flags: Discord.MessageFlags.IsComponentsV2 }).catch(() => {});
                    } catch (e) {
                        await submitted.reply({
                            components: [buildStatusContainer(false, "Impossible de changer l'avatar du bot ! (lien invalide ou limite Discord atteinte)")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }
                } catch (e) {
                    // Timeout
                }
            }

            // ---- Changer la bannière du bot ----
            if (choix === 'bannerbot') {
                const modal = new Discord.ModalBuilder()
                    .setCustomId('modal_bannerbot')
                    .setTitle('Changer la bannière du bot');

                const input = new Discord.TextInputBuilder()
                    .setCustomId('bannerbot_input')
                    .setLabel('Lien de la nouvelle bannière (URL)')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder('https://exemple.com/banniere.png')
                    .setRequired(true);

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(input));
                await interaction.showModal(modal);

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === 'modal_bannerbot' && i.user.id === message.author.id,
                        time: 60000
                    });

                    const banner = submitted.fields.getTextInputValue('bannerbot_input').trim();

                    if (!isValidHttpUrl(banner)) {
                        return submitted.reply({
                            components: [buildStatusContainer(false, "Ce lien n'est pas une URL valide (doit commencer par http:// ou https://).")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }

                    try {
                        await bot.user.setBanner(banner);
                        await submitted.reply({
                            components: [buildStatusContainer(true, "La bannière du bot a été changée.", banner)],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                        await msg.edit({ components: [buildMainContainer()], flags: Discord.MessageFlags.IsComponentsV2 }).catch(() => {});
                    } catch (e) {
                        await submitted.reply({
                            components: [buildStatusContainer(false, "Impossible de changer la bannière du bot ! (lien invalide, ou la bannière nécessite un certain niveau de boost/Nitro sur le compte du bot)")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }
                } catch (e) {
                    // Timeout
                }
            }

            // ---- Changer l'activité du bot ----
            if (choix === 'activitybot') {
                const modal = new Discord.ModalBuilder()
                    .setCustomId('modal_activitybot')
                    .setTitle('Changer l\'activité du bot');

                const statutInput = new Discord.TextInputBuilder()
                    .setCustomId('activitybot_statut')
                    .setLabel('Texte du statut')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder(`Ex: ${message.prefix || '&'}help | 4LC Coins`)
                    .setValue(statut || '')
                    .setRequired(true);

                const typeInput = new Discord.TextInputBuilder()
                    .setCustomId('activitybot_type')
                    .setLabel('Type (jouer, regarder, écouter, stream)')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setPlaceholder('jouer')
                    .setRequired(true);

                modal.addComponents(
                    new Discord.ActionRowBuilder().addComponents(statutInput),
                    new Discord.ActionRowBuilder().addComponents(typeInput)
                );
                await interaction.showModal(modal);

                try {
                    const submitted = await interaction.awaitModalSubmit({
                        filter: (i) => i.customId === 'modal_activitybot' && i.user.id === message.author.id,
                        time: 60000
                    });

                    const newStatut = submitted.fields.getTextInputValue('activitybot_statut').trim();
                    const rawType = submitted.fields.getTextInputValue('activitybot_type')
                        .trim()
                        .toLowerCase()
                        .normalize('NFD').replace(/[\u0300-\u036f]/g, ''); // retire les accents (écouter -> ecouter)

                    const typeMap = {
                        'jouer': 'Playing',
                        'regarder': 'Watching',
                        'ecouter': 'Listening',
                        'stream': 'Streaming'
                    };

                    const newType = typeMap[rawType];

                    if (!newType) {
                        return submitted.reply({
                            components: [buildStatusContainer(false, "Type invalide. Utilise : `jouer`, `regarder`, `écouter` ou `stream`.")],
                            flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                        });
                    }

                    const escapedStatut = newStatut.replace(/'/g, "''");
                    bot.db.query(`UPDATE bot SET statut = '${escapedStatut}' WHERE botId = '${bot.user.id}'`);
                    bot.db.query(`UPDATE bot SET type = '${newType}' WHERE botId = '${bot.user.id}'`);

                    bot.user.setActivity(newStatut, { type: Discord.ActivityType[newType] });

                    // Mise à jour immédiate de l'état affiché, sans attendre une nouvelle requête SQL
                    statut = newStatut;
                    type = newType;

                    await submitted.reply({
                        components: [buildStatusContainer(true, `Nouveau statut : ${ACTIVITY_EMOJIS[newType]} ${ACTIVITY_LABELS_FR[newType]} \`${newStatut}\``)],
                        flags: Discord.MessageFlags.IsComponentsV2 | Discord.MessageFlags.Ephemeral
                    });
                    await msg.edit({ components: [buildMainContainer()], flags: Discord.MessageFlags.IsComponentsV2 }).catch(() => {});
                } catch (e) {
                    // Timeout
                }
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [buildMainContainer("*Menu expiré.*")], flags: Discord.MessageFlags.IsComponentsV2 }).catch(() => {});
        });
    });
}