// Système de cartes à collectionner (mycards / cduel)
// La collection de chaque joueur est stockée en JSON dans cards.collection
// (une string du type {"c1": 2, "c7": 1, ...} -> id de carte : quantité possédée)

const CARD_POOL = [
    { id: "c1", name: "Voyou de quartier", rarity: "Commune", emoji: "🃏", power: 1, value: 20, chance: 40 },
    { id: "c2", name: "Petit dealer", rarity: "Commune", emoji: "🎴", power: 2, value: 35, chance: 30 },
    { id: "c3", name: "Cambrioleur", rarity: "Peu commune", emoji: "🔓", power: 4, value: 75, chance: 15 },
    { id: "c4", name: "Hacker de l'ombre", rarity: "Rare", emoji: "💻", power: 7, value: 150, chance: 8 },
    { id: "c5", name: "Braqueur masqué", rarity: "Rare", emoji: "🥷", power: 9, value: 220, chance: 4 },
    { id: "c6", name: "Parrain", rarity: "Épique", emoji: "🎩", power: 14, value: 400, chance: 2.3 },
    { id: "c7", name: "Le Fantôme", rarity: "Légendaire", emoji: "👑", power: 25, value: 1000, chance: 0.7 },
];

function pickRandomCard() {
    const roll = Math.random() * 100;
    let acc = 0;
    for (const card of CARD_POOL) {
        acc += card.chance;
        if (roll <= acc) return card;
    }
    return CARD_POOL[0];
}

function getCard(id) {
    return CARD_POOL.find((c) => c.id === id) || null;
}

function parseCollection(raw) {
    try {
        const parsed = JSON.parse(raw || "{}");
        return typeof parsed === "object" && parsed ? parsed : {};
    } catch {
        return {};
    }
}

function stringifyCollection(collection) {
    return JSON.stringify(collection || {});
}

function totalCards(collection) {
    return Object.values(collection).reduce((sum, n) => sum + Number(n || 0), 0);
}

function totalPower(collection) {
    return Object.entries(collection).reduce((sum, [id, n]) => {
        const card = getCard(id);
        return sum + (card ? card.power * Number(n || 0) : 0);
    }, 0);
}

function totalValue(collection) {
    return Object.entries(collection).reduce((sum, [id, n]) => {
        const card = getCard(id);
        return sum + (card ? card.value * Number(n || 0) : 0);
    }, 0);
}

module.exports = {
    CARD_POOL,
    pickRandomCard,
    getCard,
    parseCollection,
    stringifyCollection,
    totalCards,
    totalPower,
    totalValue,
};
