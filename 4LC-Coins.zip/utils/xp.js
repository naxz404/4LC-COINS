const Discord = require('discord.js');
const { toV2 } = require('./embedV2.js');

const LEVEL_STEP = 100;

// ---- Config XP par salon (stockée en JSON dans xp.channelConfig) ----
// Format : { "channelId": { "amount": 10, "cooldown": 30 } }
function parseChannelConfig(raw) {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return typeof parsed === 'object' && parsed ? parsed : {};
  } catch {
    return {};
  }
}

function stringifyChannelConfig(config) {
  return JSON.stringify(config || {});
}

async function addXp(bot, member, amount, source) {
  if (!member || member.user.bot || !Number.isFinite(Number(amount)) || Number(amount) <= 0) return;
  const guildId = member.guild.id;
  const users = await bot.db.query(`SELECT * FROM user WHERE guildId = '${guildId}' AND userId = '${member.id}'`);
  if (!users.length) return;
  const before = users[0];
  const newXp = Number(before.xp || 0) + Number(amount);
  const oldLevel = Number(before.palier || 0);
  const newLevel = Math.floor(newXp / LEVEL_STEP);
  await bot.db.query(`UPDATE user SET xp = '${newXp}', palier = '${newLevel}' WHERE guildId = '${guildId}' AND userId = '${member.id}'`);
  if (newLevel <= oldLevel) return;

  const logs = await bot.db.query(`SELECT * FROM logs WHERE guildId = '${guildId}'`);
  const channel = member.guild.channels.cache.get(logs[0]?.logsxp);
  if (!channel || !channel.isTextBased()) return;
  const embed = new Discord.EmbedBuilder()
    .setColor(before.color || 'LightGrey')
    .setAuthor({ name: member.user.username, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
    .setDescription(`${member} vient d’atteindre le palier **${newLevel}** !\nXP totale : \`${newXp}\`\nSource : ${source}`)
    .setTimestamp();
  await channel.send(toV2({ embeds: [embed] })).catch(() => {});
}

module.exports = { addXp, LEVEL_STEP, parseChannelConfig, stringifyChannelConfig };
