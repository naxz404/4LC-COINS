// ---------------------------------------------------------------------------
// Librairie centrale des images utilisées dans les embeds du bot.
//
// POURQUOI CE FICHIER EXISTE :
// Toutes les images du projet pointaient vers un même salon Discord
// (media.discordapp.net/attachments/1121718489829347358/...). Depuis que
// Discord exige une signature (paramètres ?ex=&is=&hm=) sur tous les liens
// de fichiers, ces anciens liens "nus" ne chargent plus et affichent une
// image cassée dans les embeds.
//
// Ce fichier centralise CHAQUE image du bot en un seul endroit avec une clé
// claire. Comme ça, quand un lien casse, il suffit de changer UNE ligne ici
// au lieu de fouiller dans chaque commande.
//
// COMMENT REMPLACER UNE IMAGE CASSÉE :
// 1. Héberge ta propre image sur un service permanent (imgur.com direct link,
//    catbox.moe, ou ton propre CDN) — évite de reposter dans un salon Discord
//    classique, ces liens périment.
// 2. Colle le nouveau lien sur la ligne correspondante ci-dessous.
// 3. Redémarre le bot, c'est tout — aucune commande à modifier.
//
// Si une clé est laissée à `null`, la commande concernée n'affichera
// simplement pas d'image au lieu de planter (voir utils/embedV2.js -> applyImage).
// ---------------------------------------------------------------------------

module.exports = {
    // --- Enchères (commands/administration/start.js) ---
    auctionThumbnail: null, // 🔴 à remplacer — icône document/enchère
    auctionBanner: null,    // 🔴 à remplacer — bannière "vente aux enchères"

    // --- Course de chevaux (commands/administration/course.js) ---
    // Le suivi des chevaux est maintenant un tracé animé en texte (aucune image
    // externe requise, donc 100% fiable). Ce champ est optionnel, juste pour
    // décorer le panneau de mise avant le départ.
    horseRaceBanner: null, // 🔴 optionnel — image d'hippodrome pour le panneau de mise

    // --- Team (commands/team/*.js) ---
    teamDefaultThumbnail: null, // 🔴 à remplacer — icône par défaut d'une team

    // --- Capacités illégales (commands/illegal/mobil.js) ---
    mobilThumbnail: null, // 🔴 à remplacer

    // --- Braquage (commands/job/braquage.js) ---
    braquageSuccess: null, // 🔴 à remplacer — gif de succès
    braquageFail: null,    // 🔴 à remplacer — gif d'échec

    // --- Wagon (commands/job/wagon.js) ---
    wagonThumbnail: null, // 🔴 à remplacer

    // --- Bâtiments (commands/job/batiment.js) ---
    batimentThumbnail: null, // 🔴 à remplacer

    // --- Hack (commands/job/hack.js) ---
    hackSuccess: null, // 🔴 à remplacer — gif de succès
    hackFail: null,    // 🔴 à remplacer — gif d'échec

    // --- Juge (commands/job/juge.js) ---
    jugeGif: null, // 🔴 à remplacer

    // --- Mine (commands/jeux/mine.js) ---
    minePioche: null, // 🔴 à remplacer — icône pioche

    // --- Gift (commands/jeux/gift.js) ---
    giftImage: null, // 🔴 à remplacer

    // --- Gunfight (commands/minijeux/gunfight.js) ---
    gunfightImage: null, // 🔴 à remplacer

    // --- Slots (commands/minijeux/slots.js) ---
    slotsGif: null, // 🔴 à remplacer

    // --- Roulette (commands/minijeux/roulette.js) ---
    rouletteGif: null, // 🔴 à remplacer

    // --- Pierre-feuille-ciseaux (commands/minijeux/pfc.js) ---
    pfcImage: null // 🔴 à remplacer
};
