const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const file = path.join(__dirname, "..", "manager.json");
const durations = {
  "1mois": 30,
  "2mois": 60,
  "3mois": 90,
  "12mois": 365,
  "infinie": null
};

function defaultState() {
  return { licenses: {}, bots: {} };
}

function read() {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(defaultState(), null, 2));
  const state = JSON.parse(fs.readFileSync(file, "utf8") || "{}");
  state.licenses ||= {};
  state.bots ||= {};
  return state;
}

function write(state) {
  fs.writeFileSync(file, JSON.stringify(state, null, 2));
}

function update(mutator) {
  const state = read();
  const result = mutator(state);
  write(state);
  return result;
}

function makeKey() {
  return `DF-${crypto.randomBytes(3).toString("hex").toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function expiresAt(duration) {
  const days = durations[duration];
  if (days === null) return null;
  return Date.now() + days * 86400000;
}

function isExpired(license) {
  return Boolean(license?.expiresAt && license.expiresAt <= Date.now());
}

function createLicense(duration, createdBy, note = "") {
  return update((state) => {
    let key = makeKey();
    while (state.licenses[key]) key = makeKey();
    state.licenses[key] = {
      key,
      duration,
      note,
      createdBy,
      createdAt: Date.now(),
      expiresAt: null,
      activatedAt: null,
      activatedBy: null,
      revoked: false,
      botId: null
    };
    return state.licenses[key];
  });
}

function listLicenses() {
  return Object.values(read().licenses).sort((a, b) => b.createdAt - a.createdAt);
}

function activateLicense(key, token, ownerId) {
  return update((state) => {
    const license = state.licenses[key];
    if (!license) return { error: "missing" };
    if (license.revoked) return { error: "revoked" };
    if (isExpired(license)) return { error: "expired" };
    if (license.activatedBy && license.activatedBy !== ownerId) return { error: "used" };

    const botId = license.botId || crypto.randomUUID();
    if (!license.activatedAt) {
      license.activatedAt = Date.now();
      license.expiresAt = expiresAt(license.duration);
    }
    license.activatedBy = ownerId;
    license.botId = botId;

    state.bots[botId] = {
      ...(state.bots[botId] || {}),
      id: botId,
      key,
      token,
      ownerId,
      enabled: true,
      status: "pending",
      updatedAt: Date.now(),
      lastError: null
    };
    return { license, bot: state.bots[botId] };
  });
}

function userBots(userId) {
  const state = read();
  return Object.values(state.bots)
    .filter((bot) => bot.ownerId === userId && bot.enabled)
    .map((bot) => ({ ...bot, license: state.licenses[bot.key] }));
}

function activeBots() {
  const state = read();
  return Object.values(state.bots).filter((bot) => {
    const license = state.licenses[bot.key];
    return bot.enabled && license && !license.revoked && !isExpired(license);
  });
}

function updateBot(botId, patch) {
  return update((state) => {
    if (!state.bots[botId]) return null;
    Object.assign(state.bots[botId], patch, { updatedAt: Date.now() });
    return state.bots[botId];
  });
}

function stopUserBot(userId, botId = null) {
  return update((state) => {
    const bot = Object.values(state.bots).find((item) => item.ownerId === userId && item.enabled && (!botId || item.id === botId));
    if (!bot) return null;
    bot.enabled = false;
    bot.status = "stopped";
    bot.updatedAt = Date.now();
    return bot;
  });
}

function transferUserBot(userId, newOwnerId, botId = null) {
  return update((state) => {
    const bot = Object.values(state.bots).find((item) => item.ownerId === userId && item.enabled && (!botId || item.id === botId));
    if (!bot) return null;
    bot.ownerId = newOwnerId;
    const license = state.licenses[bot.key];
    if (license) license.activatedBy = newOwnerId;
    bot.updatedAt = Date.now();
    return bot;
  });
}

module.exports = {
  durations,
  createLicense,
  listLicenses,
  activateLicense,
  userBots,
  activeBots,
  updateBot,
  stopUserBot,
  transferUserBot,
  isExpired
};
