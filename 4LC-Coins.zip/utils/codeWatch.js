const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = path.join(__dirname, "..");
const STATE_FILE = path.join(ROOT, "data", "codeState.json");

// Dossiers surveillés pour détecter un ajout / suppression / modification de fichier
const WATCHED_DIRS = ["commands", "events", "utils", "handlers"];

function walk(dir, base) {
    let results = [];
    if (!fs.existsSync(dir)) return results;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
            if (entry.name === "node_modules") continue;
            results = results.concat(walk(full, base));
        } else if (entry.isFile() && entry.name.endsWith(".js")) {
            results.push(path.relative(base, full).split(path.sep).join("/"));
        }
    }
    return results;
}

function hashFile(absPath) {
    return crypto.createHash("sha256").update(fs.readFileSync(absPath)).digest("hex");
}

/**
 * Essaie de retrouver le nom "officiel" d'une commande (exports.help.name) à partir
 * de son chemin de fichier, pour un affichage plus lisible que le nom de fichier brut.
 */
function commandDisplayName(relPath) {
    try {
        const props = require(path.join(ROOT, "commands", relPath));
        return props?.help?.name ? `\`${props.help.name}\`` : `\`${relPath}\``;
    } catch (e) {
        return `\`${relPath}\``;
    }
}

function loadPreviousState() {
    try {
        if (!fs.existsSync(STATE_FILE)) return null;
        return JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
    } catch (e) {
        return null;
    }
}

function saveState(state) {
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

/**
 * Compare l'état actuel du code (commands/events/utils/handlers) avec le dernier état
 * connu (sauvegardé au démarrage précédent) et renvoie un rapport des changements.
 * Doit être appelée une seule fois par démarrage (elle met aussi à jour l'état sauvegardé).
 */
function detectChanges() {
    const currentHashes = {};

    for (const dirName of WATCHED_DIRS) {
        const abs = path.join(ROOT, dirName);
        for (const relPath of walk(abs, abs)) {
            currentHashes[`${dirName}/${relPath}`] = hashFile(path.join(abs, relPath));
        }
    }

    const previous = loadPreviousState();
    const now = Date.now();

    const report = {
        isFirstRun: !previous,
        previousBootAt: previous?.lastBootAt || null,
        commands: { added: [], removed: [], modified: [] },
        other: { added: [], removed: [], modified: [] }
    };

    if (previous) {
        const prevHashes = previous.hashes || {};

        for (const key of Object.keys(currentHashes)) {
            const dirName = key.split("/")[0];
            const relPath = key.slice(dirName.length + 1);
            const bucket = dirName === "commands" ? report.commands : report.other;
            const label = dirName === "commands" ? commandDisplayName(relPath) : `\`${key}\``;

            if (!(key in prevHashes)) bucket.added.push(label);
            else if (prevHashes[key] !== currentHashes[key]) bucket.modified.push(label);
        }

        for (const key of Object.keys(prevHashes)) {
            if (!(key in currentHashes)) {
                const dirName = key.split("/")[0];
                const relPath = key.slice(dirName.length + 1);
                const bucket = dirName === "commands" ? report.commands : report.other;
                bucket.removed.push(`\`${relPath}\``);
            }
        }
    }

    saveState({ hashes: currentHashes, lastBootAt: now });

    report.hasChanges = [report.commands, report.other].some(
        (b) => b.added.length || b.removed.length || b.modified.length
    );

    return report;
}

module.exports = { detectChanges };
