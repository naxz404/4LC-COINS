const { EmbedBuilder } = require("discord.js");

const SIGNATURE = "By 4LC | discord.gg/ddJMXWYJ29";
const INVITE = "https://discord.gg/ddJMXWYJ29";

// Force la signature en bas de CHAQUE embed (EmbedBuilder), peu importe la commande.
// - si l'embed a deja un footer (ex: "4LC • Leaderboard"), la signature est ajoutee sur une 2e ligne
// - le patch est idempotent (jamais de doublon)
if (!EmbedBuilder.prototype.__4lcPatched) {
    const originalToJSON = EmbedBuilder.prototype.toJSON;
    EmbedBuilder.prototype.toJSON = function () {
        const data = originalToJSON.call(this);
        const footer = data.footer ? { ...data.footer } : {};
        const current = (footer.text || "").trim();
        if (!current.includes(SIGNATURE)) {
            footer.text = current ? `${current}\n${SIGNATURE}` : SIGNATURE;
        }
        return { ...data, footer };
    };
    Object.defineProperty(EmbedBuilder.prototype, "__4lcPatched", { value: true });
}

module.exports = { SIGNATURE, INVITE };
