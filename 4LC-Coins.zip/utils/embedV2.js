const {
    ContainerBuilder,
    TextDisplayBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} = require("discord.js");

/**
 * Récupère les données brutes d'un embed, qu'il soit un EmbedBuilder ou un objet brut.
 */
function getEmbedData(embed) {
    if (!embed) return {};
    if (typeof embed.toJSON === "function") return embed.toJSON();
    return embed;
}

/**
 * Convertit un embed classique (EmbedBuilder ou objet embed brut) en un
 * ContainerBuilder équivalent (Components V2).
 *
 * Gère : couleur, auteur, titre, description, champs, image, thumbnail, footer, timestamp.
 */
function embedToContainer(embedInput) {
    const data = getEmbedData(embedInput);
    const container = new ContainerBuilder();

    if (data.color !== undefined && data.color !== null) {
        container.setAccentColor(data.color);
    }

    // Auteur
    if (data.author?.name) {
        const authorText = data.author.url
            ? `[${data.author.name}](${data.author.url})`
            : `${data.author.name}`;
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(authorText));
    }

    // Titre + description (avec thumbnail en accessoire si présent)
    let mainText = "";
    if (data.title) {
        mainText += data.url ? `## [${data.title}](${data.url})` : `## ${data.title}`;
    }
    if (data.description) {
        mainText += mainText ? `\n${data.description}` : `${data.description}`;
    }

    const thumbnailUrl = data.thumbnail?.url;

    if (mainText && thumbnailUrl) {
        container.addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(mainText))
                .setThumbnailAccessory(new ThumbnailBuilder().setURL(thumbnailUrl))
        );
    } else if (mainText) {
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(mainText));
    } else if (thumbnailUrl) {
        container.addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent("\u200b"))
                .setThumbnailAccessory(new ThumbnailBuilder().setURL(thumbnailUrl))
        );
    }

    // Champs
    if (Array.isArray(data.fields) && data.fields.length) {
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
        for (const field of data.fields) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${field.name}**\n${field.value}`)
            );
        }
    }

    // Image principale
    if (data.image?.url) {
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
        container.addMediaGalleryComponents(
            new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(data.image.url))
        );
    }

    // Footer + timestamp (la signature 4LC reste toujours sur la derniere ligne)
    if (data.footer?.text || data.timestamp) {
        const SIGNATURE = "By 4LC | discord.gg/ddJMXWYJ29";
        const raw = data.footer?.text || "";
        const hasSignature = raw.includes(SIGNATURE);
        let lines = raw.split("\n").filter((l) => l.trim() && l.trim() !== SIGNATURE);
        if (data.timestamp) {
            const ts = Math.floor(new Date(data.timestamp).getTime() / 1000);
            if (lines.length) lines[lines.length - 1] += ` • <t:${ts}:R>`;
            else lines.push(`<t:${ts}:R>`);
        }
        if (hasSignature) lines.push(SIGNATURE);
        if (lines.length) {
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(lines.map((line) => `-# ${line}`).join("\n"))
            );
        }
    }

    return container;
}

/**
 * Convertit un payload classique ({ content, embeds, components, ephemeral, ... })
 * en payload compatible Components V2.
 *
 * Exemple :
 *   channel.send(toV2({ embeds: [embed], components: [row] }))
 *   interaction.reply(toV2({ embeds: [embed], ephemeral: true }))
 *
 * Si le payload ne contient aucun embed (ex: fermeture d'un panneau avec
 * `{ embeds: [], components: [] }`), il est renvoyé tel quel, sans conversion.
 */
function toV2(payload = {}) {
    const { embeds, content, components = [], flags, ephemeral, ...rest } = payload;

    const hasEmbeds = Array.isArray(embeds) && embeds.length > 0;
    if (!hasEmbeds) return payload;

    const topComponents = [];

    if (content) {
        topComponents.push(new TextDisplayBuilder().setContent(content));
    }

    for (const embed of embeds) {
        topComponents.push(embedToContainer(embed));
    }

    // Conserve les composants déjà présents (boutons, select menus...)
    for (const row of components) {
        topComponents.push(row);
    }

    let finalFlags = flags || 0;
    if (ephemeral) finalFlags |= MessageFlags.Ephemeral;
    finalFlags |= MessageFlags.IsComponentsV2;

    return { ...rest, components: topComponents, flags: finalFlags };
}

/**
 * Applique une image/thumbnail à un embed seulement si l'URL est définie.
 * Évite qu'une entrée manquante dans utils/images.js ne casse l'embed.
 * @param {Discord.EmbedBuilder} embed
 * @param {string|null|undefined} url
 * @returns {Discord.EmbedBuilder}
 */
function safeImage(embed, url) {
    if (url) embed.setImage(url);
    return embed;
}

function safeThumbnail(embed, url) {
    if (url) embed.setThumbnail(url);
    return embed;
}

module.exports = { embedToContainer, toV2, safeImage, safeThumbnail };
