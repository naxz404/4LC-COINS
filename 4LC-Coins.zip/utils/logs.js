const Discord = require("discord.js");
const { toV2 } = require("./embedV2.js");

/**
 * Envoie un embed de log détaillé dans le salon "logstransac" configuré du serveur (setlogs transaction #salon).
 * @param {Client} bot
 * @param {Guild} guild
 * @param {Object} data
 * @param {string} data.type - Type de l'action (ex: "Paiement", "Dragon (perdu)", "Drop"...)
 * @param {User} [data.user] - Auteur de l'action
 * @param {User} [data.target] - Cible de l'action (le cas échéant)
 * @param {number} [data.amount] - Montant en jeu (positif = gain, négatif = perte)
 * @param {string} [data.description] - Description libre affichée dans l'embed
 */
async function sendCoinLog(bot, guild, data) {
    try {
        const rows = await bot.db.query(`SELECT * FROM logs WHERE guildId = "${guild.id}"`);
        const channelId = rows?.[0]?.logstransac;
        if (!channelId) return;

        const channel = guild.channels.cache.get(channelId) || bot.channels.cache.get(channelId);
        if (!channel) return;

        const embed = new Discord.EmbedBuilder()
            .setAuthor({
                name: data.user ? data.user.username : "Système",
                iconURL: data.user ? data.user.displayAvatarURL({ dynamic: true }) : undefined
            })
            .setTitle(`💳 ${data.type || "Transaction"}`)
            .setDescription(data.description || "*Aucun détail supplémentaire*")
            .setColor(typeof data.amount === "number" ? (data.amount >= 0 ? "Green" : "Red") : "Blurple")
            .setTimestamp();

        const fields = [];
        if (data.user) fields.push({ name: "Auteur", value: `${data.user}`, inline: true });
        if (data.target) fields.push({ name: "Cible", value: `${data.target}`, inline: true });
        if (typeof data.amount === "number") {
            fields.push({ name: "Montant", value: `${data.amount >= 0 ? "+" : ""}${data.amount} coins`, inline: true });
        }
        if (fields.length) embed.addFields(fields);

        await channel.send(toV2({ embeds: [embed] }));
    } catch (error) {
        console.error("[LOGS COINS]", error);
    }
}

module.exports = { sendCoinLog };
