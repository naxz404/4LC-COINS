const fs = require("fs");
const path = require("path");
const { toV2 } = require("./embedV2.js");

const GUILD_DIR = path.join(__dirname, "..", "data", "guilds");

function listGuildIds() {
    if (!fs.existsSync(GUILD_DIR)) return [];
    return fs.readdirSync(GUILD_DIR)
        .filter((f) => f.endsWith(".json"))
        .map((f) => f.replace(/\.json$/, ""));
}

/**
 * Démarre la boucle de vérification (toutes les minutes) des auto-drop / auto-top configurés
 * par serveur via &configdrop / &configtop.
 */
module.exports = function startScheduler(bot) {
    setInterval(async () => {
        const now = new Date();
        const hh = String(now.getHours()).padStart(2, "0");
        const mm = String(now.getMinutes()).padStart(2, "0");
        const today = now.toISOString().slice(0, 10);

        for (const guildId of listGuildIds()) {
            try {
                const guild = bot.guilds.cache.get(guildId);
                if (!guild) continue;

                const rows = await bot.db.query(`SELECT * FROM guild WHERE guildId = "${guildId}"`);
                const g = rows[0];
                if (!g) continue;

                // ---- Auto-drop ----
                if (g.dropEnabled === "on" && g.dropChannelId && g.dropHour === hh && g.dropMinute === mm && g.lastDropDate !== today) {
                    await bot.db.query(`UPDATE guild SET lastDropDate = '${today}' WHERE guildId = '${guildId}'`);
                    const channel = guild.channels.cache.get(g.dropChannelId);
                    if (channel) {
                        const { runDrop } = require("../commands/administration/drop.js");
                        channel.send(`*Drop automatique lancé dans ${channel}*`).catch(() => {});
                        runDrop(bot, channel, Number(g.dropAmount || 100), "Blurple", guild).catch((e) => console.error("[Scheduler:drop]", e));
                    }
                }

                // ---- Auto-top ----
                if (g.topEnabled === "on" && g.topChannelId && g.topHour === hh && g.topMinute === mm && g.lastTopDate !== today) {
                    await bot.db.query(`UPDATE guild SET lastTopDate = '${today}' WHERE guildId = '${guildId}'`);
                    const channel = guild.channels.cache.get(g.topChannelId);
                    if (channel) {
                        const { buildTopAllEmbeds } = require("../commands/gestioncoins/topall.js");
                        const embeds = await buildTopAllEmbeds(bot, guild, "Blurple");
                        channel.send(toV2({ embeds })).catch((e) => console.error("[Scheduler:top]", e));
                    }
                }
            } catch (error) {
                console.error("[Scheduler]", error);
            }
        }
    }, 60 * 1000);
};
