// Génère l'image (PNG) de la commande &stats / s&u, façon "dashboard" (type Statbot).
// Même moteur "à la main" (100% JS, sans dépendance) que profileBoard.js / dragonBoard.js.

const { Canvas } = require("./canvas");
const { normalize } = require("./font");

const SS = 3; // super-échantillonnage (anti-aliasing) - plus haut = plus net

const PALETTE = {
    bgTop: [18, 20, 28, 255],
    bgBottom: [9, 10, 15, 255],
    border: [55, 68, 92, 255],
    boxTop: [27, 31, 42, 255],
    boxBottom: [16, 19, 26, 255],
    boxBorder: [50, 58, 76, 255],
    headerTop: [30, 34, 46, 255],
    headerBottom: [18, 20, 28, 255],
    textDim: [140, 152, 170, 255],
    textBright: [235, 240, 245, 255],
    gold: [255, 200, 90, 255],
    green: [95, 222, 142, 255],
    pink: [232, 92, 172, 255],
    trackBg: [40, 45, 58, 255]
};

// Le moteur de police ne gère que MAJ/chiffres/ponctuation simple : on nettoie
// le texte avant de le dessiner pour éviter des trous (emojis, accents rares...).
function safeText(text) {
    const norm = normalize(text || "");
    return norm.replace(/[^A-Z0-9 .,!?:\-+/%'()]/g, "");
}

function rotatePoint(px, py, cx, cy, angle) {
    const cos = Math.cos(angle), sin = Math.sin(angle);
    const dx = px - cx, dy = py - cy;
    return [cx + dx * cos - dy * sin, cy + dx * sin + dy * cos];
}

// ---- Jeton de poker "DF" en filigrane (recréation vectorielle du logo du serveur) ----
function drawChipLogo(c, cx, cy, r, accent) {
    for (let i = 3; i >= 1; i--) {
        c.circle(cx, cy + i * r * 0.1, r, [0, 0, 0, 70]);
    }
    c.circle(cx, cy, r, [14, 14, 17, 255]);
    const notches = 8;
    for (let i = 0; i < notches; i++) {
        const angle = (Math.PI * 2 * i) / notches;
        const ncx = cx + Math.cos(angle) * r * 0.78;
        const ncy = cy + Math.sin(angle) * r * 0.78;
        const hw = r * 0.15, hh = r * 0.24;
        const corners = [
            [ncx - hw, ncy - hh], [ncx + hw, ncy - hh],
            [ncx + hw, ncy + hh], [ncx - hw, ncy + hh]
        ].map(([px, py]) => rotatePoint(px, py, ncx, ncy, angle + Math.PI / 2));
        c.polygon(corners, [232, 232, 235, 255]);
    }
    c.circle(cx, cy, r * 0.6, [230, 230, 234, 255]);
    c.circle(cx, cy, r * 0.55, [246, 247, 249, 255]);
    const label = "DF";
    const scale = Math.max(1, r * 0.09);
    const w = Canvas.measureText(label, scale);
    c.drawText(cx - w / 2, cy - (7 * scale) / 2, label, scale, accent || [80, 150, 225, 255]);
}

function drawAvatarPlaceholder(c, cx, cy, r, letter, accent) {
    c.circle(cx, cy, r, accent);
    c.circle(cx, cy, r - 2 * SS, [20, 22, 30, 255]);
    const scale = r * 0.045;
    const w = Canvas.measureText(letter, scale);
    c.drawText(cx - w / 2, cy - (7 * scale) / 2, letter, scale, accent);
}

// Échantillonnage bilinéaire (image nette, pas de pixelisation à l'agrandissement/réduction)
function sampleBilinear(img, u, v) {
    const { width: sw, height: sh, data } = img;
    const fx = u * sw - 0.5, fy = v * sh - 0.5;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const x1 = x0 + 1, y1 = y0 + 1;
    const tx = fx - x0, ty = fy - y0;
    const cx0 = Math.min(sw - 1, Math.max(0, x0)), cx1 = Math.min(sw - 1, Math.max(0, x1));
    const cy0 = Math.min(sh - 1, Math.max(0, y0)), cy1 = Math.min(sh - 1, Math.max(0, y1));
    const px = (xx, yy) => {
        const i = (yy * sw + xx) * 4;
        return [data[i], data[i + 1], data[i + 2], data[i + 3]];
    };
    const c00 = px(cx0, cy0), c10 = px(cx1, cy0), c01 = px(cx0, cy1), c11 = px(cx1, cy1);
    const lerp = (a, b, t) => a + (b - a) * t;
    const top = [0, 1, 2, 3].map((k) => lerp(c00[k], c10[k], tx));
    const bot = [0, 1, 2, 3].map((k) => lerp(c01[k], c11[k], tx));
    return [0, 1, 2, 3].map((k) => lerp(top[k], bot[k], ty));
}

// Dessine la vraie photo de profil (recadrée en cercle) avec un anneau de couleur
function drawAvatarImage(c, cx, cy, r, img, ringColor) {
    c.circle(cx, cy, r, ringColor || PALETTE.gold);
    const innerR = r - 3 * SS;
    const x0 = Math.floor(cx - innerR), x1 = Math.ceil(cx + innerR);
    const y0 = Math.floor(cy - innerR), y1 = Math.ceil(cy + innerR);
    for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
            const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
            if (dx * dx + dy * dy > innerR * innerR) continue;
            const u = (dx + innerR) / (2 * innerR);
            const v = (dy + innerR) / (2 * innerR);
            c.setPixel(x, y, sampleBilinear(img, u, v));
        }
    }
}

function drawBox(c, x, y, w, h, title, titleColor) {
    c.roundRectGrad(x, y, w, h, 10 * SS, PALETTE.boxTop, PALETTE.boxBottom);
    c.strokeRoundRect(x, y, w, h, 10 * SS, 1.2 * SS, PALETTE.boxBorder);
    c.drawText(x + 12 * SS, y + 10 * SS, safeText(title), 1.35 * SS, titleColor || PALETTE.textDim);
}

function drawStatRow(c, x, y, w, label, value, valueColor) {
    c.drawText(x, y, safeText(label), 1.25 * SS, PALETTE.textDim);
    const vw = Canvas.measureText(safeText(value), 1.5 * SS);
    c.drawText(x + w - vw, y - 2 * SS, safeText(value), 1.5 * SS, valueColor || PALETTE.textBright);
}

function drawTopChannels(c, x, y, w, h, entries) {
    drawBox(c, x, y, w, h, "SALONS LES PLUS ACTIFS", PALETTE.gold);
    const innerX = x + 12 * SS;
    const innerW = w - 24 * SS;
    const rowH = 26 * SS;
    const startY = y + 34 * SS;
    const max = Math.max(1, ...entries.map((e) => e.ratio));
    if (!entries.length) {
        c.drawText(innerX, startY + 6 * SS, "AUCUNE ACTIVITE ENREGISTREE", 1.2 * SS, PALETTE.textDim);
        return;
    }
    entries.slice(0, 3).forEach((entry, i) => {
        const rowY = startY + i * rowH;
        c.drawText(innerX, rowY, safeText(entry.label), 1.2 * SS, PALETTE.textBright);
        const valW = Canvas.measureText(safeText(entry.value), 1.2 * SS);
        c.drawText(x + w - 12 * SS - valW, rowY, safeText(entry.value), 1.2 * SS, entry.color || PALETTE.textBright);
        const barY = rowY + 11 * SS;
        const barW = innerW;
        c.roundRect(innerX, barY, barW, 4 * SS, 2 * SS, PALETTE.trackBg);
        const fillW = Math.max(6 * SS, (entry.ratio / max) * barW);
        c.roundRect(innerX, barY, fillW, 4 * SS, 2 * SS, entry.color || PALETTE.gold);
    });
}

function drawChart(c, x, y, w, h, series) {
    drawBox(c, x, y, w, h, "ACTIVITE - 14 DERNIERS JOURS", PALETTE.gold);
    const innerX = x + 14 * SS;
    const innerW = w - 28 * SS;
    const baseY = y + h - 14 * SS;
    const chartH = h - 46 * SS;
    const slotW = innerW / series.length;
    const maxMsg = Math.max(1, ...series.map((s) => s.msg));
    const maxVoc = Math.max(1, ...series.map((s) => s.voc));

    // légende
    c.roundRect(x + w - 150 * SS, y + 10 * SS, 8 * SS, 8 * SS, 2 * SS, PALETTE.green);
    c.drawText(x + w - 136 * SS, y + 9 * SS, "MESSAGES", 1.05 * SS, PALETTE.textDim);
    c.roundRect(x + w - 150 * SS, y + 22 * SS, 8 * SS, 8 * SS, 2 * SS, PALETTE.pink);
    c.drawText(x + w - 136 * SS, y + 21 * SS, "VOCAL", 1.05 * SS, PALETTE.textDim);

    series.forEach((s, i) => {
        const slotX = innerX + i * slotW;
        const barW = Math.max(2 * SS, slotW * 0.32);
        const gap = slotW * 0.06;

        const msgH = Math.max(2 * SS, (s.msg / maxMsg) * chartH);
        c.roundRect(slotX + gap, baseY - msgH, barW, msgH, 2 * SS, PALETTE.green);

        const vocH = Math.max(2 * SS, (s.voc / maxVoc) * chartH);
        c.roundRect(slotX + gap + barW + gap, baseY - vocH, barW, vocH, 2 * SS, PALETTE.pink);
    });

    c.line(innerX, baseY, innerX + innerW, baseY, PALETTE.boxBorder, 1 * SS);
}

/**
 * @param {object} state
 * @param {string} state.username
 * @param {string} state.serverName
 * @param {[number,number,number,number]} state.accent - couleur RGBA du membre
 * @param {string} state.createdOn
 * @param {string} state.joinedOn
 * @param {number|null} state.msgRank
 * @param {number|null} state.vocRank
 * @param {number} state.totalRanked
 * @param {{d1:number,d7:number,d14:number}} state.messages
 * @param {{d1:string,d7:string,d14:string}} state.voice - déjà formaté en heures (ex: "24.02")
 * @param {{label:string,value:string,ratio:number,color:[number,number,number,number]}[]} state.topChannels
 * @param {{msg:number, voc:number}[]} state.series - 14 jours, du plus ancien au plus récent
 * @returns {Buffer} PNG
 */
function renderStatsBoard(state) {
    const {
        username, serverName, accent, createdOn, joinedOn,
        msgRank, vocRank, totalRanked, messages, voice, topChannels, series
    } = state;

    const PAD = 22;
    const GAP = 14;
    const CONTENT_W = 860;
    const HEADER_H = 92;
    const ROW2_H = 118;
    const ROW3_H = 132;
    const CHART_H = 168;
    const FOOTER_H = 40;

    const W = CONTENT_W + PAD * 2;
    const H = PAD * 2 + HEADER_H + GAP + ROW2_H + GAP + ROW3_H + GAP + CHART_H + GAP + FOOTER_H;

    const c = new Canvas(W * SS, H * SS);
    c.roundRectGrad(0, 0, W * SS, H * SS, 20 * SS, PALETTE.bgTop, PALETTE.bgBottom);
    c.strokeRoundRect(0, 0, W * SS, H * SS, 20 * SS, 1.6 * SS, accent || PALETTE.border);

    // ---- En-tête ----
    const headerX = PAD * SS, headerY = PAD * SS;
    c.roundRectGrad(headerX, headerY, CONTENT_W * SS, HEADER_H * SS, 12 * SS, PALETTE.headerTop, PALETTE.headerBottom);
    c.strokeRoundRect(headerX, headerY, CONTENT_W * SS, HEADER_H * SS, 12 * SS, 1.2 * SS, PALETTE.boxBorder);

    const avatarR = 30 * SS;
    const avatarCx = headerX + 20 * SS + avatarR;
    const avatarCy = headerY + HEADER_H * SS / 2;
    if (state.avatarImage) {
        drawAvatarImage(c, avatarCx, avatarCy, avatarR, state.avatarImage, accent || PALETTE.gold);
    } else {
        drawAvatarPlaceholder(c, avatarCx, avatarCy, avatarR, safeText(username).slice(0, 1) || "?", accent || PALETTE.gold);
    }

    const nameX = avatarCx + avatarR + 18 * SS;
    c.drawText(nameX, headerY + 24 * SS, safeText(username), 2.1 * SS, PALETTE.textBright);
    c.drawText(nameX, headerY + 54 * SS, safeText(serverName || "STATISTIQUES DU SERVEUR"), 1.15 * SS, PALETTE.textDim);

    // ---- Deux mini-chips date en haut à droite ----
    const chipW = 190 * SS, chipH = 52 * SS;
    const chip2X = headerX + CONTENT_W * SS - chipW;
    const chip1X = chip2X - chipW - 10 * SS;
    const chipY = headerY + (HEADER_H * SS - chipH) / 2;

    c.roundRect(chip1X, chipY, chipW, chipH, 8 * SS, PALETTE.boxTop);
    c.strokeRoundRect(chip1X, chipY, chipW, chipH, 8 * SS, 1 * SS, PALETTE.boxBorder);
    c.drawText(chip1X + 10 * SS, chipY + 6 * SS, "CREE LE", 1.05 * SS, PALETTE.textDim);
    c.drawText(chip1X + 10 * SS, chipY + 26 * SS, safeText(createdOn), 1.3 * SS, PALETTE.textBright);

    c.roundRect(chip2X, chipY, chipW, chipH, 8 * SS, PALETTE.boxTop);
    c.strokeRoundRect(chip2X, chipY, chipW, chipH, 8 * SS, 1 * SS, PALETTE.boxBorder);
    c.drawText(chip2X + 10 * SS, chipY + 6 * SS, "REJOINT LE", 1.05 * SS, PALETTE.textDim);
    c.drawText(chip2X + 10 * SS, chipY + 26 * SS, safeText(joinedOn), 1.3 * SS, PALETTE.textBright);

    // ---- Ligne 2 : classement / messages / vocal ----
    const row2Y = (PAD + HEADER_H + GAP) * SS;
    const col3W = (CONTENT_W - 2 * GAP) / 3;

    const boxRankX = headerX;
    drawBox(c, boxRankX, row2Y, col3W * SS, ROW2_H * SS, "CLASSEMENT SERVEUR", PALETTE.gold);
    drawStatRow(c, boxRankX + 12 * SS, row2Y + 44 * SS, col3W * SS - 24 * SS, "MESSAGES", msgRank ? `N${msgRank}` : "NC", PALETTE.green);
    drawStatRow(c, boxRankX + 12 * SS, row2Y + 74 * SS, col3W * SS - 24 * SS, "VOCAL", vocRank ? `N${vocRank}` : "NC", PALETTE.pink);
    if (totalRanked) {
        c.drawText(boxRankX + 12 * SS, row2Y + ROW2_H * SS - 20 * SS, safeText(`SUR ${totalRanked} MEMBRES`), 0.95 * SS, PALETTE.textDim);
    }

    const boxMsgX = boxRankX + (col3W + GAP) * SS;
    drawBox(c, boxMsgX, row2Y, col3W * SS, ROW2_H * SS, "MESSAGES", PALETTE.green);
    drawStatRow(c, boxMsgX + 12 * SS, row2Y + 44 * SS, col3W * SS - 24 * SS, "1 JOUR", String(messages.d1), PALETTE.textBright);
    drawStatRow(c, boxMsgX + 12 * SS, row2Y + 68 * SS, col3W * SS - 24 * SS, "7 JOURS", String(messages.d7), PALETTE.textBright);
    drawStatRow(c, boxMsgX + 12 * SS, row2Y + 92 * SS, col3W * SS - 24 * SS, "14 JOURS", String(messages.d14), PALETTE.textBright);

    const boxVocX = boxMsgX + (col3W + GAP) * SS;
    drawBox(c, boxVocX, row2Y, col3W * SS, ROW2_H * SS, "ACTIVITE VOCALE", PALETTE.pink);
    drawStatRow(c, boxVocX + 12 * SS, row2Y + 44 * SS, col3W * SS - 24 * SS, "1 JOUR", `${voice.d1}H`, PALETTE.textBright);
    drawStatRow(c, boxVocX + 12 * SS, row2Y + 68 * SS, col3W * SS - 24 * SS, "7 JOURS", `${voice.d7}H`, PALETTE.textBright);
    drawStatRow(c, boxVocX + 12 * SS, row2Y + 92 * SS, col3W * SS - 24 * SS, "14 JOURS", `${voice.d14}H`, PALETTE.textBright);

    // ---- Ligne 3 : salons les plus actifs ----
    const row3Y = row2Y + (ROW2_H + GAP) * SS;
    drawTopChannels(c, headerX, row3Y, CONTENT_W * SS, ROW3_H * SS, topChannels || []);

    // ---- Graphique 14 jours ----
    const chartY = row3Y + (ROW3_H + GAP) * SS;
    drawChart(c, headerX, chartY, CONTENT_W * SS, CHART_H * SS, series || []);

    // ---- Logo filigrane + footer ----
    const footerY = chartY + CHART_H * SS + GAP * SS;
    const footerCy = footerY + FOOTER_H * SS / 2;
    drawChipLogo(c, headerX + 16 * SS, footerCy, 15 * SS, accent);
    c.drawText(headerX + 40 * SS, footerCy - 7 * SS, safeText(serverName || "4LC"), 1.1 * SS, PALETTE.textDim);
    const footerTxt = "PERIODE : 14 DERNIERS JOURS  -  FUSEAU : UTC";
    const footerW = Canvas.measureText(footerTxt, 1.1 * SS);
    c.drawText(headerX + CONTENT_W * SS - footerW, footerCy - 7 * SS, footerTxt, 1.1 * SS, PALETTE.textDim);

    const finalImg = c.downsample(SS);
    return finalImg.toPNG();
}

module.exports = { renderStatsBoard, PALETTE, drawChipLogo };
