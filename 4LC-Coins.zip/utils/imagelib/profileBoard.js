// Génère l'image (PNG) du profil pour la commande &profil, en format PAYSAGE
// (large plutôt que haute) — même moteur "à la main" que dragonBoard.js / morpionBoard.js.

const { Canvas } = require("./canvas");

const SS = 2;

const PALETTE = {
    bgTop: [26, 32, 44, 255],
    bgBottom: [15, 19, 28, 255],
    border: [55, 68, 92, 255],
    chipTop: [36, 46, 62, 255],
    chipBottom: [24, 32, 44, 255],
    chipBorder: [54, 68, 90, 255],
    boxTop: [16, 22, 32, 255],
    boxBottom: [10, 14, 20, 255],
    textDim: [150, 165, 180, 255],
    textBright: [235, 240, 245, 255],
    gold: [255, 200, 90, 255],
    good: [110, 220, 140, 255],
    bad: [230, 90, 90, 255]
};

function drawChip(c, x, y, w, h, label, value, valueColor) {
    c.roundRectGrad(x, y, w, h, 10 * SS, PALETTE.chipTop, PALETTE.chipBottom);
    c.strokeRoundRect(x, y, w, h, 10 * SS, 1.3 * SS, PALETTE.chipBorder);
    c.drawTextCentered(x + w / 2, y + 8 * SS, label, 1.35 * SS, PALETTE.textDim);
    const boxY = y + h - 30 * SS;
    c.roundRect(x + 8 * SS, boxY, w - 16 * SS, 22 * SS, 5 * SS, PALETTE.boxTop);
    c.drawTextCentered(x + w / 2, boxY + 6 * SS, value, 1.7 * SS, valueColor || PALETTE.textBright);
}

function drawBadge(c, x, y, w, h, label, owned) {
    const cx = x + w / 2;
    const iconCy = y + 20 * SS;
    const r = 14 * SS;
    c.circle(cx, iconCy, r, owned ? [16, 60, 34, 255] : [70, 20, 20, 255]);
    c.strokeRoundRect(cx - r, iconCy - r, r * 2, r * 2, r, 1.4 * SS, owned ? PALETTE.good : PALETTE.bad);
    if (owned) {
        c.line(cx - r * 0.45, iconCy + r * 0.05, cx - r * 0.1, iconCy + r * 0.45, PALETTE.good, 2.2 * SS);
        c.line(cx - r * 0.1, iconCy + r * 0.45, cx + r * 0.5, iconCy - r * 0.35, PALETTE.good, 2.2 * SS);
    } else {
        c.line(cx - r * 0.4, iconCy - r * 0.4, cx + r * 0.4, iconCy + r * 0.4, PALETTE.bad, 2.2 * SS);
        c.line(cx + r * 0.4, iconCy - r * 0.4, cx - r * 0.4, iconCy + r * 0.4, PALETTE.bad, 2.2 * SS);
    }
    c.drawTextCentered(cx, iconCy + r + 10 * SS, label, 1.3 * SS, PALETTE.textDim);
}

/**
 * @param {object} state
 * @param {number} state.coins
 * @param {number} state.banque
 * @param {number} state.reputation
 * @param {string} state.job - déjà en majuscules, mot simple (ex: "CHOMEUR", "BRAQUEUR")
 * @param {number} state.entrepot
 * @param {string} state.antirobText - ex: "NON ACTIF" ou "ACTIF (2H 30M)"
 * @param {boolean} state.antirobActive
 * @param {{bar:boolean, garage:boolean, magasin:boolean, cinema:boolean, gare:boolean, mairie:boolean}} state.batiments
 * @returns {Buffer} PNG
 */
function renderProfileBoard(state) {
    const { coins, banque, reputation, job, entrepot, antirobText, antirobActive, batiments } = state;

    const PAD = 20;
    const GAP = 12;
    const CONTENT_W = 720;
    const ROW1_H = 76;
    const ROW2_H = 50;
    const ROW3_H = 100;

    const W = CONTENT_W + PAD * 2;
    const H = PAD * 2 + ROW1_H + GAP + ROW2_H + GAP + ROW3_H;

    const c = new Canvas(W * SS, H * SS);
    c.roundRectGrad(0, 0, W * SS, H * SS, 18 * SS, PALETTE.bgTop, PALETTE.bgBottom);
    c.strokeRoundRect(0, 0, W * SS, H * SS, 18 * SS, 1.6 * SS, PALETTE.border);

    // ---- Ligne 1 : 5 chips (coins, banque, réputation, métier, entrepôt) ----
    const row1Chips = [
        { label: "COINS EN POCHE", value: String(coins), color: PALETTE.gold },
        { label: "COINS EN BANQUE", value: String(banque), color: PALETTE.textBright },
        { label: "REPUTATION", value: String(reputation), color: [235, 100, 100, 255] },
        { label: "METIER", value: job, color: PALETTE.textBright },
        { label: "ENTREPOT", value: `${entrepot}/5000`, color: PALETTE.textBright }
    ];
    const chipW1 = (CONTENT_W - 4 * GAP) / 5;
    row1Chips.forEach((chip, i) => {
        const x = (PAD + i * (chipW1 + GAP)) * SS;
        const y = PAD * SS;
        drawChip(c, x, y, chipW1 * SS, ROW1_H * SS, chip.label, chip.value, chip.color);
    });

    // ---- Ligne 2 : anti-rob (chip pleine largeur) ----
    const row2Y = (PAD + ROW1_H + GAP) * SS;
    drawChip(c, PAD * SS, row2Y, CONTENT_W * SS, ROW2_H * SS, "ANTI-ROB", antirobText, antirobActive ? PALETTE.good : PALETTE.textBright);

    // ---- Ligne 3 : bâtiments (6 badges) ----
    const row3Y = (PAD + ROW1_H + GAP + ROW2_H + GAP) * SS;
    const badges = [
        { label: "BAR", owned: batiments.bar },
        { label: "GARAGE", owned: batiments.garage },
        { label: "MAGASIN", owned: batiments.magasin },
        { label: "CINEMA", owned: batiments.cinema },
        { label: "GARE", owned: batiments.gare },
        { label: "MAIRIE", owned: batiments.mairie }
    ];
    const badgeW = (CONTENT_W - 5 * GAP) / 6;
    badges.forEach((b, i) => {
        const x = (PAD + i * (badgeW + GAP)) * SS;
        drawBadge(c, x, row3Y, badgeW * SS, ROW3_H * SS, b.label, b.owned);
    });

    const finalImg = c.downsample(SS);
    return finalImg.toPNG();
}

module.exports = { renderProfileBoard, PALETTE };
