// Génère l'image (PNG) du plateau de la commande &morpion.
// Tout est dessiné à la main avec le mini moteur de ./canvas.js (même technique que dragonBoard.js).

const { Canvas } = require("./canvas");

const SS = 2; // facteur de sur-échantillonnage (anti-aliasing)

const PALETTE = {
    bgTop: [26, 32, 44, 255],
    bgBottom: [15, 19, 28, 255],
    border: [55, 68, 92, 255],
    tileTop: [34, 44, 60, 255],
    tileBottom: [24, 32, 44, 255],
    tileWinTop: [40, 74, 52, 255],
    tileWinBottom: [26, 52, 34, 255],
    tileBorder: [54, 68, 90, 255],
    xColor: [235, 76, 84, 255],
    xDark: [140, 30, 40, 255],
    xGlow: [255, 110, 120, 130],
    oColor: [78, 178, 235, 255],
    oDark: [22, 90, 150, 255],
    oGlow: [120, 205, 255, 130],
    gold: [255, 200, 90, 255],
    textDim: [150, 165, 180, 255],
    textBright: [235, 240, 245, 255],
    win: [110, 220, 140, 255],
    lose: [230, 90, 90, 255],
    draw: [220, 190, 110, 255]
};

function drawShadowCross(c, cx, cy, r, width, color) {
    c.line(cx - r, cy - r, cx + r, cy + r, color, width);
    c.line(cx + r, cy - r, cx - r, cy + r, color, width);
}

function drawX(c, cx, cy, size, glow) {
    const r = size * 0.30;
    if (glow) c.ellipse(cx, cy, size * 0.42, size * 0.42, PALETTE.xGlow);
    // Ombre portée
    drawShadowCross(c, cx + size * 0.03, cy + size * 0.04, r, size * 0.17, [0, 0, 0, 90]);
    // Trait sombre (contour / relief)
    drawShadowCross(c, cx, cy, r, size * 0.155, PALETTE.xDark);
    // Trait principal
    drawShadowCross(c, cx, cy, r, size * 0.11, PALETTE.xColor);
    // Reflet
    c.line(cx - r * 0.55, cy - r * 0.7, cx - r * 0.05, cy - r * 0.15, [255, 255, 255, 130], size * 0.035);
    c.line(cx + r * 0.55, cy - r * 0.7, cx + r * 0.05, cy - r * 0.15, [255, 255, 255, 90], size * 0.03);
}

function drawO(c, cx, cy, size, glow, tileColor) {
    const outerR = size * 0.33, innerR = size * 0.195;
    if (glow) c.ellipse(cx, cy, size * 0.42, size * 0.42, PALETTE.oGlow);
    // Ombre portée
    c.ellipse(cx + size * 0.03, cy + size * 0.045, outerR, outerR, [0, 0, 0, 90]);
    // Anneau (dégradé) + trou de la couleur de la case pour donner l'effet "anneau"
    c.ellipseGrad(cx, cy, outerR, outerR, PALETTE.oColor, PALETTE.oDark);
    c.ellipse(cx, cy, innerR, innerR, tileColor);
    // Reflet glossy
    c.ellipse(cx - outerR * 0.32, cy - outerR * 0.4, outerR * 0.2, outerR * 0.14, [255, 255, 255, 140]);
}

function drawTurnMarker(c, x, y, size, symbol, active, color) {
    if (symbol === "X") drawX(c, x, y, size, active);
    else drawO(c, x, y, size, active, [...PALETTE.bgBottom]);
}

/**
 * @param {object} state
 * @param {(null|"X"|"O")[][]} state.grid - grid[row][col]
 * @param {"X"|"O"} state.turnSymbol - symbole dont c'est le tour
 * @param {number} state.pot - total de coins en jeu (somme des deux mises)
 * @param {boolean} state.finished
 * @param {"win"|"draw"|null} state.outcome
 * @param {[number,number][]|null} state.winnerLine - cases [row,col] formant la ligne gagnante
 * @param {string|null} state.statusText
 * @returns {Buffer} PNG
 */
function renderMorpionBoard(state) {
    const { grid, turnSymbol, pot, finished, outcome, winnerLine = [], statusText } = state;

    const CELL = 100;
    const GAP = 10;
    const PAD = 18;
    const HEADER_H = 66;
    const FOOTER_H = 40;

    const boardSize = CELL * 3 + GAP * 2;
    const W = boardSize + PAD * 2;
    const H = HEADER_H + boardSize + FOOTER_H + PAD * 2;

    const c = new Canvas(W * SS, H * SS);
    c.roundRectGrad(0, 0, W * SS, H * SS, 18 * SS, PALETTE.bgTop, PALETTE.bgBottom);
    c.strokeRoundRect(0, 0, W * SS, H * SS, 18 * SS, 1.6 * SS, PALETTE.border);

    // ---- En-tête : indicateur de tour ----
    const headerCy = (HEADER_H / 2) * SS + PAD * SS * 0.4;
    const markerSize = 34 * SS;
    drawTurnMarker(c, W * SS / 2 - 60 * SS, headerCy, markerSize, "X", turnSymbol === "X" && !finished, PALETTE.xColor);
    c.drawTextCentered(W * SS / 2, headerCy - 4 * SS, finished ? "TERMINE" : "AU TOUR DE", 1.7 * SS, PALETTE.textDim);
    drawTurnMarker(c, W * SS / 2 + 60 * SS, headerCy, markerSize, "O", turnSymbol === "O" && !finished, PALETTE.oColor);

    c.drawTextCentered(W * SS / 2, (HEADER_H - 16) * SS, `POT : ${pot} COINS`, 1.6 * SS, PALETTE.gold);

    // ---- Grille ----
    const gridX = PAD * SS;
    const gridY = HEADER_H * SS;
    for (let r = 0; r < 3; r++) {
        for (let col = 0; col < 3; col++) {
            const tileX = gridX + col * (CELL + GAP) * SS;
            const tileY = gridY + r * (CELL + GAP) * SS;
            const size = CELL * SS;
            const isWinTile = winnerLine.some(([wr, wc]) => wr === r && wc === col);

            const topColor = isWinTile ? PALETTE.tileWinTop : PALETTE.tileTop;
            const bottomColor = isWinTile ? PALETTE.tileWinBottom : PALETTE.tileBottom;

            c.roundRectGrad(tileX, tileY, size, size, 12 * SS, topColor, bottomColor);
            c.strokeRoundRect(tileX, tileY, size, size, 12 * SS, isWinTile ? 2.2 * SS : 1.4 * SS, isWinTile ? PALETTE.gold : PALETTE.tileBorder);

            const cx = tileX + size / 2, cy = tileY + size / 2;
            const cellValue = grid[r][col];
            if (cellValue === "X") drawX(c, cx, cy, size, false);
            else if (cellValue === "O") drawO(c, cx, cy, size, false, bottomColor);
        }
    }

    // ---- Pied de page : statut ----
    if (statusText) {
        const bandY = gridY + (CELL * 3 + GAP * 2) * SS + 8 * SS;
        const bandH = (FOOTER_H - 14) * SS;
        const color = outcome === "win" ? [16, 60, 30, 235] : outcome === "draw" ? [70, 58, 16, 235] : [20, 20, 26, 220];
        c.roundRect(gridX, bandY, boardSize * SS, bandH, 6 * SS, color);
        c.drawTextCentered(W * SS / 2, bandY + bandH / 2 - 5 * SS, statusText, 1.7 * SS, PALETTE.textBright);
    }

    const finalImg = c.downsample(SS);
    return finalImg.toPNG();
}

module.exports = { renderMorpionBoard, PALETTE };
