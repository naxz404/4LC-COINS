// Génère l'image (PNG) du plateau de la commande &dragon.
// Tout est dessiné à la main avec le mini moteur de ./canvas.js.

const { Canvas } = require("./canvas");

const SS = 2; // facteur de sur-échantillonnage (anti-aliasing)

const PALETTE = {
    panelBgTop: [24, 34, 46, 255],
    panelBgBottom: [16, 24, 34, 255],
    panelBorder: [50, 68, 90, 255],
    stoneLight: [110, 122, 138, 255],
    stoneDark: [70, 80, 96, 255],
    tileHidden: [22, 45, 52, 255],
    tileHiddenLine: [30, 60, 68, 200],
    tileCleared: [24, 55, 60, 255],
    tileCurrent: [30, 70, 78, 255],
    eggBase: [240, 227, 201, 255],
    eggShade: [186, 160, 126, 255],
    eggHighlight: [255, 250, 240, 255],
    eggSpeckleDark: [132, 108, 80, 255],
    eggSpeckleLight: [210, 188, 156, 255],
    shadow: [0, 0, 0, 90],
    dragonBase: [58, 24, 26, 255],
    dragonFace: [26, 12, 14, 255],
    dragonScale: [90, 34, 34, 140],
    dragonHorn: [40, 18, 20, 255],
    dragonGlow: [255, 120, 40, 255],
    dragonGlowCore: [255, 224, 150, 255],
    textDim: [150, 165, 180, 255],
    textBright: [235, 240, 245, 255],
    gold: [255, 200, 90, 255],
    good: [110, 220, 140, 255],
    bad: [230, 90, 90, 255]
};

// Petit hash déterministe (pas de Math.random) pour que la texture d'une case
// (spéculaires, tavelures) reste identique à chaque redessin du plateau.
function hash2(x, y) {
    const h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return h - Math.floor(h);
}

function drawStoneBand(c, x, y, w, h, seedRow) {
    // Bandeau de pierre (arche du haut) avec un léger appareillage de briques.
    c.fillRectGrad(x, y, w, h, PALETTE.stoneLight, PALETTE.stoneDark);
    const brickW = 42, brickH = 20;
    let rowIndex = 0;
    for (let by = y; by < y + h; by += brickH) {
        const offset = (rowIndex % 2 === 0) ? 0 : brickW / 2;
        for (let bx = x - brickW + offset; bx < x + w; bx += brickW) {
            c.line(bx, by, bx, Math.min(by + brickH, y + h), [0, 0, 0, 60], 1.2);
        }
        c.line(x, by, x + w, by, [0, 0, 0, 50], 1.2);
        rowIndex++;
    }
    c.strokeRoundRect(x, y, w, h, 0, 2, [0, 0, 0, 90]);
}

function drawDragonHead(c, cx, cy, scale) {
    const s = scale;
    // Ailes / cornes latérales
    c.polygon([
        [cx - 4 * s, cy + 2 * s], [cx - 26 * s, cy - 22 * s], [cx - 34 * s, cy - 10 * s],
        [cx - 20 * s, cy - 4 * s], [cx - 22 * s, cy + 10 * s], [cx - 8 * s, cy + 8 * s]
    ], PALETTE.stoneDark);
    c.polygon([
        [cx + 4 * s, cy + 2 * s], [cx + 26 * s, cy - 22 * s], [cx + 34 * s, cy - 10 * s],
        [cx + 20 * s, cy - 4 * s], [cx + 22 * s, cy + 10 * s], [cx + 8 * s, cy + 8 * s]
    ], PALETTE.stoneDark);
    // Tête (arc)
    c.polygon([
        [cx - 16 * s, cy + 10 * s], [cx - 14 * s, cy - 6 * s], [cx, cy - 16 * s],
        [cx + 14 * s, cy - 6 * s], [cx + 16 * s, cy + 10 * s]
    ], PALETTE.stoneLight);
    // Museau
    c.polygon([
        [cx - 8 * s, cy + 10 * s], [cx - 6 * s, cy + 4 * s], [cx + 6 * s, cy + 4 * s], [cx + 8 * s, cy + 10 * s]
    ], PALETTE.stoneDark);
    // Yeux lumineux
    c.ellipse(cx - 7 * s, cy - 2 * s, 3 * s, 2.2 * s, PALETTE.dragonGlow);
    c.ellipse(cx + 7 * s, cy - 2 * s, 3 * s, 2.2 * s, PALETTE.dragonGlow);
    c.ellipse(cx - 7 * s, cy - 2 * s, 1.3 * s, 1 * s, PALETTE.dragonGlowCore);
    c.ellipse(cx + 7 * s, cy - 2 * s, 1.3 * s, 1 * s, PALETTE.dragonGlowCore);
}

function drawEggTile(c, x, y, size, safe) {
    const cx = x + size / 2, cy = y + size / 2;
    const rx = size * 0.30, ry = size * 0.38;

    // Ombre portée au sol (donne du volume, l'oeuf ne "flotte" plus)
    c.ellipse(cx + size * 0.03, cy + ry * 0.82, rx * 0.85, ry * 0.22, PALETTE.shadow);

    // Corps de l'oeuf : dégradé de base vertical
    c.ellipseGrad(cx, cy + 1, rx, ry, PALETTE.eggBase, PALETTE.eggShade);

    // Ombrage latéral (simule une lumière venant du haut-gauche) : un voile sombre
    // sur le bord droit et un voile clair sur le bord gauche, tous deux semi-transparents
    c.ellipse(cx + rx * 0.42, cy + ry * 0.12, rx * 0.62, ry * 0.85, [...PALETTE.eggShade.slice(0, 3), 70]);
    c.ellipse(cx - rx * 0.4, cy - ry * 0.35, rx * 0.5, ry * 0.55, [...PALETTE.eggHighlight.slice(0, 3), 60]);

    // Reflet spéculaire net (aspect "coquille lisse")
    c.ellipse(cx - rx * 0.32, cy - ry * 0.42, rx * 0.16, ry * 0.22, [...PALETTE.eggHighlight.slice(0, 3), 190]);

    // Tavelures naturelles, réparties de façon déterministe (seed = position de la case)
    for (let i = 0; i < 9; i++) {
        const n1 = hash2(x + i * 3.1, y + i * 1.7);
        const n2 = hash2(x + i * 5.3, y + i * 7.9);
        const n3 = hash2(x + i * 2.2, y + i * 9.4);
        const sx = cx + (n1 - 0.5) * rx * 1.5;
        const sy = cy + (n2 - 0.5) * ry * 1.6;
        const nx = (sx - cx) / rx, ny = (sy - cy) / ry;
        if (nx * nx + ny * ny > 0.92) continue; // reste dans l'ellipse
        const sSize = size * (0.02 + n3 * 0.035);
        const dark = n3 > 0.5;
        c.ellipse(sx, sy, sSize, sSize * 0.8, dark ? PALETTE.eggSpeckleDark : PALETTE.eggSpeckleLight);
    }

    if (safe) {
        c.circle(x + size - 8, y + 8, 7, [0, 0, 0, 70]);
        c.circle(x + size - 8, y + 8, 6, PALETTE.good);
        c.line(x + size - 10, y + 8, x + size - 9, y + 10, [10, 30, 15, 255], 1.6);
        c.line(x + size - 9, y + 10, x + size - 6, y + 5, [10, 30, 15, 255], 1.6);
    }
}

function drawDragonTile(c, x, y, size) {
    const cx = x + size / 2, cy = y + size / 2;
    const rx = size * 0.34, ry = size * 0.38;

    // Ombre portée
    c.ellipse(cx + size * 0.03, cy + ry * 0.8, rx * 0.9, ry * 0.22, PALETTE.shadow);

    // Tête / crâne (dégradé sombre pour donner du relief)
    c.ellipseGrad(cx, cy, rx, ry, PALETTE.dragonBase, PALETTE.dragonFace);

    // Petites cornes
    c.polygon([[cx - rx * 0.5, cy - ry * 0.55], [cx - rx * 0.62, cy - ry * 1.05], [cx - rx * 0.28, cy - ry * 0.6]], PALETTE.dragonHorn);
    c.polygon([[cx + rx * 0.5, cy - ry * 0.55], [cx + rx * 0.62, cy - ry * 1.05], [cx + rx * 0.28, cy - ry * 0.6]], PALETTE.dragonHorn);

    // Texture "écailles" légère (quelques arcs semi-transparents, déterministes)
    for (let i = 0; i < 5; i++) {
        const n = hash2(x + i * 4.7, y + i * 2.3);
        const sy = cy - ry * 0.5 + n * ry * 1.2;
        c.line(cx - rx * 0.5, sy, cx + rx * 0.5, sy - ry * 0.1, PALETTE.dragonScale, 1.4);
    }

    // Sourcils
    c.line(cx - rx * 0.55, cy - ry * 0.25, cx - rx * 0.1, cy - ry * 0.45, [0, 0, 0, 220], size * 0.05);
    c.line(cx + rx * 0.55, cy - ry * 0.25, cx + rx * 0.1, cy - ry * 0.45, [0, 0, 0, 220], size * 0.05);

    // Yeux lumineux avec halo + pupille
    c.ellipse(cx - rx * 0.4, cy, rx * 0.28, ry * 0.22, [...PALETTE.dragonGlow.slice(0, 3), 110]);
    c.ellipse(cx + rx * 0.4, cy, rx * 0.28, ry * 0.22, [...PALETTE.dragonGlow.slice(0, 3), 110]);
    c.ellipse(cx - rx * 0.4, cy, rx * 0.2, ry * 0.15, PALETTE.dragonGlow);
    c.ellipse(cx + rx * 0.4, cy, rx * 0.2, ry * 0.15, PALETTE.dragonGlow);
    c.ellipse(cx - rx * 0.4, cy, rx * 0.09, ry * 0.07, [20, 0, 0, 255]);
    c.ellipse(cx + rx * 0.4, cy, rx * 0.09, ry * 0.07, [20, 0, 0, 255]);
    c.ellipse(cx - rx * 0.44, cy - ry * 0.06, rx * 0.05, ry * 0.04, PALETTE.dragonGlowCore);
    c.ellipse(cx + rx * 0.36, cy - ry * 0.06, rx * 0.05, ry * 0.04, PALETTE.dragonGlowCore);

    // Narines / museau
    c.ellipse(cx - rx * 0.15, cy + ry * 0.5, rx * 0.07, ry * 0.05, [10, 4, 4, 200]);
    c.ellipse(cx + rx * 0.15, cy + ry * 0.5, rx * 0.07, ry * 0.05, [10, 4, 4, 200]);
}

function drawHiddenTile(c, x, y, size, highlight) {
    c.roundRect(x, y, size, size, size * 0.14, highlight ? PALETTE.tileCurrent : PALETTE.tileHidden);
    // Croisillons diagonaux (motif "case cachée")
    const step = size / 4;
    for (let i = -1; i <= 4; i++) {
        c.line(x + i * step, y + size, x + (i + 1) * step, y, PALETTE.tileHiddenLine, 1.4);
    }
    if (highlight) {
        c.strokeRoundRect(x, y, size, size, size * 0.14, 2.2, PALETTE.gold);
    } else {
        c.strokeRoundRect(x, y, size, size, size * 0.14, 1.4, [0, 0, 0, 120]);
    }
}

/**
 * @param {object} state
 * @param {number} state.mise
 * @param {number} state.multiplier
 * @param {number} state.level - palier actuellement validé (0 = pas encore commencé)
 * @param {number} state.rows
 * @param {number} state.cols
 * @param {number[][]} state.board - board[r] = colonnes occupées par un dragon à la ligne r
 * @param {string} state.difficultyLabel
 * @param {boolean} state.finished
 * @param {"win"|"lose"|null} state.outcome
 * @param {string|null} state.statusText
 * @param {number[]} [state.chosenCols] - colonne cliquée par le joueur pour chaque palier validé (chosenCols[r] = colonne choisie à la ligne r)
 * @returns {Buffer} PNG
 */
function renderDragonBoard(state) {
    const { mise, multiplier, level, rows, cols, board, difficultyLabel, finished, outcome, statusText, chosenCols = [] } = state;

    const TILE = 48;
    const GAP = 7;
    const GRID_PAD = 14;
    const HEADER_H = 78;
    const LEFT_W = 190;
    const MARGIN = 16;
    const RIGHT_W = cols * TILE + (cols - 1) * GAP + GRID_PAD * 2;
    const RIGHT_H = HEADER_H + rows * TILE + (rows - 1) * GAP + GRID_PAD * 2;
    const PANEL_GAP = 14;

    const W = MARGIN * 2 + LEFT_W + PANEL_GAP + RIGHT_W;
    const H = MARGIN * 2 + RIGHT_H;

    const c = new Canvas(W * SS, H * SS);

    // ---- Panneau gauche : infos ----
    const lx = MARGIN * SS, ly = MARGIN * SS, lw = LEFT_W * SS, lh = RIGHT_H * SS;
    c.roundRectGrad(lx, ly, lw, lh, 16 * SS, PALETTE.panelBgTop, PALETTE.panelBgBottom);
    c.strokeRoundRect(lx, ly, lw, lh, 16 * SS, 1.5 * SS, PALETTE.panelBorder);

    let cursorY = ly + 22 * SS;
    c.drawText(lx + 18 * SS, cursorY, "MONTANT DU PARI", 2 * SS, PALETTE.textDim);
    cursorY += 20 * SS;
    c.roundRect(lx + 16 * SS, cursorY, lw - 32 * SS, 30 * SS, 6 * SS, [12, 18, 26, 255]);
    c.drawTextCentered(lx + lw / 2, cursorY + 8 * SS, String(mise), 3 * SS, PALETTE.textBright);
    cursorY += 48 * SS;

    c.drawText(lx + 18 * SS, cursorY, "MULTIPLICATEUR", 2 * SS, PALETTE.textDim);
    cursorY += 20 * SS;
    c.roundRect(lx + 16 * SS, cursorY, lw - 32 * SS, 30 * SS, 6 * SS, [12, 18, 26, 255]);
    c.drawTextCentered(lx + lw / 2, cursorY + 8 * SS, `X${multiplier.toFixed(2)}`, 3 * SS, PALETTE.gold);
    cursorY += 48 * SS;

    c.drawText(lx + 18 * SS, cursorY, "PALIER", 2 * SS, PALETTE.textDim);
    cursorY += 20 * SS;
    c.roundRect(lx + 16 * SS, cursorY, lw - 32 * SS, 30 * SS, 6 * SS, [12, 18, 26, 255]);
    c.drawTextCentered(lx + lw / 2, cursorY + 8 * SS, `${level}/${rows}`, 3 * SS, PALETTE.textBright);
    cursorY += 30 * SS;

    const footerText = finished
        ? "PARTIE TERMINEE"
        : "RETIRE TES GAINS A TOUT MOMENT AVEC LE BOUTON SOUS LE MESSAGE";
    const footerLines = Canvas.wrapText(footerText, 1.6 * SS, lw - 32 * SS);
    let fy = ly + lh - 20 * SS - footerLines.length * 12 * SS;
    for (const line of footerLines) {
        c.drawText(lx + 16 * SS, fy, line, 1.6 * SS, PALETTE.textDim);
        fy += 12 * SS;
    }

    // ---- Panneau droit : tour ----
    const rx = lx + lw + PANEL_GAP * SS, ry = ly, rw = RIGHT_W * SS, rh = RIGHT_H * SS;
    c.roundRectGrad(rx, ry, rw, rh, 16 * SS, [18, 28, 34, 255], [10, 16, 20, 255]);
    c.strokeRoundRect(rx, ry, rw, rh, 16 * SS, 1.5 * SS, PALETTE.panelBorder);

    drawStoneBand(c, rx, ry, rw, HEADER_H * SS, 0);
    drawDragonHead(c, rx + rw / 2, ry + HEADER_H * SS * 0.55, SS * 1.3);

    const gridX = rx + GRID_PAD * SS;
    const gridTop = ry + HEADER_H * SS + GRID_PAD * SS;
    for (let r = 0; r < rows; r++) {
        // r = 0 en bas (départ), r = rows-1 en haut (sommet de la tour)
        const rowFromTop = rows - 1 - r;
        const tileY = gridTop + rowFromTop * (TILE + GAP) * SS;
        for (let col = 0; col < cols; col++) {
            const tileX = gridX + col * (TILE + GAP) * SS;
            const size = TILE * SS;

            if (finished) {
                const isDragon = board[r] && board[r].includes(col);
                if (isDragon) drawDragonTile(c, tileX, tileY, size);
                else drawEggTile(c, tileX, tileY, size, false);
            } else if (r < level) {
                // Ligne déjà validée : on ne révèle QUE la case cliquée par le joueur (son oeuf),
                // les autres cases de la ligne restent cachées.
                if (chosenCols[r] === col) {
                    drawEggTile(c, tileX, tileY, size, true);
                } else {
                    drawHiddenTile(c, tileX, tileY, size, false);
                }
            } else {
                drawHiddenTile(c, tileX, tileY, size, r === level);
            }
        }
    }

    // Bandeau de statut
    if (statusText) {
        const bandH = 30 * SS;
        const bandY = gridTop + (rows * TILE + (rows - 1) * GAP) * SS / 2 - bandH / 2;
        const color = outcome === "win" ? [16, 60, 30, 235] : outcome === "lose" ? [70, 16, 16, 235] : [20, 20, 26, 220];
        c.roundRect(gridX - 4 * SS, bandY, (rw - GRID_PAD * SS * 2) + 8 * SS, bandH, 6 * SS, color);
        c.drawTextCentered(rx + rw / 2, bandY + bandH / 2 - 5 * SS, statusText, 1.8 * SS, PALETTE.textBright);
    }

    const finalImg = c.downsample(SS);
    return finalImg.toPNG();
}

module.exports = { renderDragonBoard, PALETTE };
