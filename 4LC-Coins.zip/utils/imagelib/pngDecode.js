// Décodeur PNG minimaliste, écrit à la main (miroir de png.js qui encode).
// Aucune dépendance externe : uniquement `zlib`, natif à Node.js.
// Supporte : color type 0/2/3/4/6, bit depth 1/2/4/8/16, non-entrelacé.

const zlib = require("zlib");

function readChunks(buf) {
    const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    if (buf.length < 8 || !buf.slice(0, 8).equals(sig)) {
        throw new Error("Signature PNG invalide");
    }
    let offset = 8;
    const chunks = [];
    while (offset + 8 <= buf.length) {
        const len = buf.readUInt32BE(offset); offset += 4;
        const type = buf.toString("ascii", offset, offset + 4); offset += 4;
        const data = buf.slice(offset, offset + len); offset += len;
        offset += 4; // CRC (non vérifié, on fait confiance à la source)
        chunks.push({ type, data });
        if (type === "IEND") break;
    }
    return chunks;
}

function paeth(a, b, c) {
    const p = a + b - c;
    const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
    if (pa <= pb && pa <= pc) return a;
    if (pb <= pc) return b;
    return c;
}

function unfilter(raw, height, bpp, stride) {
    const out = Buffer.alloc(height * stride);
    let rawOff = 0, outOff = 0;
    for (let y = 0; y < height; y++) {
        const filterType = raw[rawOff]; rawOff += 1;
        for (let x = 0; x < stride; x++) {
            const val = raw[rawOff + x];
            const a = x >= bpp ? out[outOff + x - bpp] : 0;
            const b = y > 0 ? out[outOff - stride + x] : 0;
            const c = (x >= bpp && y > 0) ? out[outOff - stride + x - bpp] : 0;
            let recon;
            switch (filterType) {
                case 0: recon = val; break;
                case 1: recon = val + a; break;
                case 2: recon = val + b; break;
                case 3: recon = val + ((a + b) >> 1); break;
                case 4: recon = val + paeth(a, b, c); break;
                default: recon = val;
            }
            out[outOff + x] = recon & 0xff;
        }
        rawOff += stride;
        outOff += stride;
    }
    return out;
}

function getSample(row, bitOffset, depth) {
    if (depth === 8 || depth === 16) return row[bitOffset >> 3];
    const byte = row[bitOffset >> 3];
    const shift = 8 - depth - (bitOffset % 8);
    const mask = (1 << depth) - 1;
    return (byte >> shift) & mask;
}

/**
 * Décode un PNG en RGBA brut.
 * @param {Buffer} buffer
 * @returns {{width:number, height:number, data:Uint8ClampedArray}}
 */
function decodePNG(buffer) {
    const chunks = readChunks(buffer);
    const ihdr = chunks.find((c) => c.type === "IHDR");
    if (!ihdr) throw new Error("IHDR manquant");

    const width = ihdr.data.readUInt32BE(0);
    const height = ihdr.data.readUInt32BE(4);
    const bitDepth = ihdr.data[8];
    const colorType = ihdr.data[9];
    const interlace = ihdr.data[12];
    if (interlace !== 0) throw new Error("PNG entrelacé non supporté");

    const channelsMap = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 };
    const channels = channelsMap[colorType];
    if (!channels) throw new Error("Type de couleur PNG non supporté");
    if (![1, 2, 4, 8, 16].includes(bitDepth)) throw new Error("Profondeur de bits non supportée");

    let palette = null;
    const plteChunk = chunks.find((c) => c.type === "PLTE");
    if (plteChunk) {
        palette = [];
        for (let i = 0; i < plteChunk.data.length; i += 3) {
            palette.push([plteChunk.data[i], plteChunk.data[i + 1], plteChunk.data[i + 2]]);
        }
    }
    let trns = null;
    const trnsChunk = chunks.find((c) => c.type === "tRNS");
    if (trnsChunk) trns = trnsChunk.data;

    const idatData = Buffer.concat(chunks.filter((c) => c.type === "IDAT").map((c) => c.data));
    const raw = zlib.inflateSync(idatData);

    const bitsPerPixel = channels * bitDepth;
    const bpp = Math.max(1, Math.ceil(bitsPerPixel / 8));
    const stride = Math.ceil((width * bitsPerPixel) / 8);

    const px = unfilter(raw, height, bpp, stride);
    const out = new Uint8ClampedArray(width * height * 4);

    for (let y = 0; y < height; y++) {
        const row = px.subarray(y * stride, y * stride + stride);
        for (let x = 0; x < width; x++) {
            let r, g, b, a = 255;
            if (colorType === 3) {
                const idx = getSample(row, x * bitDepth, bitDepth);
                const col = (palette && palette[idx]) || [0, 0, 0];
                r = col[0]; g = col[1]; b = col[2];
                a = trns && idx < trns.length ? trns[idx] : 255;
            } else if (colorType === 0) {
                const v = getSample(row, x * bitDepth, bitDepth);
                const maxVal = (1 << bitDepth) - 1;
                r = g = b = bitDepth === 8 ? v : bitDepth === 16 ? v : Math.round((v / maxVal) * 255);
            } else if (colorType === 4) {
                const step = bitDepth === 16 ? 4 : 2;
                const off = x * step;
                r = g = b = row[off];
                a = row[off + (bitDepth === 16 ? 2 : 1)];
            } else if (colorType === 2) {
                const step = bitDepth === 16 ? 6 : 3;
                const off = x * step;
                r = row[off]; g = row[off + (bitDepth === 16 ? 2 : 1)]; b = row[off + (bitDepth === 16 ? 4 : 2)];
            } else if (colorType === 6) {
                const step = bitDepth === 16 ? 8 : 4;
                const off = x * step;
                r = row[off]; g = row[off + (bitDepth === 16 ? 2 : 1)]; b = row[off + (bitDepth === 16 ? 4 : 2)]; a = row[off + (bitDepth === 16 ? 6 : 3)];
            }
            const oi = (y * width + x) * 4;
            out[oi] = r; out[oi + 1] = g; out[oi + 2] = b; out[oi + 3] = a;
        }
    }

    return { width, height, data: out };
}

module.exports = { decodePNG };
