// Mini moteur de dessin "canvas-like", 100% JS pur, sans dépendance.
// Fonctionne sur un buffer de pixels RGBA en mémoire.

const { encodePNG } = require("./png");
const { GLYPHS, normalize } = require("./font");

function dist(x1, y1, x2, y2) {
    const dx = x1 - x2, dy = y1 - y2;
    return Math.sqrt(dx * dx + dy * dy);
}

function lerpColor(c1, c2, t) {
    const a1 = c1[3] === undefined ? 255 : c1[3];
    const a2 = c2[3] === undefined ? 255 : c2[3];
    return [
        c1[0] + (c2[0] - c1[0]) * t,
        c1[1] + (c2[1] - c1[1]) * t,
        c1[2] + (c2[2] - c1[2]) * t,
        a1 + (a2 - a1) * t
    ];
}

function insideRoundRect(px, py, x, y, w, h, r) {
    if (px < x || px > x + w || py < y || py > y + h) return false;
    if (r <= 0) return true;
    if (px < x + r && py < y + r) return dist(px, py, x + r, y + r) <= r;
    if (px > x + w - r && py < y + r) return dist(px, py, x + w - r, y + r) <= r;
    if (px < x + r && py > y + h - r) return dist(px, py, x + r, y + h - r) <= r;
    if (px > x + w - r && py > y + h - r) return dist(px, py, x + w - r, y + h - r) <= r;
    return true;
}

class Canvas {
    constructor(width, height, bg = null) {
        this.width = width;
        this.height = height;
        this.data = new Float32Array(width * height * 4);
        if (bg) this.fillRect(0, 0, width, height, bg);
    }

    setPixel(x, y, color) {
        x = x | 0;
        y = y | 0;
        if (x < 0 || y < 0 || x >= this.width || y >= this.height) return;
        const r = color[0], g = color[1], b = color[2];
        const a = color[3] === undefined ? 255 : color[3];
        const i = (y * this.width + x) * 4;
        if (a >= 255) {
            this.data[i] = r; this.data[i + 1] = g; this.data[i + 2] = b; this.data[i + 3] = 255;
            return;
        }
        if (a <= 0) return;
        const alpha = a / 255;
        const dr = this.data[i], dg = this.data[i + 1], db = this.data[i + 2], da = this.data[i + 3] / 255;
        const outA = alpha + da * (1 - alpha);
        if (outA <= 0) { this.data[i + 3] = 0; return; }
        this.data[i] = (r * alpha + dr * da * (1 - alpha)) / outA;
        this.data[i + 1] = (g * alpha + dg * da * (1 - alpha)) / outA;
        this.data[i + 2] = (b * alpha + db * da * (1 - alpha)) / outA;
        this.data[i + 3] = outA * 255;
    }

    fillRect(x, y, w, h, color) {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
        for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.setPixel(i, j, color);
    }

    fillRectGrad(x, y, w, h, colorTop, colorBottom) {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
        for (let j = 0; j < h; j++) {
            const t = h <= 1 ? 0 : j / (h - 1);
            const c = lerpColor(colorTop, colorBottom, t);
            for (let i = 0; i < w; i++) this.setPixel(x + i, y + j, c);
        }
    }

    roundRect(x, y, w, h, r, color) {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
        r = Math.min(r, w / 2, h / 2);
        for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) {
            if (insideRoundRect(i + 0.5, j + 0.5, x, y, w, h, r)) this.setPixel(i, j, color);
        }
    }

    roundRectGrad(x, y, w, h, r, colorTop, colorBottom) {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
        r = Math.min(r, w / 2, h / 2);
        for (let j = y; j < y + h; j++) {
            const t = h <= 1 ? 0 : (j - y) / (h - 1);
            const c = lerpColor(colorTop, colorBottom, t);
            for (let i = x; i < x + w; i++) {
                if (insideRoundRect(i + 0.5, j + 0.5, x, y, w, h, r)) this.setPixel(i, j, c);
            }
        }
    }

    strokeRoundRect(x, y, w, h, r, thickness, color) {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
        r = Math.min(r, w / 2, h / 2);
        for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) {
            const outer = insideRoundRect(i + 0.5, j + 0.5, x, y, w, h, r);
            const inner = insideRoundRect(i + 0.5, j + 0.5, x + thickness, y + thickness, w - 2 * thickness, h - 2 * thickness, Math.max(0, r - thickness));
            if (outer && !inner) this.setPixel(i, j, color);
        }
    }

    circle(cx, cy, r, color) {
        const x0 = Math.floor(cx - r), x1 = Math.ceil(cx + r), y0 = Math.floor(cy - r), y1 = Math.ceil(cy + r);
        for (let j = y0; j <= y1; j++) for (let i = x0; i <= x1; i++) {
            if (dist(i + 0.5, j + 0.5, cx, cy) <= r) this.setPixel(i, j, color);
        }
    }

    ellipse(cx, cy, rx, ry, color) {
        const x0 = Math.floor(cx - rx), x1 = Math.ceil(cx + rx), y0 = Math.floor(cy - ry), y1 = Math.ceil(cy + ry);
        for (let j = y0; j <= y1; j++) for (let i = x0; i <= x1; i++) {
            const nx = (i + 0.5 - cx) / rx, ny = (j + 0.5 - cy) / ry;
            if (nx * nx + ny * ny <= 1) this.setPixel(i, j, color);
        }
    }

    ellipseGrad(cx, cy, rx, ry, colorTop, colorBottom) {
        const x0 = Math.floor(cx - rx), x1 = Math.ceil(cx + rx), y0 = Math.floor(cy - ry), y1 = Math.ceil(cy + ry);
        for (let j = y0; j <= y1; j++) {
            const t = Math.min(1, Math.max(0, (j - (cy - ry)) / (2 * ry)));
            const c = lerpColor(colorTop, colorBottom, t);
            for (let i = x0; i <= x1; i++) {
                const nx = (i + 0.5 - cx) / rx, ny = (j + 0.5 - cy) / ry;
                if (nx * nx + ny * ny <= 1) this.setPixel(i, j, c);
            }
        }
    }

    line(x0, y0, x1, y1, color, width = 1) {
        const minX = Math.floor(Math.min(x0, x1) - width), maxX = Math.ceil(Math.max(x0, x1) + width);
        const minY = Math.floor(Math.min(y0, y1) - width), maxY = Math.ceil(Math.max(y0, y1) + width);
        const dx = x1 - x0, dy = y1 - y0, len2 = dx * dx + dy * dy || 1;
        for (let j = minY; j <= maxY; j++) for (let i = minX; i <= maxX; i++) {
            const px = i + 0.5, py = j + 0.5;
            let t = ((px - x0) * dx + (py - y0) * dy) / len2;
            t = Math.max(0, Math.min(1, t));
            const cx = x0 + t * dx, cy = y0 + t * dy;
            if (dist(px, py, cx, cy) <= width / 2) this.setPixel(i, j, color);
        }
    }

    polygon(points, color) {
        let minY = Infinity, maxY = -Infinity;
        for (const [, py] of points) { if (py < minY) minY = py; if (py > maxY) maxY = py; }
        minY = Math.floor(minY); maxY = Math.ceil(maxY);
        for (let y = minY; y <= maxY; y++) {
            const xs = [];
            for (let i = 0; i < points.length; i++) {
                const [x1, y1] = points[i], [x2, y2] = points[(i + 1) % points.length];
                if ((y1 <= y + 0.5 && y2 > y + 0.5) || (y2 <= y + 0.5 && y1 > y + 0.5)) {
                    const t = (y + 0.5 - y1) / (y2 - y1);
                    xs.push(x1 + t * (x2 - x1));
                }
            }
            xs.sort((a, b) => a - b);
            for (let i = 0; i + 1 < xs.length; i += 2) {
                const xStart = Math.round(xs[i]), xEnd = Math.round(xs[i + 1]);
                for (let x = xStart; x < xEnd; x++) this.setPixel(x, y, color);
            }
        }
    }

    drawCanvas(src, dx, dy) {
        for (let j = 0; j < src.height; j++) for (let i = 0; i < src.width; i++) {
            const si = (j * src.width + i) * 4;
            const a = src.data[si + 3];
            if (a <= 0) continue;
            this.setPixel(dx + i, dy + j, [src.data[si], src.data[si + 1], src.data[si + 2], a]);
        }
    }

    drawText(x, y, text, scale, color) {
        let cx = x;
        for (const ch of normalize(text)) {
            const glyph = GLYPHS[ch] || GLYPHS[" "];
            for (let row = 0; row < 7; row++) {
                const bits = glyph[row];
                for (let col = 0; col < 5; col++) {
                    if (bits & (1 << (4 - col))) {
                        this.fillRect(cx + col * scale, y + row * scale, scale, scale, color);
                    }
                }
            }
            cx += 6 * scale;
        }
        return cx - x;
    }

    drawTextCentered(cx, y, text, scale, color) {
        const w = Canvas.measureText(text, scale);
        this.drawText(cx - w / 2, y, text, scale, color);
        return w;
    }

    static measureText(text, scale) {
        const clean = normalize(text);
        return Math.max(0, clean.length * 6 * scale - scale);
    }

    // Découpe un texte en lignes qui tiennent dans maxWidth (px), pour un scale donné.
    static wrapText(text, scale, maxWidth) {
        const words = String(text).split(" ");
        const lines = [];
        let current = "";
        for (const word of words) {
            const attempt = current ? `${current} ${word}` : word;
            if (Canvas.measureText(attempt, scale) > maxWidth && current) {
                lines.push(current);
                current = word;
            } else {
                current = attempt;
            }
        }
        if (current) lines.push(current);
        return lines;
    }

    // Sur-échantillonnage : réduit l'image d'un facteur entier en moyennant les blocs
    // de pixels (anti-aliasing "gratuit" pour les formes rondes et le texte).
    downsample(factor) {
        factor = Math.round(factor);
        if (factor <= 1) return this;
        const nw = Math.floor(this.width / factor), nh = Math.floor(this.height / factor);
        const out = new Canvas(nw, nh);
        for (let y = 0; y < nh; y++) {
            for (let x = 0; x < nw; x++) {
                let r = 0, g = 0, b = 0, a = 0;
                for (let jy = 0; jy < factor; jy++) for (let jx = 0; jx < factor; jx++) {
                    const sx = x * factor + jx, sy = y * factor + jy;
                    const i = (sy * this.width + sx) * 4;
                    const sa = this.data[i + 3];
                    r += this.data[i] * sa; g += this.data[i + 1] * sa; b += this.data[i + 2] * sa; a += sa;
                }
                const n = factor * factor;
                const oi = (y * nw + x) * 4;
                if (a > 0) {
                    out.data[oi] = r / a; out.data[oi + 1] = g / a; out.data[oi + 2] = b / a; out.data[oi + 3] = a / n;
                }
            }
        }
        return out;
    }

    toPNG() {
        const bytes = new Uint8ClampedArray(this.data.length);
        for (let i = 0; i < this.data.length; i++) bytes[i] = this.data[i];
        return encodePNG(this.width, this.height, Buffer.from(bytes.buffer));
    }
}

module.exports = { Canvas, lerpColor, dist };
