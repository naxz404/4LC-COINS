// Encodeur PNG minimaliste, écrit à la main.
// Aucune dépendance externe : uniquement `zlib`, natif à Node.js.
// On encode toujours en RGBA 8 bits (color type 6), filtre "None" par ligne.

const zlib = require("zlib");

// Table CRC32 standard (utilisée pour valider chaque chunk PNG)
const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) {
            c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
        }
        table[n] = c >>> 0;
    }
    return table;
})();

function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
        c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
    const typeBuf = Buffer.from(type, "ascii");
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(data.length, 0);
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
    return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

/**
 * Encode un buffer RGBA brut (width*height*4 octets) en PNG.
 * @param {number} width
 * @param {number} height
 * @param {Buffer|Uint8Array} rgba
 * @returns {Buffer}
 */
function encodePNG(width, height, rgba) {
    const stride = width * 4;
    // Chaque ligne de pixels est précédée d'un octet "type de filtre" (0 = aucun filtre).
    const raw = Buffer.alloc((stride + 1) * height);
    for (let y = 0; y < height; y++) {
        raw[y * (stride + 1)] = 0;
        Buffer.from(rgba.buffer || rgba, rgba.byteOffset || 0).copy(
            raw,
            y * (stride + 1) + 1,
            y * stride,
            y * stride + stride
        );
    }

    const idatData = zlib.deflateSync(raw, { level: 9 });

    const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(width, 0);
    ihdr.writeUInt32BE(height, 4);
    ihdr[8] = 8; // bit depth
    ihdr[9] = 6; // color type : RGBA
    ihdr[10] = 0; // compression
    ihdr[11] = 0; // filtre
    ihdr[12] = 0; // entrelacement

    return Buffer.concat([
        signature,
        chunk("IHDR", ihdr),
        chunk("IDAT", idatData),
        chunk("IEND", Buffer.alloc(0))
    ]);
}

module.exports = { encodePNG, crc32 };
