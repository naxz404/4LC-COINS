const { Client, Collection, GatewayIntentBits, Partials } = require("discord.js");
const managerStore = require("./managerStore");
const commandEvent = require("../events/message/commandHandler");

const activeClients = new Map();

function inviteUrl(clientId) {
  return `https://discord.com/oauth2/authorize?client_id=${clientId}&permissions=8&scope=bot`;
}

function buildClient(record, mainBot) {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember]
  });

  client.commands = new Collection(
    [...mainBot.commands.entries()].filter(([, command]) => !command.help?.managerOnly)
  );
  client.config = mainBot.config;
  client.db = mainBot.db;
  client.footer = mainBot.footer;
  client.supportLink = mainBot.supportLink;
  client.antirob = new Map();
  client.isManagedBot = true;
  client.managedBotId = record.id;
  client.managedBotOwnerId = record.ownerId;

  client.on("messageCreate", async (message) => {
    if (!message.guild || message.author.bot) return;
    client.db.query(`SELECT * FROM guild WHERE guildId = "${message.guild.id}"`, async (err, req) => {
      client.prefix = req.length < 1 || !req[0].prefix ? "*" : req[0].prefix;
      commandEvent.execute(message, client).catch(console.error);
    });
  });

  client.once("clientReady", () => {
    managerStore.updateBot(record.id, {
      status: "online",
      clientId: client.user.id,
      username: client.user.username,
      tag: client.user.tag,
      inviteUrl: inviteUrl(client.user.id),
      lastError: null
    });
    console.log(`4LC client connecte: ${client.user.tag}`);
  });

  return client;
}

async function startManagedBot(record, mainBot) {
  if (activeClients.has(record.id)) return activeClients.get(record.id);
  const client = buildClient(record, mainBot);
  activeClients.set(record.id, client);
  try {
    await client.login(record.token);
  } catch (error) {
    activeClients.delete(record.id);
    managerStore.updateBot(record.id, { status: "error", lastError: error.message });
    throw error;
  }
  return client;
}

async function stopManagedBot(botId) {
  const client = activeClients.get(botId);
  if (!client) return false;
  activeClients.delete(botId);
  await client.destroy();
  managerStore.updateBot(botId, { status: "stopped" });
  return true;
}

async function startAllManagedBots(mainBot) {
  const records = managerStore.activeBots();
  for (const record of records) {
    startManagedBot(record, mainBot).catch((error) => {
      console.log(`Impossible de lancer le bot client ${record.id}: ${error.message}`);
    });
  }
  return records.length;
}

module.exports = {
  activeClients,
  inviteUrl,
  startManagedBot,
  stopManagedBot,
  startAllManagedBots
};
