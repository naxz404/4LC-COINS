// Création du profil économique d'un utilisateur (tables user/batiment/gain/mine/job/xp/...)
// Utilisé par la commande &start ET par le bouton "acces_getrole_" (rôle -> profil auto)
module.exports.createUserProfile = (bot, guildId, userId) => {
  const queries = [
    `INSERT INTO batiment (guildId, userId) SELECT "${guildId}", "${userId}" WHERE NOT EXISTS (SELECT 1 FROM batiment WHERE guildId = ${guildId} AND userId = "${userId}")`,
    `INSERT INTO user (guildId, userId) SELECT "${guildId}", "${userId}" WHERE NOT EXISTS (SELECT 1 FROM user WHERE guildId = ${guildId} AND userId = "${userId}")`,
    `INSERT INTO gain (guildId) SELECT "${guildId}" WHERE NOT EXISTS (SELECT 1 FROM gain WHERE guildId = ${guildId})`,
    `INSERT INTO mine (guildId, userId) SELECT "${guildId}", "${userId}" WHERE NOT EXISTS (SELECT 1 FROM mine WHERE guildId = ${guildId} AND userId = "${userId}")`,
    `INSERT INTO job (guildId, userId) SELECT "${guildId}", "${userId}" WHERE NOT EXISTS (SELECT 1 FROM job WHERE guildId = ${guildId} AND userId = "${userId}")`,
    `INSERT INTO cards (guildId, userId) SELECT "${guildId}", "${userId}" WHERE NOT EXISTS (SELECT 1 FROM cards WHERE guildId = ${guildId} AND userId = "${userId}")`,
    `INSERT INTO xp (guildId) SELECT "${guildId}" WHERE NOT EXISTS (SELECT 1 FROM xp WHERE guildId = ${guildId})`,
    `INSERT INTO commands (guildId) SELECT "${guildId}" WHERE NOT EXISTS (SELECT 1 FROM commands WHERE guildId = ${guildId})`,
    `INSERT INTO guild (guildId) SELECT "${guildId}" WHERE NOT EXISTS (SELECT 1 FROM guild WHERE guildId = ${guildId})`,
    `INSERT INTO logs (guildId) SELECT "${guildId}" WHERE NOT EXISTS (SELECT 1 FROM logs WHERE guildId = ${guildId})`,
    `INSERT INTO bot (botId) SELECT "${bot.user.id}" WHERE NOT EXISTS (SELECT 1 FROM bot WHERE botId = ${bot.user.id})`
  ];

  for (const query of queries) {
    bot.db.query(query, (err) => {
      if (err) throw err;
    });
  }
};

// Vérifie si un utilisateur a déjà un profil (table user), callback(hasProfile: boolean)
module.exports.hasProfile = (bot, guildId, userId, callback) => {
  bot.db.query(`SELECT * FROM user WHERE guildId = "${guildId}" AND userId = "${userId}"`, (err, req) => {
    callback(!err && req.length >= 1);
  });
};
