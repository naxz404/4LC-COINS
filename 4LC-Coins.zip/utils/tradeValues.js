// ---------------------------------------------------------------------------
// Valeurs de référence utilisées par &trade et &value pour juger si un
// échange (métier/capacité <-> argent, ou métier/capacité <-> métier/capacité)
// est équilibré ou non.
//
// Base de calcul : le prix d'achat original de chaque métier/capacité était
// exprimé en réputation (voir commands/job/job.js et commands/illegal/mobil.js).
// On applique un taux de conversion pour obtenir un équivalent en coins,
// cohérent avec le reste de l'économie (vente d'objets entre 1500 et 7000 coins).
// ---------------------------------------------------------------------------

const REP_TO_COINS = 200; // 1 réputation ≈ 200 coins

// { clé DB (colonne table `job`) : { emoji, label, repPrice, slot } }
// slot "metier"   -> un seul actif à la fois (braqueur, tueur, juge, cambrioleur, hacker, policier)
// slot "capacite" -> un seul actif à la fois (cultivateur, blanchisseur)
const JOBS = {
    braqueur:     { emoji: "💰", label: "Braqueur",     repPrice: 16, slot: "metier" },
    juge:         { emoji: "⚖️", label: "Juge",         repPrice: 15, slot: "metier" },
    tueur:        { emoji: "🔪", label: "Tueur",        repPrice: 14, slot: "metier" },
    hacker:       { emoji: "💻", label: "Hacker",       repPrice: 13, slot: "metier" },
    policier:     { emoji: "👮", label: "Policier",     repPrice: 13, slot: "metier" },
    cambrioleur:  { emoji: "🕵️", label: "Cambrioleur",  repPrice: 12, slot: "metier" },
    blanchisseur: { emoji: "🧺", label: "Blanchisseur", repPrice: 15, slot: "capacite" },
    cultivateur:  { emoji: "🌱", label: "Cultivateur",  repPrice: 8,  slot: "capacite" }
};

const JOB_KEYS = Object.keys(JOBS);
const METIER_KEYS = JOB_KEYS.filter(k => JOBS[k].slot === "metier");
const CAPACITE_KEYS = JOB_KEYS.filter(k => JOBS[k].slot === "capacite");

// Tolérance acceptée entre les deux valeurs d'un échange pour le considérer "équilibré"
const BALANCE_TOLERANCE = 0.15; // 15%

function jobValue(key) {
    const job = JOBS[key];
    if (!job) return 0;
    return job.repPrice * REP_TO_COINS;
}

function jobInfo(key) {
    return JOBS[key] || null;
}

/**
 * Calcule la valeur en coins d'une offre : { type: 'coins', amount } ou { type: 'job', key }
 */
function offerValue(offer) {
    if (!offer) return 0;
    if (offer.type === "coins") return Number(offer.amount) || 0;
    if (offer.type === "job") return jobValue(offer.key);
    return 0;
}

/**
 * Compare deux offres et retourne un statut d'équilibre.
 * @returns {{ diff: number, ratio: number, balanced: boolean, favored: 'a'|'b'|null }}
 */
function compareOffers(offerA, offerB) {
    const valA = offerValue(offerA);
    const valB = offerValue(offerB);
    const diff = valA - valB;
    const base = Math.max(valA, valB, 1);
    const ratio = Math.abs(diff) / base;
    const balanced = ratio <= BALANCE_TOLERANCE;
    // Celui qui DONNE une offre de plus grande valeur est le désavantagé (il donne plus qu'il ne reçoit).
    // "advantaged"/"disadvantaged" sont donc à l'inverse de la comparaison brute valA vs valB.
    let advantaged = null, disadvantaged = null;
    if (diff > 0) { advantaged = "b"; disadvantaged = "a"; }
    else if (diff < 0) { advantaged = "a"; disadvantaged = "b"; }
    return { valA, valB, diff: Math.abs(diff), ratio, balanced, advantaged, disadvantaged };
}

module.exports = {
    REP_TO_COINS,
    JOBS,
    JOB_KEYS,
    METIER_KEYS,
    CAPACITE_KEYS,
    BALANCE_TOLERANCE,
    jobValue,
    jobInfo,
    offerValue,
    compareOffers
};
