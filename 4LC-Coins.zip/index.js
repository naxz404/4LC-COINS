require("./utils/branding.js");

// Vérification de la configuration avant de démarrer
{
  const fs = require("fs");
  const path = require("path");
  const cfgPath = path.join(__dirname, "config.json");
  if (!fs.existsSync(cfgPath)) {
    console.error("\n❌ config.json introuvable.\n   Copie config.example.json en config.json puis remplis ton token :\n   cp config.example.json config.json\n");
    process.exit(1);
  }
  const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
  if (!cfg.token || /TON[_ ]TOKEN/i.test(cfg.token)) {
    console.error("\n❌ Aucun token dans config.json.\n   Renseigne le token de ton bot (Portail développeur Discord > Bot > Reset Token).\n");
    process.exit(1);
  }
}
const {
  Client,
  Collection,
  GatewayIntentBits,
  Partials
} = require("discord.js");
const bot = new Client({
  intents: [ 
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildInvites,
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User,
    Partials.GuildMember,
    Partials.Reaction,
    Partials.ThreadMember,
    Partials.GuildScheduledEvent,
  ]
});
const ms = require("ms")
bot.setMaxListeners(70)

bot.commands = new Collection();
bot.antirob = new Map()
bot.antikill = new Map()

console.log(`
╔══════════════════════════════════════╗
║             4LC COINS                ║
║              By 4LC                  ║
║   https://discord.gg/ddJMXWYJ29      ║
╚══════════════════════════════════════╝
`)

bot.config = require('./config.json')
bot.footer = {
  text: "4LC Coins",
  iconURL: "https://cdn.discordapp.com/embed/avatars/0.png"
};
bot.supportLink = "https://discord.gg/ddJMXWYJ29";

bot.on("clientReady", async (bot) => {
  let pill = 0;

  setInterval(() => {
    pill = Math.floor(Math.random() * (20000 - 0 + 1)) + 0;
    bot.pill = pill;
  }, ms('5m'));
});

const commandHandler = require("./handlers/command.js")(bot);
const anticrashHandler = require("./utils/anticrash");
anticrashHandler(bot);
const eventdHandler = require("./handlers/event.js")(bot);
const loadDatabase = require("./handlers/loadDatabase");
const DataBase = require("./handlers/loginDatabase");
DataBase.connectDatabase(bot)
const startScheduler = require("./utils/scheduler.js");
startScheduler(bot);


bot.login(bot.config.token);
